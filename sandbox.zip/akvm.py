#!/usr/bin/env python3
"""
AKVM Panel v1.0 - KVM Manager
Modern dark UI • Public IP support • Console • Cloud-init
"""

import os, json, uuid, subprocess, signal, psutil, sqlite3, threading, time, shutil, socket, random, logging, warnings, hashlib, hmac, secrets, string, re, posixpath, stat, io, codecs
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
import urllib.request
import urllib.error
import urllib.parse
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from contextlib import contextmanager

warnings.filterwarnings("ignore")
logging.getLogger('werkzeug').setLevel(logging.ERROR)

REQUIRED_CMDS = {
    'qemu-system-x86_64': 'qemu-system-x86',
    'qemu-img': 'qemu-utils',
    'cloud-localds': 'cloud-image-utils',
    'wget': 'wget',
    'curl': 'curl',
    'sshpass': 'sshpass'
}

def check_system_deps():
    missing = []
    for cmd, pkg in REQUIRED_CMDS.items():
        if subprocess.run(['which', cmd], capture_output=True).returncode != 0:
            missing.append(pkg)
    if missing:
        print("=" * 60)
        print("  ⚠️  MISSING: sudo apt install -y " + ' '.join(set(missing)))
        print("=" * 60 + "\n")
        return False
    return True

check_system_deps()

app = Flask(__name__)
@app.after_request
def add_header(response):
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Content-Security-Policy'] = "default-src 'self' https: data: blob:; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https:; font-src 'self' https: data:; img-src 'self' data: https:; connect-src 'self'"
    return response

BASE_DIR = Path(__file__).parent.absolute()
_SECRET_FILE = BASE_DIR / '.secret_key'
if _SECRET_FILE.exists():
    app.secret_key = _SECRET_FILE.read_text().strip()
else:
    app.secret_key = secrets.token_hex(32)
    try:
        _SECRET_FILE.write_text(app.secret_key)
        os.chmod(_SECRET_FILE, 0o600)
    except Exception:
        pass
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_NAME='akvm_session',
    PERMANENT_SESSION_LIFETIME=86400 * 7,
    # Raised from 2MB so the file manager can upload real files. This limit is
    # global (applies to every route, not just file manager uploads) — if that's
    # too generous for a public-facing panel, give the upload route its own
    # request.max_content_length override instead of raising this site-wide.
    MAX_CONTENT_LENGTH=512 * 1024 * 1024,  # 512MB
)

VM_DIR = BASE_DIR / 'vm_instances'
DATABASE = str(BASE_DIR / 'akvm.db')
VM_DIR.mkdir(exist_ok=True)

try:
    import paramiko
    HAVE_PARAMIKO = True
except ImportError:
    HAVE_PARAMIKO = False

terminal_sessions = {}
TERMINAL_SESSION_IDLE_LIMIT = 15 * 60  # seconds — orphaned sessions (e.g. browser closed
                                        # without a clean disconnect) get reaped after this

def _reap_stale_terminal_sessions():
    """Close and drop any SSH shell session that hasn't been read from or
    written to in a while. Without this, a session whose browser tab was
    just closed (no clean /disconnect call) keeps its paramiko SSHClient +
    channel open on the host forever, leaking a socket + thread per orphan."""
    now = time.time()
    stale = [sid for sid, s in terminal_sessions.items()
             if now - s.get('last_active', s.get('created', now)) > TERMINAL_SESSION_IDLE_LIMIT]
    for sid in stale:
        sess = terminal_sessions.pop(sid, None)
        if not sess:
            continue
        try:
            sess['channel'].close()
        except Exception:
            pass
        try:
            sess['ssh'].close()
        except Exception:
            pass

# ─────────────────────────── Security helpers ───────────────────────────

_UUID_RE = re.compile(
    r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.I
)

def is_valid_uuid(val):
    return bool(val and isinstance(val, str) and _UUID_RE.match(val.strip()))

def safe_vm_id(vid):
    """Return vid if valid UUID else None (blocks path traversal)."""
    if not is_valid_uuid(vid):
        return None
    return vid.strip().lower()

def safe_int(val, default=0, min_v=None, max_v=None):
    try:
        n = int(val)
    except (TypeError, ValueError):
        return default
    if min_v is not None and n < min_v:
        return default
    if max_v is not None and n > max_v:
        return default
    return n

def sanitize_name(name, max_len=64):
    name = (name or '').strip()
    name = re.sub(r'[^\w\s.\-]', '', name)[:max_len]
    return name.strip() or 'vm'

def constant_time_eq(a, b):
    try:
        return secrets.compare_digest(str(a or ''), str(b or ''))
    except Exception:
        return False

# Simple in-memory rate limiter {key: [timestamps]}
_rate_buckets = {}

def rate_limit(key, limit=10, window=60):
    """Return True if allowed, False if rate exceeded."""
    now = time.time()
    bucket = _rate_buckets.get(key, [])
    bucket = [t for t in bucket if now - t < window]
    if len(bucket) >= limit:
        _rate_buckets[key] = bucket
        return False
    bucket.append(now)
    _rate_buckets[key] = bucket
    return True

def csrf_token():
    if '_csrf' not in session:
        session['_csrf'] = secrets.token_hex(16)
    return session['_csrf']

def verify_csrf():
    token = request.form.get('_csrf') or (request.headers.get('X-CSRF-Token') or '')
    if request.is_json and request.json:
        token = token or (request.json.get('_csrf') or '')
    expected = session.get('_csrf', '')
    if not expected or not constant_time_eq(token, expected):
        return False
    return True

# Settings keys that may be changed via UI/API
SETTINGS_ALLOWLIST = {
    'site_name', 'theme_color', 'server_ip', 'base_ssh_port', 'base_vnc_port', 'base_serial_port',
    'max_nat_ports_per_vm', 'smbios_manufacturer', 'smbios_product', 'smbios_version',
    'default_nested_kvm', 'node_register_token', 'background_enabled', 'background_url',
    'company_name', 'support_email', 'footer_text', 'max_vps_per_user',
    'default_ram_mb', 'default_cpu_cores', 'default_storage_gb', 'ui_font', 'site_icon_url', 'sidebar_icon_url',
    'security_scan_enabled', 'security_scan_interval_min', 'security_auto_stop_on_mining',
    'discord_oauth_client_id', 'discord_oauth_client_secret', 'discord_oauth_enabled',
}



def get_public_ip():
    try:
        return subprocess.check_output(['curl', '-s', '--max-time', '5', 'ifconfig.me'], timeout=6).decode().strip()
    except Exception:
        try:
            return subprocess.check_output(['curl', '-s', '--max-time', '5', 'api.ipify.org'], timeout=6).decode().strip()
        except Exception:
            return '127.0.0.1'

PUBLIC_IP = get_public_ip()

def kvm_available():
    """Return True if /dev/kvm exists and is usable."""
    try:
        if not os.path.exists('/dev/kvm'):
            return False
        # readable + writable
        return os.access('/dev/kvm', os.R_OK | os.W_OK)
    except Exception:
        return False

HAVE_KVM = kvm_available()

def generate_vm_password(length=12):
    """Generate a secure random password for VM root/sudo users."""
    alphabet = string.ascii_letters + string.digits
    # ensure mix
    pw = [
        secrets.choice(string.ascii_lowercase),
        secrets.choice(string.ascii_uppercase),
        secrets.choice(string.digits),
    ]
    pw += [secrets.choice(alphabet) for _ in range(max(0, length - 3))]
    random.SystemRandom().shuffle(pw)
    return ''.join(pw)

def allocate_private_ip():
    """Allocate a unique private IP from 10.10.0.0/16 for NAT VMs."""
    used = set()
    rows = db_execute("SELECT private_ip FROM vm_instances WHERE private_ip IS NOT NULL", fetch=True) or []
    for r in rows:
        if r['private_ip']:
            used.add(r['private_ip'])
    for _ in range(5000):
        a = random.randint(0, 255)
        b = random.randint(2, 254)  # skip .0 .1 .255-ish
        ip = f"10.10.{a}.{b}"
        if ip not in used:
            return ip
    return f"10.10.{random.randint(0,255)}.{random.randint(2,254)}"

def allocate_host_port(preferred=None):
    """Allocate a free host TCP port for NAT forwarding (SSH or extra)."""
    used = set()
    for r in (db_execute("SELECT ssh_port FROM vm_instances WHERE ssh_port IS NOT NULL", fetch=True) or []):
        used.add(r['ssh_port'])
    for r in (db_execute("SELECT host_port FROM port_forwards", fetch=True) or []):
        used.add(r['host_port'])
    base = int(gsv('base_ssh_port', 10000))
    if preferred and preferred not in used and 1024 <= preferred <= 65535:
        return preferred
    for _ in range(5000):
        p = random.randint(base, min(base + 20000, 65000))
        if p not in used:
            return p
    return random.randint(20000, 60000)

def ensure_local_node():
    """Ensure the panel host Local Node exists; recreate if deleted."""
    local = db_execute("SELECT * FROM nodes WHERE is_local=1", fetchone=True)
    if local:
        try:
            cpu = psutil.cpu_count() or 1
            ram = int(psutil.virtual_memory().total / (1024 * 1024))
            disk = int(psutil.disk_usage('/').total / (1024 ** 3))
            db_execute(
                "UPDATE nodes SET hostname=?, status='online', cpu_cores=?, ram_mb=?, disk_gb=?, "
                "has_kvm=?, last_seen=CURRENT_TIMESTAMP WHERE is_local=1",
                (socket.gethostname(), cpu, ram, disk, 1 if HAVE_KVM else 0)
            )
        except Exception:
            pass
        return local['id'] if isinstance(local, dict) or hasattr(local, 'keys') else local[0]
    try:
        cpu = psutil.cpu_count() or 1
        ram = int(psutil.virtual_memory().total / (1024 * 1024))
        disk = int(psutil.disk_usage('/').total / (1024 ** 3))
    except Exception:
        cpu, ram, disk = 1, 0, 0
    # avoid name collision
    name = 'Local Node'
    exists = db_execute("SELECT id FROM nodes WHERE name=?", (name,), fetchone=True)
    if exists:
        db_execute("UPDATE nodes SET is_local=1, status='online', hostname=?, has_kvm=?, "
                   "cpu_cores=?, ram_mb=?, disk_gb=?, last_seen=CURRENT_TIMESTAMP WHERE id=?",
                   (socket.gethostname(), 1 if HAVE_KVM else 0, cpu, ram, disk, exists['id']))
        return exists['id']
    db_execute(
        "INSERT INTO nodes (name, hostname, is_local, status, cpu_cores, ram_mb, disk_gb, has_kvm, notes) "
        "VALUES (?,?,1,'online',?,?,?,?,?)",
        (name, socket.gethostname(), cpu, ram, disk, 1 if HAVE_KVM else 0, 'Panel host')
    )
    row = db_execute("SELECT id FROM nodes WHERE is_local=1", fetchone=True)
    return row['id'] if row else None




# Default OS users for cloud images
OS_TEMPLATES = {
    'ubuntu-22.04': {
        'name': 'Ubuntu 22.04 LTS',
        'url': 'https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img',
        'default_user': 'ubuntu',
        'root_pass': 'akvm123',
    },
    'ubuntu-24.04': {
        'name': 'Ubuntu 24.04 LTS',
        'url': 'https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img',
        'default_user': 'ubuntu',
        'root_pass': 'akvm123',
    },
    'ubuntu-26.04': {
        'name': 'Ubuntu 26.04 LTS',
        'url': 'https://cloud-images.ubuntu.com/releases/26.04/release/ubuntu-26.04-server-cloudimg-amd64.img',
        'default_user': 'ubuntu',
        'root_pass': 'akvm123',
    },
    'debian-11': {
        'name': 'Debian 11',
        'url': 'https://cloud.debian.org/images/cloud/bullseye/latest/debian-11-generic-amd64.qcow2',
        'default_user': 'debian',
        'root_pass': 'akvm123',
    },
    'debian-12': {
        'name': 'Debian 12',
        'url': 'https://cloud.debian.org/images/cloud/bookworm/latest/debian-12-generic-amd64.qcow2',
        'default_user': 'debian',
        'root_pass': 'akvm123',
    },
    'debian-13': {
        'name': 'Debian 13',
        'url': 'https://cloud.debian.org/images/cloud/trixie/latest/debian-13-generic-amd64.qcow2',
        'default_user': 'debian',
        'root_pass': 'akvm123',
    },
    'fedora-40': {
        'name': 'Fedora 40',
        'url': 'https://download.fedoraproject.org/pub/fedora/linux/releases/40/Cloud/x86_64/images/Fedora-Cloud-Base-Generic.x86_64-40-1.14.qcow2',
        'default_user': 'fedora',
        'root_pass': 'akvm123',
    },
    'centos-stream-9': {
        'name': 'CentOS Stream 9',
        'url': 'https://cloud.centos.org/centos/9-stream/x86_64/images/CentOS-Stream-GenericCloud-9-latest.x86_64.qcow2',
        'default_user': 'cloud-user',
        'root_pass': 'akvm123',
    },
    'alpine-3.20': {
        'name': 'Alpine 3.20',
        'url': 'https://dl-cdn.alpinelinux.org/cloud/v3.20/x86_64/alpine-cloud-generic-3.20.3-x86_64.qcow2',
        'default_user': 'alpine',
        'root_pass': 'akvm123',
    },
}


# ─────────────────────────── Database ───────────────────────────

def get_db_connection():
    conn = sqlite3.connect(DATABASE, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn

@contextmanager
def get_db():
    conn = get_db_connection()
    try:
        yield conn
    finally:
        conn.close()

def db_execute(query, params=None, fetch=False, fetchone=False):
    for attempt in range(5):
        try:
            conn = get_db_connection()
            cursor = conn.execute(query, params) if params else conn.execute(query)
            result = cursor.fetchall() if fetch else (cursor.fetchone() if fetchone else None)
            conn.commit()
            conn.close()
            return result
        except sqlite3.OperationalError as e:
            if 'locked' in str(e) and attempt < 4:
                time.sleep(0.3 * (attempt + 1))
                continue
            raise

def init_db():
    conn = sqlite3.connect(DATABASE, timeout=30)
    c = conn.cursor()
    c.execute("PRAGMA journal_mode=WAL")
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP,
        is_active BOOLEAN DEFAULT 1
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS vm_instances (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vm_id TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        os_template TEXT NOT NULL,
        ram_mb INTEGER NOT NULL,
        cpu_cores INTEGER NOT NULL,
        storage_gb INTEGER NOT NULL,
        ssh_port INTEGER,
        ssh_host TEXT,
        ssh_user TEXT,
        ssh_password TEXT,
        network_mode TEXT DEFAULT 'private',
        public_ip TEXT,
        vnc_port INTEGER,
        status TEXT DEFAULT 'creating',
        pid INTEGER,
        tmate_ssh TEXT,
        tmate_web TEXT,
        creation_progress INTEGER DEFAULT 0,
        creation_step TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS public_ips (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip_address TEXT UNIQUE NOT NULL,
        label TEXT,
        is_available BOOLEAN DEFAULT 1,
        assigned_vm_id TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS nodes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        hostname TEXT,
        is_local BOOLEAN DEFAULT 0,
        status TEXT DEFAULT 'online',
        cpu_cores INTEGER,
        ram_mb INTEGER,
        disk_gb INTEGER,
        has_kvm BOOLEAN DEFAULT 0,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS port_forwards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vm_id TEXT NOT NULL,
        host_port INTEGER NOT NULL,
        guest_port INTEGER NOT NULL,
        protocol TEXT DEFAULT 'tcp',
        label TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(host_port)
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS api_keys (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT,
        key_hash TEXT NOT NULL,
        key_prefix TEXT NOT NULL,
        scope TEXT DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_used TIMESTAMP,
        is_active BOOLEAN DEFAULT 1,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        type TEXT DEFAULT 'info',
        is_read BOOLEAN DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT NOT NULL,
        details TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    defaults = [
        ('site_name', 'AKVM Panel'),
        ('theme_color', '#d98f3f'),
        ('server_ip', PUBLIC_IP),
        ('base_ssh_port', '10000'),
        ('base_vnc_port', '5900'),
        ('base_serial_port', '5900'),
        ('max_nat_ports_per_vm', '5'),
        ('smbios_manufacturer', 'AKVM'),
        ('smbios_product', 'AKVM Virtual Machine'),
        ('smbios_version', '1.0'),
        ('default_nested_kvm', 'false'),
        ('node_register_token', ''),
        ('background_enabled', 'false'),
        ('background_url', ''),
        ('site_icon_url', '/static/uploads/site-icon.png'),
        ('sidebar_icon_url', '/static/uploads/sidebar-icon.png'),
        ('discord_bot_token', ''),
        ('discord_bot_enabled', 'false'),
        ('discord_bot_guild_id', ''),
        ('discord_free_vm_ram_mb', '8192'),
        ('discord_free_vm_cpu_cores', '2'),
        ('discord_free_vm_storage_gb', '40'),
        ('discord_free_vm_os', 'ubuntu-22.04'),
        ('discord_free_vm_limit', '1'),
        ('security_scan_enabled', 'true'),
        ('security_scan_interval_min', '15'),
        ('security_auto_stop_on_mining', 'false'),
        ('discord_oauth_client_id', ''),
        ('discord_oauth_client_secret', ''),
        ('discord_oauth_enabled', 'false'),
        ('discord_bot_avatar_set', 'false'),
        ('discord_admin_ids', ''),
        ('ui_font', 'roboto'),
        ('valid_license_key', ''),  # not used — verification is digest-based

        ('license_activated', 'false'),
        ('license_key_entered', ''),
        ('license_digest', ''),
        ('license_activated_at', ''),
    ]
    for k, v in defaults:
        c.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))
    try:
        c.execute("INSERT INTO users (username, email, password, role) VALUES (?,?,?,?)",
                  ('admin', 'admin@akvm.local', generate_password_hash('admin123', method='scrypt'), 'admin'))
    except Exception:
        pass
    # Migrate columns if upgrading from older DB
    for col, decl in [
        ("network_mode", "TEXT DEFAULT 'private'"),
        ("public_ip", "TEXT"),
        ("private_ip", "TEXT"),
        ("node_id", "INTEGER"),
        ("accel_mode", "TEXT DEFAULT 'auto'"),
        ("nested_kvm", "INTEGER DEFAULT 0"),
        ("serial_port", "INTEGER"),
        ("sshx_url", "TEXT"),
    ]:
        try:
            c.execute(f"ALTER TABLE vm_instances ADD COLUMN {col} {decl}")
        except Exception:
            pass
    for col, decl in [
        ("api_url", "TEXT"),
        ("token", "TEXT"),
        ("agent_version", "TEXT"),
    ]:
        try:
            c.execute(f"ALTER TABLE nodes ADD COLUMN {col} {decl}")
        except Exception:
            pass
    for col, decl in [
        ("discord_id", "TEXT"),
    ]:
        try:
            c.execute(f"ALTER TABLE users ADD COLUMN {col} {decl}")
        except Exception:
            pass
    try:
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_discord_id ON users(discord_id) WHERE discord_id IS NOT NULL")
    except Exception:
        pass
    # Ensure local node exists
    local = c.execute("SELECT id FROM nodes WHERE is_local=1").fetchone()
    if not local:
        try:
            cpu = psutil.cpu_count() or 1
            ram = int((psutil.virtual_memory().total or 0) / (1024 * 1024))
            disk = int((psutil.disk_usage('/').total or 0) / (1024 ** 3))
        except Exception:
            cpu, ram, disk = 1, 0, 0
        hn = socket.gethostname()
        c.execute(
            "INSERT INTO nodes (name, hostname, is_local, status, cpu_cores, ram_mb, disk_gb, has_kvm, notes) VALUES (?,?,?,?,?,?,?,?,?)",
            ("Local Node", hn, 1, "online", cpu, ram, disk, 1 if HAVE_KVM else 0, "Panel host")
        )
    else:
        try:
            c.execute("UPDATE nodes SET has_kvm=?, last_seen=CURRENT_TIMESTAMP, status='online' WHERE is_local=1",
                      (1 if HAVE_KVM else 0,))
        except Exception:
            pass
    conn.commit()
    conn.close()


def row_get(row, key, default=None):
    """Safe get for sqlite3.Row / dict / None."""
    if row is None:
        return default
    try:
        if hasattr(row, 'keys') and key in row.keys():
            val = row[key]
            return default if val is None else val
    except Exception:
        pass
    if isinstance(row, dict):
        return row.get(key, default)
    return default

def row_to_dict(row):
    if row is None:
        return {}
    if isinstance(row, dict):
        return row
    try:
        return {k: row[k] for k in row.keys()}
    except Exception:
        return {}

# ── VM Security Scanner (crypto-miner + intrusion detection) ──
# Runs read-only diagnostic commands over SSH and flags common signs of
# abuse: known cryptocurrency-miner processes, brute-force SSH attempts,
# suspicious executables dropped in /tmp, and cron entries that pipe a
# download straight into a shell (a classic backdoor/persistence pattern).
MINER_PROCESS_NAMES = [
    'xmrig', 'xmr-stak', 'minerd', 'cpuminer', 'ccminer', 'ethminer',
    'nheqminer', 'cgminer', 'bfgminer', 't-rex', 'trex', 'phoenixminer',
    'lolminer', 'gminer', 'teamredminer', 'srbminer', 'nbminer', 'wildrig',
    'nicehash', 'unmineable', 'xmr-stak-cpu', 'cast_xmr', 'sgminer',
]

_SCAN_SCRIPT = r'''
echo "===PS==="
ps aux --sort=-%cpu 2>/dev/null | head -25
echo "===LOAD==="
uptime 2>/dev/null
echo "===FAILEDAUTH==="
( grep -c "Failed password" /var/log/auth.log 2>/dev/null || grep -c "Failed password" /var/log/secure 2>/dev/null || echo 0 )
echo "===TMPEXEC==="
find /tmp /var/tmp /dev/shm -maxdepth 2 -type f -executable 2>/dev/null | head -20
echo "===CRON==="
( crontab -l 2>/dev/null; cat /etc/cron.d/* 2>/dev/null ) | grep -Ei "curl|wget|base64|\|\s*sh|\|\s*bash" | head -10
echo "===PORTS==="
( ss -tlnp 2>/dev/null || netstat -tlnp 2>/dev/null ) | head -20
echo "===END==="
'''

def scan_vm_for_threats(v):
    """SSH into a running VM and check for crypto-miners / intrusion signs.
    Returns a dict: {ok, miner_detected, matched_processes, failed_logins,
    suspicious_files, suspicious_cron, raw_ps, raw_load, error}."""
    result = {
        'ok': False, 'miner_detected': False, 'matched_processes': [],
        'failed_logins': 0, 'suspicious_files': [], 'suspicious_cron': [],
        'raw_ps': '', 'raw_load': '', 'error': None,
    }
    sp = row_get(v, 'ssh_port')
    password = row_get(v, 'ssh_password', '')
    user = row_get(v, 'ssh_user', 'root') or 'root'
    if not sp:
        result['error'] = 'No SSH port on record for this VM.'
        return result
    output = vm.ssh_exec(sp, _SCAN_SCRIPT, password=password, user=user, timeout=25)
    if not output or 'Connection failed' in output or output.strip() == '':
        result['error'] = output or 'No output from VM (is it running and reachable over SSH?)'
        return result

    def _section(name):
        m = re.search(rf'==={name}===\n(.*?)(?=\n===[A-Z]+===|\Z)', output, re.DOTALL)
        return m.group(1).strip() if m else ''

    ps_out = _section('PS')
    result['raw_ps'] = ps_out
    result['raw_load'] = _section('LOAD')

    matched = []
    for line in ps_out.splitlines():
        low = line.lower()
        for name in MINER_PROCESS_NAMES:
            if name in low and name not in matched:
                matched.append(name)
    result['matched_processes'] = matched
    result['miner_detected'] = bool(matched)

    failed_raw = _section('FAILEDAUTH')
    try:
        result['failed_logins'] = int(re.search(r'\d+', failed_raw).group()) if failed_raw else 0
    except Exception:
        result['failed_logins'] = 0

    tmp_files = [l.strip() for l in _section('TMPEXEC').splitlines() if l.strip()]
    result['suspicious_files'] = tmp_files[:20]

    cron_lines = [l.strip() for l in _section('CRON').splitlines() if l.strip()]
    result['suspicious_cron'] = cron_lines[:10]

    result['ok'] = True
    return result

def scan_summary_text(scan):
    if not scan['ok']:
        return f"❌ Scan failed: {scan['error']}"
    lines = []
    if scan['miner_detected']:
        lines.append(f"🚨 **Crypto-miner detected**: {', '.join(scan['matched_processes'])}")
    else:
        lines.append("✅ No known miner processes found")
    if scan['failed_logins'] > 20:
        lines.append(f"🚨 **{scan['failed_logins']} failed SSH login attempts** — possible brute-force")
    elif scan['failed_logins'] > 0:
        lines.append(f"⚠️ {scan['failed_logins']} failed SSH login attempts")
    else:
        lines.append("✅ No failed SSH logins")
    if scan['suspicious_files']:
        lines.append(f"⚠️ {len(scan['suspicious_files'])} executable file(s) in /tmp — worth reviewing")
    else:
        lines.append("✅ No suspicious executables in /tmp")
    if scan['suspicious_cron']:
        lines.append(f"🚨 **Suspicious cron entry** piping a download into a shell — possible backdoor")
    else:
        lines.append("✅ No suspicious cron entries")
    return '\n'.join(lines)

def gsv(key, default=None):
    try:
        r = db_execute("SELECT value FROM settings WHERE key=?", (key,), fetchone=True)
        return r['value'] if r else default
    except Exception:
        return default

def add_notification(uid, title, message, ntype='info'):
    db_execute("INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)",
               (uid, title, message, ntype))

def audit(uid, action, details=''):
    db_execute("INSERT INTO audit_log (user_id, action, details) VALUES (?,?,?)",
               (uid, action, details))

# ─────────────────────────── License system ───────────────────────────

# ── License verification (per-install unique key, HMAC-based) ──
# Each install gets its own random Install ID (shown on the license page).
# The valid key for that install is: HMAC-SHA256(LICENSE_SECRET, install_id),
# formatted as groups of 5 uppercase hex chars. Keep LICENSE_SECRET private —
# it's the only thing needed (together with an install_id) to generate a
# matching key. Use generate_license_key.py (shipped alongside this file) to
# produce a key for any given install_id.
LICENSE_SECRET = "akvm-9f3c7a1e-59b2-4d8a-b6ce-2f0a7e4c1d6b-do-not-share"

def _license_install_id():
    iid = gsv('license_install_id', '') or ''
    if not iid:
        iid = secrets.token_hex(6)  # 12 hex chars
        _set_setting('license_install_id', iid)
    return iid

def _format_license_key(raw_hex: str) -> str:
    raw_hex = raw_hex.upper()
    groups = [raw_hex[i:i+5] for i in range(0, 20, 5)]
    return 'AKVM-' + '-'.join(groups)

def _expected_license_key(install_id: str) -> str:
    digest = hmac.new(LICENSE_SECRET.encode('utf-8'), install_id.encode('utf-8'), hashlib.sha256).hexdigest()
    return _format_license_key(digest[:20])

def is_licensed():
    flag = (gsv('license_activated', 'false') or 'false').lower()
    if flag not in ('1', 'true', 'yes'):
        return False
    iid = _license_install_id()
    entered = (gsv('license_key_entered', '') or '').strip().upper()
    return constant_time_eq(entered, _expected_license_key(iid))

def get_valid_license_key():
    # Intentionally unavailable here — generate keys with generate_license_key.py
    return None

def _set_setting(key, value):
    db_execute(
        "INSERT INTO settings (key, value, updated_at) VALUES (?,?,CURRENT_TIMESTAMP) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=CURRENT_TIMESTAMP",
        (key, value),
    )

def activate_license(key):
    key = (key or '').strip().upper()
    if not key:
        return False
    iid = _license_install_id()
    if not constant_time_eq(key, _expected_license_key(iid)):
        return False
    _set_setting('license_activated', 'true')
    _set_setting('license_key_entered', key)
    _set_setting('license_activated_at', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    return True

def deactivate_license():
    _set_setting('license_activated', 'false')
    _set_setting('license_key_entered', '')

# ── Remote blacklist check ──
# Panel periodically fetches a small JSON file you control (e.g. a GitHub
# repo you own) listing revoked Install IDs / keys. Any matching install
# gets auto-locked (license deactivated) on the next check. This is the
# ONLY thing that needs network access for licensing — everything else
# (initial activation) works fully offline via the HMAC key.
#
# Point this at a raw file URL you control, e.g.:
#   https://raw.githubusercontent.com/Akvmpanel/get-akvm/main/revoked.json
# JSON format:
#   {"revoked_install_ids": ["ABCD1234EFGH"], "revoked_keys": ["AKVM-..."]}
LICENSE_REVOCATION_URL = "https://raw.githubusercontent.com/Akvmpanel/get-akvm/main/revoked.json"
LICENSE_CHECK_INTERVAL = 6 * 3600  # seconds between checks

_license_check_status = {'last_check': None, 'last_result': None, 'last_error': None}

def check_license_revocation():
    """Fetch the revocation list and lock this install if it's on it.
    Fails open — any network/parse error just skips the check silently,
    so a temporary outage never locks out a legitimate install."""
    if not LICENSE_REVOCATION_URL:
        return
    try:
        req = urllib.request.Request(
            LICENSE_REVOCATION_URL,
            headers={'User-Agent': 'AKVM-Panel-License-Check'}
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        iid = _license_install_id()
        entered_key = (gsv('license_key_entered', '') or '').strip().upper()
        revoked_ids = set(x.strip().upper() for x in data.get('revoked_install_ids', []) or [])
        revoked_keys = set(x.strip().upper() for x in data.get('revoked_keys', []) or [])
        _license_check_status['last_check'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        _license_check_status['last_error'] = None
        if iid.upper() in revoked_ids or (entered_key and entered_key in revoked_keys):
            deactivate_license()
            _license_check_status['last_result'] = 'revoked'
            logging.getLogger('akvm.license').warning(f"Install {iid} is on the revocation list — license deactivated.")
        else:
            _license_check_status['last_result'] = 'ok'
    except Exception as e:
        _license_check_status['last_error'] = str(e)

def _license_check_loop():
    while True:
        try:
            check_license_revocation()
        except Exception:
            pass
        time.sleep(LICENSE_CHECK_INTERVAL)

def start_license_check_thread():
    t = threading.Thread(target=_license_check_loop, daemon=True)
    t.start()

# ── Security scanner: crypto-mining & brute-force (hack) detector ──
# Periodically SSHes into every running VM and checks for:
#   1. Known cryptocurrency-miner processes running
#   2. A burst of failed SSH login attempts (possible brute-force attack)
# Any hit creates a notification for every admin + an audit log entry.
# Auto-stopping the VM on mining detection is opt-in (Settings > Security).

MINER_PROCESS_NAMES = [
    'xmrig', 'xmr-stak', 'ethminer', 'cpuminer', 'minerd', 'cgminer', 'bfgminer',
    'ccminer', 't-rex', 'trex', 'phoenixminer', 'lolminer', 'gminer', 'teamredminer',
    'nbminer', 'nanominer', 'srbminer', 'nicehash', 'unmineable', 'xmr-stak-cpu',
]

_security_scan_status = {'last_scan': None, 'last_findings': []}

def _notify_all_admins(title, message, ntype='warning'):
    admins = db_execute("SELECT id FROM users WHERE role='admin'", fetch=True) or []
    for a in admins:
        db_execute("INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)",
                   (a['id'], title, message, ntype))

def _scan_vm_for_abuse(v):
    """Runs inside the scan loop for one running VM row. Returns a list of finding strings."""
    findings = []
    sp = v['ssh_port']
    pw = v['ssh_password'] or ''
    if not sp:
        return findings

    # 1. Crypto miner process check
    ps_out = vm.ssh_exec(sp, "ps -eo comm= 2>/dev/null; ps aux 2>/dev/null", password=pw, timeout=12) or ''
    ps_lower = ps_out.lower()
    hit_miners = [m for m in MINER_PROCESS_NAMES if m in ps_lower]
    if hit_miners:
        findings.append(f"Possible crypto-mining process detected: {', '.join(sorted(set(hit_miners)))}")

    # 2. Brute-force / failed SSH login burst check (last ~15 min of auth log)
    auth_cmd = (
        "( grep -i 'Failed password' /var/log/auth.log 2>/dev/null | tail -500; "
        "journalctl -u ssh --since '-15 min' 2>/dev/null | grep -i 'Failed password' ) | wc -l"
    )
    fail_out = vm.ssh_exec(sp, auth_cmd, password=pw, timeout=12) or ''
    try:
        fail_count = int(re.search(r'\d+', fail_out).group())
    except Exception:
        fail_count = 0
    if fail_count >= 50:
        findings.append(f"{fail_count} failed SSH login attempts detected — possible brute-force attack against this VM")

    return findings

def run_security_scan():
    if (gsv('security_scan_enabled', 'true') or 'true').lower() not in ('1', 'true', 'yes'):
        return
    auto_stop = (gsv('security_auto_stop_on_mining', 'false') or 'false').lower() in ('1', 'true', 'yes')
    rows = db_execute("SELECT * FROM vm_instances WHERE status='running'", fetch=True) or []
    all_findings = []
    for v in rows:
        try:
            running, pid = vm.vm_status(v['vm_id'])
            if not running:
                continue
            findings = _scan_vm_for_abuse(v)
            if not findings:
                continue
            all_findings.append({'vm_id': v['vm_id'], 'name': v['name'], 'findings': findings})
            msg = f"VM \"{v['name']}\" ({v['vm_id'][:8]}): " + "; ".join(findings)
            audit(v['user_id'], 'security_alert', msg)
            is_mining = any('mining' in f.lower() for f in findings)
            action_note = ''
            if is_mining and auto_stop:
                try:
                    vm.stop_vm(pid, v['ssh_port'])
                    db_execute("UPDATE vm_instances SET status='stopped', pid=NULL WHERE vm_id=?", (v['vm_id'],))
                    action_note = ' The VM was automatically stopped.'
                    audit(v['user_id'], 'security_auto_stop', f"Auto-stopped {v['name']} after mining detection")
                except Exception:
                    pass
            _notify_all_admins(
                'Security alert',
                msg + action_note,
                'danger' if is_mining else 'warning'
            )
        except Exception as e:
            logging.getLogger('akvm.security').error(f"Scan failed for {v.get('vm_id')}: {e}")
    _security_scan_status['last_scan'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    _security_scan_status['last_findings'] = all_findings

def _security_scan_loop():
    # Small initial delay so VMs have time to finish booting after a panel restart
    time.sleep(60)
    while True:
        try:
            run_security_scan()
        except Exception:
            pass
        interval_min = safe_int(gsv('security_scan_interval_min', '15'), 15, 5, 1440)
        time.sleep(interval_min * 60)

def start_security_scan_thread():
    t = threading.Thread(target=_security_scan_loop, daemon=True)
    t.start()

LICENSE_EXEMPT = {
    'license_activate', 'license_page', 'static', 'logout',
    'api_node_register', 'api_node_heartbeat',
}


@app.before_request
def csrf_protect():
    if request.method not in ('POST', 'PUT', 'PATCH', 'DELETE'):
        return None
    # API + node agents use their own auth
    if request.path.startswith('/api/'):
        return None
    # Standalone auth/license pages (must work after deactivation while still logged in)
    if request.endpoint in (
        'license_page', 'login', 'register', 'logout',
        'terminal_read', 'terminal_send', 'terminal_connect', 'terminal_resize', 'terminal_disconnect', 'read_notification',
        'vm_security_scan',
    ):
        return None
    # Require CSRF for logged-in form posts
    if session.get('user_id'):
        if not verify_csrf():
            if request.accept_mimetypes.best == 'application/json' or request.is_json:
                return jsonify({'success': False, 'error': 'CSRF validation failed'}), 403
            flash('Security token expired. Please retry.', 'danger')
            return redirect(request.referrer or url_for('index'))
    return None

@app.before_request
def require_license():
    # Allow static / exempt endpoints
    ep = request.endpoint or ''
    if ep in LICENSE_EXEMPT or ep.startswith('static'):
        return None
    # Node API exempt
    if request.path.startswith('/api/node/'):
        return None
    if is_licensed():
        return None
    # Force license page
    if ep != 'license_page' and ep != 'license_activate':
        return redirect(url_for('license_page'))
    return None


# UI font catalog (admin-selectable)
PANEL_FONTS = {
    'inter': {
        'name': 'Inter',
        'family': "'Inter', 'Inter Variable', system-ui, -apple-system, sans-serif",
        'google': 'Inter:wght@400;500;600;700',
        'preview': 'Clean modern UI default',
    },
    'system': {
        'name': 'System UI',
        'family': "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        'google': None,
        'preview': 'Native OS font stack',
    },
    'roboto': {
        'name': 'Roboto',
        'family': "'Roboto', 'Roboto Variable', system-ui, sans-serif",
        'google': 'Roboto:wght@400;500;700',
        'preview': 'Google Material style',
    },
    'poppins': {
        'name': 'Poppins',
        'family': "'Poppins', system-ui, sans-serif",
        'google': 'Poppins:wght@400;500;600;700',
        'preview': 'Geometric and friendly',
    },
    'dm-sans': {
        'name': 'DM Sans',
        'family': "'DM Sans', 'DM Sans Variable', system-ui, sans-serif",
        'google': 'DM+Sans:wght@400;500;600;700',
        'preview': 'Low-contrast geometric',
    },
    'nunito': {
        'name': 'Nunito',
        'family': "'Nunito', 'Nunito Variable', system-ui, sans-serif",
        'google': 'Nunito:wght@400;600;700',
        'preview': 'Rounded soft UI',
    },
    'source-sans': {
        'name': 'Source Sans 3',
        'family': "'Source Sans 3', 'Source Sans 3 Variable', system-ui, sans-serif",
        'google': 'Source+Sans+3:wght@400;600;700',
        'preview': 'Adobe open UI font',
    },
    'ibm-plex': {
        'name': 'IBM Plex Sans',
        'family': "'IBM Plex Sans', 'IBM Plex Sans Variable', system-ui, sans-serif",
        'google': 'IBM+Plex+Sans:wght@400;500;600;700',
        'preview': 'Technical corporate',
    },
    'jetbrains': {
        'name': 'JetBrains Mono',
        'family': "'JetBrains Mono', 'JetBrains Mono Variable', ui-monospace, monospace",
        'google': 'JetBrains+Mono:wght@400;500;600;700',
        'preview': 'Monospace everywhere',
    },
    'space-grotesk': {
        'name': 'Space Grotesk',
        'family': "'Space Grotesk', 'Space Grotesk Variable', system-ui, sans-serif",
        'google': 'Space+Grotesk:wght@400;500;600;700',
        'preview': 'Modern display UI',
    },
}

def get_ui_font():
    """Return (key, font_meta) for the active UI font."""
    try:
        key = (gsv('ui_font', 'inter') or 'inter').strip().lower()
    except Exception:
        key = 'inter'
    if key not in PANEL_FONTS:
        key = 'inter'
    return key, PANEL_FONTS[key]

@app.context_processor
def inject_globals():
    def gs(k, d=None):
        return gsv(k, d)
    unread = 0
    recent = []
    if session.get('user_id'):
        try:
            r = db_execute("SELECT COUNT(*) as c FROM notifications WHERE user_id=? AND is_read=0",
                           (session['user_id'],), fetchone=True)
            unread = r['c'] if r else 0
            recent = db_execute(
                "SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 5",
                (session['user_id'],), fetch=True) or []
        except Exception:
            pass
    try:
        _fk, _fm = get_ui_font()
    except Exception:
        _fk, _fm = 'inter', {
            'family': "'Inter', 'Inter Variable', system-ui, -apple-system, sans-serif",
            'google': 'Inter:wght@400;500;600;700',
        }
    return {
        'site_name': gs('site_name', 'AKVM Panel'),
        'site_version': '1.0',
        'developer_name': gs('developer_name', 'AKVM'),
        'theme_color': gs('theme_color', '#d98f3f'),
        'server_ip': gs('server_ip', PUBLIC_IP),
        'bg_enabled': gs('background_enabled', 'false'),
        'bg_url': gs('background_url', ''),
        'site_icon_url': gs('site_icon_url', ''),
        'sidebar_icon_url': gs('sidebar_icon_url', ''),
        'ui_font_key': _fk,
        'ui_font_family': _fm['family'],
        'ui_font_google': _fm.get('google'),
        'unread_notifications': unread,
        'recent_notifications': recent,
        'HAVE_PARAMIKO': HAVE_PARAMIKO,
        'HAVE_KVM': HAVE_KVM,
        'licensed': is_licensed(),
        'csrf_token': csrf_token(),
    }


# ─────────────────────────── Auth helpers ───────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated

def vm_owner_or_admin(f):
    @wraps(f)
    def decorated(vm_id, *args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login'))
        vm_id = safe_vm_id(vm_id)
        if not vm_id:
            flash('Invalid VM id.', 'danger')
            return redirect(url_for('dashboard'))
        v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
        if not v:
            flash('VM not found.', 'danger')
            return redirect(url_for('dashboard'))
        if session.get('role') != 'admin' and v['user_id'] != session['user_id']:
            flash('Access denied.', 'danger')
            return redirect(url_for('dashboard'))
        return f(vm_id, *args, **kwargs)
    return decorated

def get_random_port():
    base = int(gsv('base_ssh_port', 10000))
    used = {r['ssh_port'] for r in (db_execute("SELECT ssh_port FROM vm_instances WHERE ssh_port IS NOT NULL", fetch=True) or [])}
    for _ in range(200):
        p = random.randint(base, base + 2000)
        if p not in used:
            return p
    return base + random.randint(0, 9999)

# ─────────────────────────── VM Manager ───────────────────────────

class VMManager:
    last_start_error = None
    def vm_dir(self, vid):
        vid = safe_vm_id(vid)
        if not vid:
            raise ValueError('Invalid VM id')
        d = (VM_DIR / vid).resolve()
        if not str(d).startswith(str(VM_DIR.resolve())):
            raise ValueError('Path escape blocked')
        d.mkdir(exist_ok=True)
        return d

    def up(self, vid, progress, step):
        db_execute("UPDATE vm_instances SET creation_progress=?, creation_step=? WHERE vm_id=?",
                   (progress, step, vid))

    def download_image(self, vid, ost):
        self.up(vid, 10, 'Downloading OS image...')
        d = self.vm_dir(vid)
        oi = OS_TEMPLATES.get(ost, OS_TEMPLATES['ubuntu-22.04'])
        raw = d / 'disk.img'
        qcow = d / 'disk.qcow2'
        if qcow.exists() and qcow.stat().st_size > 50_000_000:
            self.up(vid, 40, 'Image already present')
            return
        if not raw.exists() or raw.stat().st_size < 10_000_000:
            self.up(vid, 15, f'Downloading {oi["name"]}...')
            subprocess.run(['wget', '-q', '--show-progress', '-O', str(raw), oi['url']], check=False, timeout=1800)
        self.up(vid, 45, 'Converting to qcow2...')
        if qcow.exists():
            qcow.unlink()
        subprocess.run(['qemu-img', 'convert', '-f', 'qcow2', '-O', 'qcow2', str(raw), str(qcow)], check=False)
        if not qcow.exists() or qcow.stat().st_size < 10_000_000:
            # some images are already raw
            subprocess.run(['qemu-img', 'convert', '-O', 'qcow2', str(raw), str(qcow)], check=False)
        self.up(vid, 55, 'Image ready')

    def resize_disk(self, vid, gb):
        self.up(vid, 60, f'Resizing disk to {gb}G...')
        qcow = self.vm_dir(vid) / 'disk.qcow2'
        if qcow.exists():
            subprocess.run(['qemu-img', 'resize', str(qcow), f'{gb}G'], check=False)

    def create_cloud_init(self, vid, ost, hostname, root_pw):
        """Create cloud-init with root + default OS sudo user"""
        d = self.vm_dir(vid)
        seed = d / 'seed.iso'
        self.up(vid, 70, 'Creating cloud-init...')
        tmpl = OS_TEMPLATES.get(ost, OS_TEMPLATES['ubuntu-22.04'])
        default_user = tmpl.get('default_user', 'ubuntu')
        # password for both root and default user
        root_pw = root_pw or tmpl.get('root_pass', 'akvm123')
        user_pw = root_pw

        ud = f"""#cloud-config
hostname: {hostname}
manage_etc_hosts: true
disable_root: false
ssh_pwauth: true
growpart:
  mode: auto
  devices: ['/']
resize_rootfs: true

chpasswd:
  list: |
    root:{root_pw}
    {default_user}:{user_pw}
  expire: false

users:
  - name: root
    lock_passwd: false
    shell: /bin/bash
    sudo: ALL=(ALL) NOPASSWD:ALL
  - name: {default_user}
    lock_passwd: false
    shell: /bin/bash
    sudo: ALL=(ALL) NOPASSWD:ALL
    groups: [sudo, adm]
    ssh_pwauth: true

write_files:
  - path: /etc/ssh/sshd_config.d/akvm.conf
    content: |
      PermitRootLogin yes
      PasswordAuthentication yes
      PubkeyAuthentication yes
      ChallengeResponseAuthentication no
    permissions: '0644'
  - path: /etc/sudoers.d/akvm
    content: |
      {default_user} ALL=(ALL) NOPASSWD:ALL
      root ALL=(ALL) NOPASSWD:ALL
    permissions: '0440'

packages:
  - cloud-guest-utils
  - curl
  - wget
  - git
  - vim
  - htop
  - net-tools
  - openssh-server
  - qemu-guest-agent

bootcmd:
  - echo 'root:{root_pw}' | chpasswd
  - echo '{default_user}:{user_pw}' | chpasswd
  - growpart /dev/vda 1 || growpart /dev/sda 1 || true
  - resize2fs /dev/vda1 || resize2fs /dev/sda1 || true

runcmd:
  - echo 'root:{root_pw}' | chpasswd
  - echo '{default_user}:{user_pw}' | chpasswd
  - growpart /dev/vda 1 || growpart /dev/sda 1 || true
  - resize2fs /dev/vda1 || resize2fs /dev/sda1 || true
  - sed -i 's/^#*PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
  - sed -i 's/^#*PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
  - sed -i 's/^PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
  - systemctl enable ssh 2>/dev/null || true
  - systemctl restart ssh 2>/dev/null || service ssh restart 2>/dev/null || true
  - systemctl enable qemu-guest-agent 2>/dev/null || true
  - systemctl start qemu-guest-agent 2>/dev/null || true
"""
        md = f"instance-id: {vid}\nlocal-hostname: {hostname}\n"
        (d / 'user-data').write_text(ud)
        (d / 'meta-data').write_text(md)
        self.up(vid, 80, 'Generating seed ISO...')
        if seed.exists():
            seed.unlink()
        subprocess.run(['cloud-localds', str(seed), str(d / 'user-data'), str(d / 'meta-data')], check=False)
        return str(seed)

    def start_vm(self, vid, ost, ram, cpu, stor, sp, vp, network_mode='private', public_ip=None, private_ip=None, extra_forwards=None, nested_kvm=False):
        d = self.vm_dir(vid)
        img = d / 'disk.qcow2'
        seed = d / 'seed.iso'
        pf = d / 'qemu.pid'
        self.last_start_error = None
        if not img.exists() or img.stat().st_size < 1_000_000:
            self.last_start_error = 'Disk image missing or incomplete — use Reinstall'
            print(f'[AKVM] {self.last_start_error} ({img})')
            return None
        if not seed.exists():
            self.last_start_error = 'Cloud-init seed.iso missing — use Reinstall'
            print(f'[AKVM] {self.last_start_error}')
            return None
        try:
            vp = int(vp or 0)
        except Exception:
            vp = 0
        if not vp or vp < 1024:
            self.last_start_error = f'Invalid serial port: {vp}'
            return None
        # NOTE: no macvtap/bridge is set up on the host (see README), so a VM
        # with a public_ip is NEVER actually reachable at that address — all
        # guests, public or private, are only reachable via the hostfwd on
        # 127.0.0.1:ssh_port. public_ip is advertised/display-only. So we
        # always free/forward the port, regardless of network_mode.
        ports_to_free = []
        if sp and int(sp) != 22:
            ports_to_free.append(int(sp))
        if extra_forwards:
            for fw in extra_forwards:
                hp = int(fw.get('host_port') or fw.get('host') or 0)
                if hp and hp != 22:
                    ports_to_free.append(hp)
        for port in ports_to_free:
            subprocess.run(['fuser', '-k', f'{port}/tcp'], capture_output=True)
        time.sleep(0.5)
        if pf.exists():
            try:
                os.kill(int(pf.read_text().strip()), signal.SIGKILL)
            except Exception:
                pass
            try:
                pf.unlink()
            except Exception:
                pass
        subprocess.run(['pkill', '-f', f'qemu.*{vid}'], capture_output=True) if is_valid_uuid(vid) else None
        time.sleep(0.5)

        use_kvm = kvm_available()
        nested = bool(nested_kvm) and use_kvm
        accel_args = []
        if use_kvm:
            if nested:
                # Host CPU + nested virtualization flags (guest can use /dev/kvm)
                accel_args = ['-enable-kvm', '-cpu', 'host,+vmx,+svm']
                mode = 'kvm-nested'
            else:
                # KVM accel but common/safe CPU model (not host passthrough)
                accel_args = ['-enable-kvm', '-cpu', 'kvm64']
                mode = 'kvm'
        else:
            accel_args = ['-accel', 'tcg,thread=multi', '-cpu', 'qemu64']
            mode = 'tcg'

        # SSH hostfwd for ALL VMs (public and private/NAT alike). There's no
        # real bridge/macvtap, so hostfwd on 127.0.0.1:sp is the only way in —
        # public_ip is stored/shown to the user but is not itself routable.
        fw_parts = []
        if sp:
            fw_parts.append(f'hostfwd=tcp::{sp}-:22')
        if extra_forwards:
            for fw in extra_forwards:
                hp = int(fw.get('host_port') or fw.get('host') or 0)
                gp = int(fw.get('guest_port') or fw.get('guest') or 0)
                proto = (fw.get('protocol') or 'tcp').lower()
                if hp and gp:
                    fw_parts.append(f'hostfwd={proto}::{hp}-:{gp}')
        if fw_parts:
            netdev = 'user,id=net0,' + ','.join(fw_parts)
        else:
            # Still user-net for outbound; no inbound hostfwd (public IP path)
            netdev = 'user,id=net0'

        # SMBIOS — shows up in neofetch / fastfetch as host manufacturer/product
        mfr = gsv('smbios_manufacturer', 'AKVM') or 'AKVM'
        prod = gsv('smbios_product', 'AKVM Virtual Machine') or 'AKVM Virtual Machine'
        sver = gsv('smbios_version', '1.0') or '1.0'
        smbios = f'type=1,manufacturer={mfr},product={prod},version={sver}'

        qc = [
            'qemu-system-x86_64',
            '-name', vid,
            '-m', str(ram),
            '-smp', str(cpu),
            *accel_args,
            '-display', 'none',
            '-smbios', smbios,
            '-drive', f'file={img},format=qcow2,if=virtio',
            '-drive', f'file={seed},format=raw,if=virtio',
            '-netdev', netdev,
            '-device', 'virtio-net-pci,netdev=net0',
            '-serial', f'telnet:127.0.0.1:{vp},server,nowait',
            '-daemonize',
            '-pidfile', str(pf)
        ]
        try:
            db_execute("UPDATE vm_instances SET accel_mode=? WHERE vm_id=?", (mode, vid))
        except Exception:
            pass

        log = d / 'qemu.log'
        try:
            with open(log, 'w') as lf:
                proc = subprocess.Popen(qc, stdout=lf, stderr=subprocess.STDOUT)
                proc.wait(timeout=15)
        except FileNotFoundError:
            self.last_start_error = 'qemu-system-x86_64 not found — run: sudo apt install -y qemu-system-x86'
            print('[AKVM]', self.last_start_error)
            return None
        except Exception as e:
            self.last_start_error = f'qemu launch error: {e}'
            print('[AKVM]', self.last_start_error)
            return None
        for i in range(20):
            if pf.exists():
                try:
                    pid = int(pf.read_text().strip())
                    os.kill(pid, 0)
                    return pid
                except Exception:
                    pass
            time.sleep(0.5)
        try:
            r = subprocess.run(['pgrep', '-f', f'qemu.*{vid}'], capture_output=True, text=True) if is_valid_uuid(vid) else type('R', (), {'stdout': '', 'returncode': 1})()
            if r.stdout.strip():
                pid = int(r.stdout.strip().split('\n')[0])
                pf.write_text(str(pid))
                return pid
        except Exception:
            pass
        # Read qemu log for reason
        err = ''
        try:
            if log.exists():
                err = log.read_text(errors='replace')[-500:].strip()
        except Exception:
            pass
        self.last_start_error = err or 'QEMU exited without pidfile (port busy, bad disk, or missing KVM?)'
        print('[AKVM] start failed:', self.last_start_error)
        return None


    def stop_vm(self, pid, sp=None):
        if sp and int(sp) != 22:
            subprocess.run(['fuser', '-k', f'{sp}/tcp'], capture_output=True)
        if not pid:
            return True
        try:
            os.kill(pid, signal.SIGTERM)
            time.sleep(2)
        except Exception:
            pass
        try:
            os.kill(pid, signal.SIGKILL)
        except Exception:
            pass
        return True

    def vm_status(self, vid):
        pf = self.vm_dir(vid) / 'qemu.pid'
        if pf.exists():
            try:
                pid = int(pf.read_text().strip())
                os.kill(pid, 0)
                return True, pid
            except Exception:
                try:
                    pf.unlink()
                except Exception:
                    pass
        try:
            r = subprocess.run(['pgrep', '-f', f'qemu.*{vid}'], capture_output=True, text=True) if is_valid_uuid(vid) else type('R', (), {'stdout': '', 'returncode': 1})()
            if r.stdout.strip():
                pid = int(r.stdout.strip().split('\n')[0])
                pf.write_text(str(pid))
                return True, pid
        except Exception:
            pass
        return False, None

    def vm_metrics(self, pid):
        if not pid:
            return None
        try:
            p = psutil.Process(pid)
            mem = p.memory_info()
            return {
                'cpu': round(p.cpu_percent(interval=0.5), 1),
                'ram_mb': round(mem.rss / (1024 * 1024), 0),
                'threads': p.num_threads(),
                'uptime': str(datetime.now() - datetime.fromtimestamp(p.create_time())).split('.')[0]
            }
        except Exception:
            return None

    def ssh_exec(self, sp, cmd, password='', user='root', timeout=30, host='127.0.0.1'):
        try:
            sp = safe_int(sp, 0, 1, 65535)
            if not sp:
                return "Invalid port"
            user = re.sub(r'[^\w.-]', '', user or 'root')[:32]
            host = host or '127.0.0.1'
            # Never use shell=True — password/cmd injection safe argv list
            r = subprocess.run(
                ['sshpass', '-p', str(password or ''), 'ssh',
                 '-o', 'StrictHostKeyChecking=no',
                 '-o', 'UserKnownHostsFile=/dev/null',
                 '-o', 'ConnectTimeout=8',
                 '-p', str(sp), f'{user}@{host}', str(cmd or '')],
                capture_output=True, text=True, timeout=timeout
            )
            return r.stdout if r.returncode == 0 else (r.stderr or r.stdout or "Command failed")
        except Exception as e:
            return f"Connection failed: {e}"

    def setup_tmate(self, vid, sp, password='', host='127.0.0.1'):
        self.last_share_error = None
        host = host or '127.0.0.1'
        try:
            ready = False
            for i in range(40):
                r = subprocess.run(
                    ['sshpass', '-p', password, 'ssh', '-o', 'StrictHostKeyChecking=no',
                     '-o', 'UserKnownHostsFile=/dev/null', '-o', 'ConnectTimeout=3',
                     '-p', str(sp), f'root@{host}', 'echo READY'],
                    capture_output=True, text=True, timeout=10)
                if 'READY' in (r.stdout or ''):
                    ready = True
                    break
                time.sleep(2)
            if not ready:
                self.last_share_error = 'VM SSH not reachable yet (still booting or SSH not up) — wait a bit and retry.'
                return None
            sn = f'/tmp/tmate-{uuid.uuid4().hex[:8]}.sock'
            remote = (
                f'(apt-get update -qq && apt-get install -y -qq tmate) >/tmp/tmate_install.log 2>&1; '
                f'tmate -S {sn} new-session -d 2>>/tmp/tmate_install.log; sleep 4; '
                f'tmate -S {sn} display -p "#{{tmate_ssh}}" 2>>/tmp/tmate_install.log; echo ---; '
                f'tmate -S {sn} display -p "#{{tmate_web}}" 2>>/tmp/tmate_install.log; echo ---; '
                f'which tmate >/dev/null 2>&1 && echo TMATE_OK || echo TMATE_MISSING; '
                f'tail -c 400 /tmp/tmate_install.log'
            )
            r = subprocess.run(
                ['sshpass', '-p', str(password or ''), 'ssh',
                 '-o', 'StrictHostKeyChecking=no', '-o', 'UserKnownHostsFile=/dev/null',
                 '-p', str(safe_int(sp, 0, 1, 65535)), f'root@{host}', remote],
                capture_output=True, text=True, timeout=150
            )
            out = r.stdout or ''
            if '---' in out:
                pts = out.split('---')
                ssh = pts[0].strip() if len(pts) > 0 else None
                web = pts[1].strip() if len(pts) > 1 else None
                if ssh or web:
                    db_execute("UPDATE vm_instances SET tmate_ssh=?, tmate_web=? WHERE vm_id=?",
                               (ssh, web, vid))
                    return {'ssh': ssh, 'web': web}
                tail = pts[2].strip() if len(pts) > 2 else ''
                if 'TMATE_MISSING' in tail or not tail:
                    self.last_share_error = ('Could not install/start tmate inside the VM — check the guest '
                                              'has outbound internet (apt) access. Log tail: ' + tail[-300:])
                else:
                    self.last_share_error = 'tmate started but produced no session string. Log tail: ' + tail[-300:]
            else:
                self.last_share_error = 'No response from VM over SSH while setting up tmate.'
        except subprocess.TimeoutExpired:
            self.last_share_error = 'tmate setup timed out (apt install / session start took too long).'
        except Exception as e:
            self.last_share_error = f'tmate setup error: {e}'
        return None

    def setup_sshx(self, vid, sp, password='', host='127.0.0.1'):
        """Launch an sshx.io shared web-terminal session inside the VM and
        return its shareable URL. Different from tmate: sshx gives a single
        clickable link (no separate SSH string) with live multi-cursor sharing."""
        self.last_share_error = None
        host = host or '127.0.0.1'
        try:
            ready = False
            for i in range(40):
                r = subprocess.run(
                    ['sshpass', '-p', password, 'ssh', '-o', 'StrictHostKeyChecking=no',
                     '-o', 'UserKnownHostsFile=/dev/null', '-o', 'ConnectTimeout=3',
                     '-p', str(sp), f'root@{host}', 'echo READY'],
                    capture_output=True, text=True, timeout=10)
                if 'READY' in (r.stdout or ''):
                    ready = True
                    break
                time.sleep(2)
            if not ready:
                self.last_share_error = 'VM SSH not reachable yet (still booting or SSH not up) — wait a bit and retry.'
                return None
            remote = (
                'which sshx >/dev/null 2>&1 || curl -sSf https://sshx.io/get | sh >/tmp/sshx_install.log 2>&1; '
                'export PATH="$HOME/.local/bin:$PATH"; '
                'pkill -9 -f "sshx$" >/dev/null 2>&1; sleep 2; '
                'nohup sshx >/tmp/sshx_output.log 2>&1 & '
                'sleep 6; cat /tmp/sshx_output.log; echo ---LOG---; '
                'which sshx >/dev/null 2>&1 && echo SSHX_OK || echo SSHX_MISSING; '
                'tail -c 400 /tmp/sshx_install.log 2>/dev/null'
            )
            r = subprocess.run(
                ['sshpass', '-p', str(password or ''), 'ssh',
                 '-o', 'StrictHostKeyChecking=no', '-o', 'UserKnownHostsFile=/dev/null',
                 '-p', str(safe_int(sp, 0, 1, 65535)), f'root@{host}', remote],
                capture_output=True, text=True, timeout=90
            )
            full = (r.stdout or '') + (r.stderr or '')
            m = re.search(r'https://sshx\.io/s/\S+', full)
            if m:
                url = m.group(0)
                db_execute("UPDATE vm_instances SET sshx_url=? WHERE vm_id=?", (url, vid))
                return {'url': url}
            if 'SSHX_MISSING' in full:
                install_log = full.split('---LOG---')[-1] if '---LOG---' in full else full
                self.last_share_error = ('Could not install sshx inside the VM — check the guest has '
                                          'outbound internet access to sshx.io. Log tail: ' + install_log[-300:])
            else:
                self.last_share_error = 'sshx started but no shareable URL was returned. Output: ' + full[-300:]
        except subprocess.TimeoutExpired:
            self.last_share_error = 'sshx setup timed out (install / session start took too long).'
        except Exception as e:
            self.last_share_error = f'sshx setup error: {e}'
        return None

vm = VMManager()

def complete_vm_setup(vid, ost, ram, cpu, stor, sp, vp, network_mode='private', public_ip=None, private_ip=None):
    try:
        vrow = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vid,), fetchone=True)
        root_pw = (vrow['ssh_password'] if vrow and vrow['ssh_password'] else None) or generate_vm_password()
        if vrow and not vrow['ssh_password']:
            db_execute("UPDATE vm_instances SET ssh_password=? WHERE vm_id=?", (root_pw, vid))
        tmpl = OS_TEMPLATES.get(ost, OS_TEMPLATES['ubuntu-22.04'])
        hostname = f'akvm-{vid[:8]}'
        # Port forwards for this VM
        fws = db_execute("SELECT host_port, guest_port, protocol FROM port_forwards WHERE vm_id=?", (vid,), fetch=True) or []
        extra = [dict(r) for r in fws]
        vm.up(vid, 5, 'Preparing workspace…')
        vm.download_image(vid, ost)
        vm.up(vid, 60, 'Resizing disk…')
        vm.resize_disk(vid, stor)
        vm.up(vid, 70, 'Building cloud-init seed…')
        vm.create_cloud_init(vid, ost, hostname, root_pw)
        vm.up(vid, 85, 'Starting QEMU…')
        nested = False
        if vrow:
            try:
                nested = bool(vrow['nested_kvm'])
            except Exception:
                nested = False
        pid = vm.start_vm(vid, ost, ram, cpu, stor, sp, vp, network_mode, public_ip, private_ip, extra, nested)
        if pid:
            db_execute("UPDATE vm_instances SET status='running', pid=?, creation_progress=100, "
                       "ssh_user=?, ssh_password=?, creation_step=?, creation_progress=100 WHERE vm_id=?",
                       (pid, 'root', root_pw, 'Ready — VM is running', vid))
            v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vid,), fetchone=True)
            if v:
                add_notification(v['user_id'], 'VM Ready!',
                                 f'VM "{v["name"]}" is running. SSH port: {sp}', 'success')
        else:
            time.sleep(3)
            pid = vm.start_vm(vid, ost, ram, cpu, stor, sp, vp, network_mode, public_ip, private_ip, extra, nested)
            if pid:
                db_execute("UPDATE vm_instances SET status='running', pid=?, creation_progress=100, "
                           "ssh_password=? WHERE vm_id=?",
                           (pid, root_pw, vid))
            else:
                db_execute("UPDATE vm_instances SET status='stopped', creation_progress=100, "
                           "creation_step=? WHERE vm_id=?", ('Failed to start', vid))
        if pid:
            time.sleep(15)
            try:
                vm.ssh_exec(sp, 'growpart /dev/vda 1 || growpart /dev/sda 1 || true; '
                            'resize2fs /dev/vda1 || resize2fs /dev/sda1 || true',
                            password=root_pw)
            except Exception:
                pass
    except Exception as e:
        db_execute("UPDATE vm_instances SET status='error', creation_step=? WHERE vm_id=?",
                   (str(e)[:200], vid))


# ─────────────────────────── Auth routes ───────────────────────────

@app.route('/license', methods=['GET', 'POST'])
def license_page():
    if is_licensed():
        return redirect(url_for('index'))
    if request.method == 'POST':
        ip = request.headers.get('X-Forwarded-For', request.remote_addr or 'unknown').split(',')[0].strip()
        if not rate_limit(f'license:{ip}', limit=10, window=120):
            flash('Too many attempts. Try again later.', 'danger')
            return render_template('license.html', install_id=_license_install_id()), 429
        key = request.form.get('license_key', '').strip()[:128]
        if activate_license(key):
            try:
                audit(session.get('user_id'), 'license_activate', 'License activated')
            except Exception:
                pass
            flash('License activated successfully!', 'success')
            return redirect(url_for('index'))
        flash('Invalid license key for this install. Check and try again.', 'danger')
    return render_template('license.html', install_id=_license_install_id())

@app.route('/admin/license', methods=['GET', 'POST'])
@admin_required
def admin_license():
    if request.method == 'POST':
        action = request.form.get('action', '')
        if action == 'deactivate':
            deactivate_license()
            audit(session['user_id'], 'license_deactivate', 'License deactivated')
            flash('License deactivated.', 'info')
            return redirect(url_for('license_page'))
        return redirect(url_for('admin_license'))
    return render_template('admin/license.html',
                           licensed=is_licensed(),
                           activated_at=gsv('license_activated_at', ''),
                           install_id=_license_install_id(),
                           check_status=_license_check_status)


@app.route('/')
def index():
    if session.get('user_id'):
        if session.get('role') == 'admin':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('dashboard'))
    return render_template('landing.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if session.get('user_id'):
        return redirect(url_for('index'))
    if request.method == 'POST':
        ip = request.headers.get('X-Forwarded-For', request.remote_addr or 'unknown').split(',')[0].strip()
        if not rate_limit(f'login:{ip}', limit=8, window=60):
            flash('Too many login attempts. Wait a minute.', 'danger')
            return render_template('login.html'), 429
        u = request.form.get('username', '').strip()[:64]
        p = request.form.get('password', '')
        user = db_execute("SELECT * FROM users WHERE username=? AND is_active=1", (u,), fetchone=True)
        if user and check_password_hash(user['password'], p):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            db_execute("UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?", (user['id'],))
            audit(user['id'], 'login', f'Login from {request.remote_addr}')
            flash(f'Welcome, {user["username"]}!', 'success')
            return redirect(url_for('index'))
        flash('Invalid username or password.', 'danger')
    return render_template('login.html', discord_oauth_enabled=(gsv('discord_oauth_enabled', 'false') or 'false').lower() in ('1', 'true', 'yes'))

@app.route('/login/discord')
def login_discord():
    if session.get('user_id'):
        return redirect(url_for('index'))
    client_id = (gsv('discord_oauth_client_id', '') or '').strip()
    if not client_id or (gsv('discord_oauth_enabled', 'false') or 'false').lower() not in ('1', 'true', 'yes'):
        flash('Discord login is not configured.', 'danger')
        return redirect(url_for('login'))
    state = secrets.token_urlsafe(24)
    session['_discord_oauth_state'] = state
    redirect_uri = url_for('login_discord_callback', _external=True)
    params = urllib.parse.urlencode({
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'response_type': 'code',
        'scope': 'identify',
        'state': state,
    })
    return redirect(f'https://discord.com/api/oauth2/authorize?{params}')

@app.route('/login/discord/callback')
def login_discord_callback():
    if session.get('user_id'):
        return redirect(url_for('index'))
    error = request.args.get('error')
    if error:
        flash('Discord login was cancelled or failed.', 'danger')
        return redirect(url_for('login'))
    code = request.args.get('code', '')
    state = request.args.get('state', '')
    if not code or not state or state != session.pop('_discord_oauth_state', None):
        flash('Discord login failed (invalid state). Please try again.', 'danger')
        return redirect(url_for('login'))

    client_id = (gsv('discord_oauth_client_id', '') or '').strip()
    client_secret = (gsv('discord_oauth_client_secret', '') or '').strip()
    if not client_id or not client_secret:
        flash('Discord login is not configured.', 'danger')
        return redirect(url_for('login'))

    redirect_uri = url_for('login_discord_callback', _external=True)
    ip = request.headers.get('X-Forwarded-For', request.remote_addr or 'unknown').split(',')[0].strip()
    if not rate_limit(f'discord_oauth:{ip}', limit=10, window=120):
        flash('Too many attempts. Try again later.', 'danger')
        return redirect(url_for('login'))

    try:
        token_data = urllib.parse.urlencode({
            'client_id': client_id,
            'client_secret': client_secret,
            'grant_type': 'authorization_code',
            'code': code,
            'redirect_uri': redirect_uri,
        }).encode('utf-8')
        req = urllib.request.Request(
            'https://discord.com/api/oauth2/token', data=token_data,
            headers={'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'AKVM-Panel-OAuth'}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            token_json = json.loads(resp.read().decode('utf-8'))
        access_token = token_json.get('access_token')
        if not access_token:
            raise ValueError('No access token returned')

        req2 = urllib.request.Request(
            'https://discord.com/api/users/@me',
            headers={'Authorization': f'Bearer {access_token}', 'User-Agent': 'AKVM-Panel-OAuth'}
        )
        with urllib.request.urlopen(req2, timeout=10) as resp2:
            discord_user = json.loads(resp2.read().decode('utf-8'))
        discord_id = str(discord_user.get('id', ''))
    except Exception as e:
        flash(f'Discord login failed: {e}', 'danger')
        return redirect(url_for('login'))

    if not discord_id:
        flash('Could not verify your Discord account.', 'danger')
        return redirect(url_for('login'))

    user = db_execute("SELECT * FROM users WHERE discord_id=? AND is_active=1", (discord_id,), fetchone=True)
    if not user:
        flash("No AKVM account is linked to this Discord account yet. Run akvm!register in Discord first, then try again.", 'danger')
        return redirect(url_for('login'))

    session['user_id'] = user['id']
    session['username'] = user['username']
    session['role'] = user['role']
    db_execute("UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?", (user['id'],))
    audit(user['id'], 'login_discord', f'Discord OAuth login from {request.remote_addr}')
    flash(f'Welcome, {user["username"]}!', 'success')
    return redirect(url_for('index'))

@app.route('/logout')
def logout():
    if session.get('user_id'):
        audit(session['user_id'], 'logout')
    session.clear()
    flash('Logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if session.get('user_id'):
        return redirect(url_for('index'))
    if request.method == 'POST':
        ip = request.headers.get('X-Forwarded-For', request.remote_addr or 'unknown').split(',')[0].strip()
        if not rate_limit(f'register:{ip}', limit=5, window=300):
            flash('Too many registrations from this IP.', 'danger')
            return render_template('register.html'), 429
        u = request.form.get('username', '').strip()
        e = request.form.get('email', '').strip()
        p = request.form.get('password', '')
        p2 = request.form.get('password2', '')
        if not u or not e or not p:
            flash('All fields are required.', 'warning')
            return render_template('register.html')
        if len(u) < 3:
            flash('Username must be at least 3 characters.', 'warning')
            return render_template('register.html')
        if len(p) < 4:
            flash('Password must be at least 4 characters.', 'warning')
            return render_template('register.html')
        if p != p2:
            flash('Passwords do not match.', 'danger')
            return render_template('register.html')
        try:
            db_execute(
                "INSERT INTO users (username, email, password, role) VALUES (?,?,?,?)",
                (u, e, generate_password_hash(p, method='scrypt'), 'user')
            )
            audit(None, 'register', f'New user {u}')
            flash('Account created! You can sign in now.', 'success')
            return redirect(url_for('login'))
        except Exception:
            flash('Username or email already exists.', 'danger')
            return render_template('register.html')
    return render_template('register.html')

# ─────────────────────────── User dashboard ───────────────────────────

@app.route('/dashboard')
@login_required
def dashboard():
    # Available to all users including admins (their assigned VMs)
    vms = db_execute("SELECT * FROM vm_instances WHERE user_id=? ORDER BY created_at DESC",
                     (session['user_id'],), fetch=True) or []
    notifs = db_execute("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 10",
                        (session['user_id'],), fetch=True) or []
    vl = []
    for v in vms:
        d = dict(v)
        r, _ = vm.vm_status(v['vm_id'])
        d['real_status'] = 'running' if r else ('creating' if v['status'] == 'creating' else 'stopped')
        vl.append(d)
    running_count = sum(1 for x in vl if x.get('real_status') == 'running')
    return render_template('dashboard.html', vms=vl, notifications=notifs, running_count=running_count)

# ─────────────────────────── VM routes ───────────────────────────

@app.route('/vm/create', methods=['GET', 'POST'])
@admin_required
def create_vm():
    if request.method == 'POST':
        name = sanitize_name(request.form.get('name', ''), 64)
        ost = request.form.get('os_template', 'ubuntu-22.04')
        try:
            ram = safe_int(request.form.get('ram_mb', 2048), 2048, 256, 262144)
            cpu = safe_int(request.form.get('cpu_cores', 2), 2, 1, 128)
            stor = safe_int(request.form.get('storage_gb', 20), 20, 5, 10000)
            uid = safe_int(request.form.get('user_id', session['user_id']), session['user_id'], 1, None)
        except Exception:
            flash('Invalid resource values.', 'danger')
            return redirect(url_for('create_vm'))
        uref = db_execute("SELECT id FROM users WHERE id=? AND is_active=1", (uid,), fetchone=True)
        if not uref:
            flash('Selected user is invalid.', 'danger')
            return redirect(url_for('create_vm'))
        network_mode = request.form.get('network_mode', 'private')
        public_ip_id = request.form.get('public_ip_id', '').strip()
        node_id = request.form.get('node_id', '').strip()
        # Always generate a unique password
        root_pw = generate_vm_password(12)

        if not name:
            flash('VM name required.', 'warning')
            return redirect(url_for('create_vm'))
        if ost not in OS_TEMPLATES:
            flash('Invalid OS template.', 'danger')
            return redirect(url_for('create_vm'))

        vid = str(uuid.uuid4())
        # SSH host port always auto-assigned (never asked)
        sp = allocate_host_port()
        # Serial console port (QEMU telnet) — separate from SSH
        vp = allocate_host_port()

        nid = int(node_id) if node_id else ensure_local_node()
        if not nid:
            nid = ensure_local_node()

        assigned_ip = None
        private_ip = None
        if network_mode == 'public' and public_ip_id:
            pip = db_execute("SELECT * FROM public_ips WHERE id=? AND is_available=1",
                             (int(public_ip_id),), fetchone=True)
            if pip:
                assigned_ip = pip['ip_address']
                db_execute("UPDATE public_ips SET is_available=0, assigned_vm_id=? WHERE id=?",
                           (vid, pip['id']))
            else:
                flash('Selected public IP is no longer available. Using private NAT mode.', 'warning')
                network_mode = 'private'

        if network_mode == 'private':
            private_ip = allocate_private_ip()
        else:
            # Public IP: SSH is on :22 of the public address — no NAT host port
            sp = 22
            private_ip = None

        ssh_host = assigned_ip or PUBLIC_IP

        # Guest ports only for private/NAT VMs — host ports auto-assigned.
        max_nat = int(gsv('max_nat_ports_per_vm', 5) or 5)
        guest_ports_raw = request.form.get('guest_ports', '').strip() if network_mode == 'private' else ''
        extra_list = []
        if guest_ports_raw:
            seen_gp = set()
            for part in guest_ports_raw.replace(' ', '').split(','):
                if len(extra_list) >= max_nat:
                    flash(f'Max {max_nat} NAT ports per VM — extra ports ignored.', 'warning')
                    break
                try:
                    gp = int(part.split(':')[-1])  # allow accidental host:guest form, take guest
                    if gp < 1 or gp > 65535 or gp in seen_gp or gp == 22:
                        continue
                    seen_gp.add(gp)
                    hp = allocate_host_port()
                    extra_list.append({'host_port': hp, 'guest_port': gp, 'protocol': 'tcp'})
                except ValueError:
                    pass

        nested_kvm = 1 if request.form.get('nested_kvm') == 'on' else 0
        if nested_kvm and not HAVE_KVM:
            flash('Nested KVM requested but host has no KVM — using TCG.', 'warning')
            nested_kvm = 0

        db_execute(
            "INSERT INTO vm_instances "
            "(vm_id, user_id, name, os_template, ram_mb, cpu_cores, storage_gb, "
            "ssh_port, ssh_host, ssh_user, ssh_password, network_mode, public_ip, "
            "private_ip, node_id, vnc_port, serial_port, status, creation_step, creation_progress, accel_mode, nested_kvm) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (vid, uid, name, ost, ram, cpu, stor, sp, ssh_host, 'root', root_pw,
             network_mode, assigned_ip, private_ip, nid, vp, vp, 'creating', 'Queued — starting install…', 1,
             'kvm' if HAVE_KVM else 'tcg', nested_kvm)
        )
        for fw in extra_list:
            try:
                db_execute(
                    "INSERT INTO port_forwards (vm_id, host_port, guest_port, protocol, label) VALUES (?,?,?,?,?)",
                    (vid, fw['host_port'], fw['guest_port'], 'tcp', f"{fw['host_port']}->{fw['guest_port']}")
                )
            except Exception:
                pass

        add_notification(uid, 'VM Creating...', f'VM "{name}" – SSH port: {sp}', 'info')
        audit(session['user_id'], 'create_vm', f'Created VM {name} ({vid[:8]}) on node {nid}')
        threading.Thread(target=complete_vm_setup,
                         args=(vid, ost, ram, cpu, stor, sp, vp, network_mode, assigned_ip, private_ip),
                         daemon=True).start()
        flash(f'VM "{name}" is being created!', 'success')
        return redirect(url_for('vm_installing', vm_id=vid))

    users = db_execute("SELECT id, username FROM users WHERE is_active=1 ORDER BY username", fetch=True) or []
    public_ips = db_execute("SELECT * FROM public_ips WHERE is_available=1 ORDER BY ip_address", fetch=True) or []
    nodes = db_execute("SELECT * FROM nodes ORDER BY is_local DESC, name", fetch=True) or []
    return render_template('create_vm.html',
                           os_templates=OS_TEMPLATES,
                           users=users,
                           public_ips=public_ips,
                           nodes=nodes,
                           have_kvm=HAVE_KVM)


@app.route('/vm/<vm_id>/progress')
@login_required
@vm_owner_or_admin
def vm_progress(vm_id):
    v = db_execute("SELECT vm_id, name, status, creation_progress, creation_step, created_at FROM vm_instances WHERE vm_id=?",
                   (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False}), 404
    running, pid = vm.vm_status(vm_id)
    prog = int(v['creation_progress'] or 0)
    step = v['creation_step'] or 'Pending'
    status = v['status'] or 'creating'
    if running and status == 'creating':
        status = 'running'
        prog = max(prog, 100)
    return jsonify({
        'success': True,
        'vm_id': v['vm_id'],
        'name': v['name'],
        'status': status,
        'progress': prog,
        'step': step,
        'running': running,
        'done': status in ('running', 'stopped', 'error') and prog >= 100,
        'error': status == 'error',
    })

@app.route('/vm/<vm_id>/installing')
@login_required
@vm_owner_or_admin
def vm_installing(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        flash('VM not found.', 'danger')
        return redirect(url_for('dashboard'))
    # If already ready, go to manage
    if v['status'] in ('running', 'stopped') and int(v['creation_progress'] or 0) >= 100:
        return redirect(url_for('manage_vm', vm_id=vm_id))
    return render_template('installing.html', vm=v)

@app.route('/vm/<vm_id>/manage')
@login_required
@vm_owner_or_admin
def manage_vm(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if v and v['status'] == 'creating' and int(v['creation_progress'] or 0) < 100:
        return redirect(url_for('vm_installing', vm_id=vm_id))
    r, pid = vm.vm_status(vm_id)
    m = vm.vm_metrics(pid) if r else None
    tmpl = OS_TEMPLATES.get(v['os_template'], {})
    fws = db_execute("SELECT * FROM port_forwards WHERE vm_id=? ORDER BY host_port", (vm_id,), fetch=True) or []
    node = None
    if v and v['node_id']:
        node = db_execute("SELECT * FROM nodes WHERE id=?", (v['node_id'],), fetchone=True)
    return render_template('manage_vm.html', vm=v, is_running=r, metrics=m,
                           default_user=tmpl.get('default_user', 'ubuntu'),
                           port_forwards=fws, node=node)

@app.route('/vm/<vm_id>/security-scan', methods=['POST'])
@login_required
@vm_owner_or_admin
def vm_security_scan(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'ok': False, 'error': 'VM not found'}), 404
    running, _ = vm.vm_status(vm_id)
    if not running:
        return jsonify({'ok': False, 'error': 'VM is not running.'}), 400
    scan = scan_vm_for_threats(v)
    if scan['ok']:
        audit(session.get('user_id'), 'security_scan',
              f"{v['name']}: miner={scan['miner_detected']}, failed_logins={scan['failed_logins']}")
        if scan['miner_detected'] or scan['failed_logins'] > 20 or scan['suspicious_cron']:
            try:
                db_execute(
                    "INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)",
                    (v['user_id'], 'Security scan flagged issues on ' + v['name'], scan_summary_text(scan), 'warning')
                )
            except Exception:
                pass
    return jsonify({'ok': scan['ok'], 'error': scan.get('error'),
                    'miner_detected': scan['miner_detected'],
                    'matched_processes': scan['matched_processes'],
                    'failed_logins': scan['failed_logins'],
                    'suspicious_files': scan['suspicious_files'],
                    'suspicious_cron': scan['suspicious_cron'],
                    'summary': scan_summary_text(scan)})

@app.route('/vm/<vm_id>/terminal')
@login_required
@vm_owner_or_admin
def terminal(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    r, _ = vm.vm_status(vm_id)
    return render_template('terminal.html', vm=v, is_running=r)

@app.route('/vm/<vm_id>/console')
@login_required
@vm_owner_or_admin
def console(vm_id):
    """Web console – SSH shell + QEMU serial info"""
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    r, pid = vm.vm_status(vm_id)
    return render_template('console.html', vm=v, is_running=r)

@app.route('/vm/<vm_id>/hostname', methods=['POST'])
@login_required
@vm_owner_or_admin
def change_hostname(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False, 'message': 'VM not found'})
    new_hostname = request.json.get('hostname', '').strip()
    if not new_hostname:
        return jsonify({'success': False, 'message': 'Hostname required'})
    pw = v['ssh_password'] or ''
    output = vm.ssh_exec(v['ssh_port'],
                         f"hostnamectl set-hostname {new_hostname} 2>/dev/null || "
                         f"hostname {new_hostname}; echo {new_hostname} > /etc/hostname",
                         password=pw)
    if 'Connection failed' not in output:
        return jsonify({'success': True, 'message': f'Hostname changed to: {new_hostname}'})
    return jsonify({'success': False, 'message': 'Failed. Is VM running?'})


@app.route('/vm/<vm_id>/terminal/connect', methods=['POST'])
@login_required
@vm_owner_or_admin
def terminal_connect(vm_id):
    if not HAVE_PARAMIKO:
        return jsonify({'success': False, 'message': 'paramiko not installed'})
    _reap_stale_terminal_sessions()
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False, 'message': 'VM not found'})
    running, _ = vm.vm_status(vm_id)
    if not running:
        return jsonify({'success': False, 'message': 'VM is not running. Start it first.'})
    data = request.json or {}
    username = data.get('username') or (v['ssh_user'] if v else 'root') or 'root'
    password = data.get('password') or (v['ssh_password'] if v else '') or ''
    # public_ip is display-only (no real bridge on this host — see README);
    # the guest is only actually reachable via the hostfwd on 127.0.0.1:ssh_port.
    ssh_host = data.get('host') or '127.0.0.1'
    port = int(data.get('port', v['ssh_port'] if v else 22))

    last_err = None
    for attempt in range(8):
        try:
            # Wait until TCP accepts
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            try:
                sock.connect((ssh_host, port))
            except Exception as e:
                sock.close()
                last_err = f'Port closed ({e})'
                time.sleep(2)
                continue
            sock.close()

            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(
                ssh_host, port=port, username=username, password=password,
                look_for_keys=False, allow_agent=False, timeout=20,
                banner_timeout=30, auth_timeout=20
            )
            init_cols = max(10, min(500, int(data.get('cols', 140) or 140)))
            init_rows = max(5, min(200, int(data.get('rows', 40) or 40)))
            channel = ssh.invoke_shell(term='xterm-256color', width=init_cols, height=init_rows)
            channel.settimeout(0.1)
            session_id = str(uuid.uuid4())
            terminal_sessions[session_id] = {
                'ssh': ssh, 'channel': channel, 'created': time.time(), 'last_active': time.time(),
                'user_id': session.get('user_id'), 'vm_id': vm_id,
                'decoder': codecs.getincrementaldecoder('utf-8')(errors='replace'),
            }
            time.sleep(0.4)
            output = ''
            try:
                raw = b''
                for _ in range(10):
                    if channel.recv_ready():
                        raw += channel.recv(8192)
                    time.sleep(0.08)
                output = terminal_sessions[session_id]['decoder'].decode(raw)
            except Exception:
                pass
            return jsonify({'success': True, 'session': session_id, 'output': output})
        except Exception as e:
            last_err = str(e)
            time.sleep(2)
    return jsonify({
        'success': False,
        'message': f'SSH not ready yet: {last_err}. Wait for cloud-init/SSH to finish, then retry.'
    })


@app.route('/vm/<vm_id>/terminal/read', methods=['POST'])
@login_required
@vm_owner_or_admin
def terminal_read(vm_id):
    data = request.json or {}
    session_id = data.get('session')
    if session_id not in terminal_sessions:
        return jsonify({'output': '', 'closed': True})
    sess = terminal_sessions[session_id]
    if sess.get('user_id') != session.get('user_id') or sess.get('vm_id') != safe_vm_id(vm_id):
        return jsonify({'output': '', 'closed': True, 'error': 'forbidden'}), 403
    sess['last_active'] = time.time()
    channel = sess['channel']
    if 'decoder' not in sess:
        sess['decoder'] = codecs.getincrementaldecoder('utf-8')(errors='replace')
    output = ''
    try:
        raw = b''
        for _ in range(5):
            if channel.recv_ready():
                raw += channel.recv(8192)
            time.sleep(0.04)
        output = sess['decoder'].decode(raw)
        if channel.closed:
            try:
                sess['ssh'].close()
            except Exception:
                pass
            del terminal_sessions[session_id]
            return jsonify({'output': output, 'closed': True})
    except Exception:
        try:
            sess['ssh'].close()
        except Exception:
            pass
        if session_id in terminal_sessions:
            del terminal_sessions[session_id]
        return jsonify({'output': '', 'closed': True})
    return jsonify({'output': output, 'closed': False})

@app.route('/vm/<vm_id>/terminal/send', methods=['POST'])
@login_required
@vm_owner_or_admin
def terminal_send(vm_id):
    data = request.json or {}
    session_id = data.get('session')
    text = data.get('data', '')
    if not isinstance(text, str):
        return jsonify({'success': False})
    if len(text) > 8192:
        text = text[:8192]
    if session_id not in terminal_sessions:
        return jsonify({'success': False})
    sess = terminal_sessions[session_id]
    if sess.get('user_id') != session.get('user_id') or sess.get('vm_id') != safe_vm_id(vm_id):
        return jsonify({'success': False, 'error': 'forbidden'}), 403
    sess['last_active'] = time.time()
    try:
        sess['channel'].send(text)
        return jsonify({'success': True})
    except Exception:
        return jsonify({'success': False})

@app.route('/vm/<vm_id>/terminal/resize', methods=['POST'])
@login_required
@vm_owner_or_admin
def terminal_resize(vm_id):
    data = request.json or {}
    session_id = data.get('session')
    try:
        cols = max(10, min(500, int(data.get('cols', 80))))
        rows = max(5, min(200, int(data.get('rows', 24))))
    except (TypeError, ValueError):
        return jsonify({'success': False})
    if session_id not in terminal_sessions:
        return jsonify({'success': False})
    sess = terminal_sessions[session_id]
    if sess.get('user_id') != session.get('user_id') or sess.get('vm_id') != safe_vm_id(vm_id):
        return jsonify({'success': False, 'error': 'forbidden'}), 403
    try:
        sess['channel'].resize_pty(width=cols, height=rows)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/vm/<vm_id>/terminal/disconnect', methods=['POST'])
@login_required
@vm_owner_or_admin
def terminal_disconnect(vm_id):
    """Explicitly close a shell session's SSH connection. Called when the
    user clicks Disconnect, so the paramiko client + channel on the host
    is freed immediately instead of sitting idle until the reaper (up to
    TERMINAL_SESSION_IDLE_LIMIT later) or the server closes it for us."""
    data = request.json or {}
    session_id = data.get('session')
    if not session_id or session_id not in terminal_sessions:
        return jsonify({'success': True})  # already gone — nothing to do
    sess = terminal_sessions[session_id]
    if sess.get('user_id') != session.get('user_id') or sess.get('vm_id') != safe_vm_id(vm_id):
        return jsonify({'success': False, 'error': 'forbidden'}), 403
    terminal_sessions.pop(session_id, None)
    try:
        sess['channel'].close()
    except Exception:
        pass
    try:
        sess['ssh'].close()
    except Exception:
        pass
    return jsonify({'success': True})

# ─────────────────────────── File manager (SFTP into the guest) ───────────────────────────
#
# This browses/edits files *inside the VM's own OS* over SFTP, using the same
# root/user SSH credentials the web shell already connects with — it does not
# touch the host filesystem. The VM must be running and SSH must be up.

def _vm_ssh_target(v):
    """Resolve (host, port, username, password) for reaching a VM's guest OS,
    mirroring the logic in terminal_connect()."""
    username = (v['ssh_user'] if v else 'root') or 'root'
    password = (v['ssh_password'] if v else '') or ''
    # public_ip is display-only — always connect via the real hostfwd.
    host = '127.0.0.1'
    port = int(v['ssh_port'] if v else 22)
    return host, port, username, password


@contextmanager
def sftp_connect(v):
    """Open an SSH+SFTP session to a VM's guest OS. Use as a `with` block;
    closes the SFTP session and the underlying SSH transport on exit."""
    if not HAVE_PARAMIKO:
        raise RuntimeError('paramiko not installed on the host')
    host, port, username, password = _vm_ssh_target(v)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(host, port=port, username=username, password=password,
                look_for_keys=False, allow_agent=False, timeout=15,
                banner_timeout=20, auth_timeout=15)
    try:
        sftp = ssh.open_sftp()
        try:
            yield sftp
        finally:
            sftp.close()
    finally:
        ssh.close()


def safe_remote_path(path):
    """Normalize a path used against the VM's *guest* filesystem over SFTP.
    Always returns an absolute posix path (this is the guest's root, not the
    host's — root already has full access there by design)."""
    path = (path or '/').strip()
    if not path:
        path = '/'
    if not path.startswith('/'):
        path = '/' + path
    path = posixpath.normpath(path)
    if not path.startswith('/'):
        path = '/'
    return path


def _sftp_remove_recursive(sftp, path):
    """Delete a file, or a directory and everything under it, over SFTP
    (SFTP has no native recursive remove)."""
    attr = sftp.lstat(path)
    if stat.S_ISDIR(attr.st_mode):
        for entry in sftp.listdir_attr(path):
            _sftp_remove_recursive(sftp, posixpath.join(path, entry.filename))
        sftp.rmdir(path)
    else:
        sftp.remove(path)


FILE_MANAGER_TEXT_MAX = 2 * 1024 * 1024  # 2MB cap on in-browser text editing


def _file_manager_precheck(vm_id):
    """Shared checks for every file-manager API route. Returns (vm_row, error_response)."""
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return None, (jsonify({'success': False, 'message': 'VM not found'}), 404)
    if not HAVE_PARAMIKO:
        return None, (jsonify({'success': False, 'message': 'paramiko not installed'}), 500)
    running, _ = vm.vm_status(vm_id)
    if not running:
        return None, (jsonify({'success': False, 'message': 'VM is not running. Start it first.'}), 400)
    return v, None


@app.route('/vm/<vm_id>/files')
@login_required
@vm_owner_or_admin
def file_manager(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    running, _ = vm.vm_status(vm_id)
    return render_template('files.html', vm=v, is_running=running)


@app.route('/vm/<vm_id>/files/list')
@login_required
@vm_owner_or_admin
def files_list(vm_id):
    v, err = _file_manager_precheck(vm_id)
    if err:
        return err
    path = safe_remote_path(request.args.get('path', '/'))
    try:
        with sftp_connect(v) as sftp:
            entries = []
            for attr in sftp.listdir_attr(path):
                mode = attr.st_mode or 0
                entries.append({
                    'name': attr.filename,
                    'is_dir': stat.S_ISDIR(mode),
                    'is_link': stat.S_ISLNK(mode),
                    'size': attr.st_size or 0,
                    'mtime': attr.st_mtime or 0,
                })
            entries.sort(key=lambda e: (not e['is_dir'], e['name'].lower()))
        parent = None if path == '/' else (posixpath.dirname(path.rstrip('/')) or '/')
        return jsonify({'success': True, 'path': path, 'parent': parent, 'entries': entries})
    except FileNotFoundError:
        return jsonify({'success': False, 'message': 'Path not found'}), 404
    except PermissionError:
        return jsonify({'success': False, 'message': 'Permission denied'}), 403
    except Exception as e:
        return jsonify({'success': False, 'message': f'Connection failed: {e}'}), 502


@app.route('/vm/<vm_id>/files/mkdir', methods=['POST'])
@login_required
@vm_owner_or_admin
def files_mkdir(vm_id):
    v, err = _file_manager_precheck(vm_id)
    if err:
        return err
    data = request.json or {}
    path = safe_remote_path(data.get('path', '/'))
    name = (data.get('name') or '').strip()
    if not name or '/' in name or name in ('.', '..'):
        return jsonify({'success': False, 'message': 'Invalid folder name'}), 400
    new_path = posixpath.join(path, name)
    try:
        with sftp_connect(v) as sftp:
            sftp.mkdir(new_path)
        return jsonify({'success': True, 'path': new_path})
    except IOError as e:
        return jsonify({'success': False, 'message': f'Could not create folder: {e}'}), 400
    except Exception as e:
        return jsonify({'success': False, 'message': f'Connection failed: {e}'}), 502


@app.route('/vm/<vm_id>/files/delete', methods=['POST'])
@login_required
@vm_owner_or_admin
def files_delete(vm_id):
    v, err = _file_manager_precheck(vm_id)
    if err:
        return err
    data = request.json or {}
    path = safe_remote_path(data.get('path', ''))
    if path == '/':
        return jsonify({'success': False, 'message': 'Refusing to delete /'}), 400
    try:
        with sftp_connect(v) as sftp:
            _sftp_remove_recursive(sftp, path)
        return jsonify({'success': True})
    except FileNotFoundError:
        return jsonify({'success': False, 'message': 'Path not found'}), 404
    except PermissionError:
        return jsonify({'success': False, 'message': 'Permission denied'}), 403
    except Exception as e:
        return jsonify({'success': False, 'message': f'Delete failed: {e}'}), 502


@app.route('/vm/<vm_id>/files/rename', methods=['POST'])
@login_required
@vm_owner_or_admin
def files_rename(vm_id):
    v, err = _file_manager_precheck(vm_id)
    if err:
        return err
    data = request.json or {}
    src = safe_remote_path(data.get('path', ''))
    new_name = (data.get('new_name') or '').strip()
    if src == '/' or not new_name or '/' in new_name or new_name in ('.', '..'):
        return jsonify({'success': False, 'message': 'Invalid rename'}), 400
    dst = posixpath.join(posixpath.dirname(src), new_name)
    try:
        with sftp_connect(v) as sftp:
            sftp.posix_rename(src, dst)
        return jsonify({'success': True, 'path': dst})
    except FileNotFoundError:
        return jsonify({'success': False, 'message': 'Path not found'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': f'Rename failed: {e}'}), 502


@app.route('/vm/<vm_id>/files/read', methods=['POST'])
@login_required
@vm_owner_or_admin
def files_read(vm_id):
    v, err = _file_manager_precheck(vm_id)
    if err:
        return err
    data = request.json or {}
    path = safe_remote_path(data.get('path', ''))
    try:
        with sftp_connect(v) as sftp:
            attr = sftp.stat(path)
            if stat.S_ISDIR(attr.st_mode or 0):
                return jsonify({'success': False, 'message': 'That is a folder'}), 400
            if (attr.st_size or 0) > FILE_MANAGER_TEXT_MAX:
                return jsonify({'success': False, 'message': 'File is too large to edit in the browser (2MB max)'}), 400
            with sftp.open(path, 'rb') as f:
                raw = f.read()
        try:
            text = raw.decode('utf-8')
        except UnicodeDecodeError:
            return jsonify({'success': False, 'message': 'File is not plain text — download it instead'}), 400
        return jsonify({'success': True, 'content': text})
    except FileNotFoundError:
        return jsonify({'success': False, 'message': 'Path not found'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': f'Read failed: {e}'}), 502


@app.route('/vm/<vm_id>/files/write', methods=['POST'])
@login_required
@vm_owner_or_admin
def files_write(vm_id):
    v, err = _file_manager_precheck(vm_id)
    if err:
        return err
    data = request.json or {}
    path = safe_remote_path(data.get('path', ''))
    content = data.get('content', '')
    if not isinstance(content, str):
        return jsonify({'success': False, 'message': 'Invalid content'}), 400
    if len(content.encode('utf-8')) > FILE_MANAGER_TEXT_MAX:
        return jsonify({'success': False, 'message': 'Content too large (2MB max)'}), 400
    try:
        with sftp_connect(v) as sftp:
            with sftp.open(path, 'w') as f:
                f.write(content)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Save failed: {e}'}), 502


@app.route('/vm/<vm_id>/files/upload', methods=['POST'])
@login_required
@vm_owner_or_admin
def files_upload(vm_id):
    v, err = _file_manager_precheck(vm_id)
    if err:
        return err
    path = safe_remote_path(request.form.get('path', '/'))
    file = request.files.get('file')
    if not file or not file.filename:
        return jsonify({'success': False, 'message': 'No file selected'}), 400
    filename = secure_filename(file.filename)
    if not filename:
        return jsonify({'success': False, 'message': 'Invalid filename'}), 400
    dest = posixpath.join(path, filename)
    try:
        with sftp_connect(v) as sftp:
            sftp.putfo(file.stream, dest)
        return jsonify({'success': True, 'path': dest})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Upload failed: {e}'}), 502


@app.route('/vm/<vm_id>/files/download')
@login_required
@vm_owner_or_admin
def files_download(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        flash('VM not found.', 'danger')
        return redirect(url_for('dashboard'))
    running, _ = vm.vm_status(vm_id)
    if not running:
        flash('VM is not running.', 'danger')
        return redirect(url_for('file_manager', vm_id=vm_id))
    path = safe_remote_path(request.args.get('path', ''))
    try:
        with sftp_connect(v) as sftp:
            attr = sftp.stat(path)
            if stat.S_ISDIR(attr.st_mode or 0):
                flash('Cannot download a folder.', 'danger')
                return redirect(url_for('file_manager', vm_id=vm_id, path=path))
            buf = io.BytesIO()
            sftp.getfo(path, buf)
        buf.seek(0)
        filename = posixpath.basename(path) or 'download'
        return send_file(buf, as_attachment=True, download_name=filename)
    except Exception as e:
        flash(f'Download failed: {e}', 'danger')
        return redirect(url_for('file_manager', vm_id=vm_id))


@app.route('/vm/<vm_id>/start')
@login_required
@vm_owner_or_admin
def start_vm_route(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False, 'message': 'VM not found'})
    if (row_get(v, 'status') or '') == 'creating' and int(row_get(v, 'creation_progress') or 0) < 100:
        return jsonify({'success': False, 'message': 'Still installing — wait until ready'})
    r, _ = vm.vm_status(vm_id)
    if r:
        return jsonify({'success': False, 'message': 'Already running'})
    fws = db_execute("SELECT host_port, guest_port, protocol FROM port_forwards WHERE vm_id=?", (vm_id,), fetch=True) or []
    extra = [dict(r) for r in fws]
    nested = bool(row_get(v, 'nested_kvm') or 0)
    sp = int(row_get(v, 'ssh_port') or 0)
    serial = row_get(v, 'serial_port') or row_get(v, 'vnc_port')
    if sp and sp != 22:
        subprocess.run(['fuser', '-k', f'{sp}/tcp'], capture_output=True)
    time.sleep(0.5)
    pid = vm.start_vm(
        vm_id, v['os_template'], v['ram_mb'], v['cpu_cores'], v['storage_gb'],
        sp, serial,
        row_get(v, 'network_mode') or 'private',
        row_get(v, 'public_ip'),
        row_get(v, 'private_ip'),
        extra, nested,
    )
    if pid:
        db_execute("UPDATE vm_instances SET status='running', pid=? WHERE vm_id=?", (pid, vm_id))
        return jsonify({'success': True, 'message': 'Started'})
    err = getattr(vm, 'last_start_error', None) or 'Failed to start — check host has qemu-system-x86 and VM disk exists'
    return jsonify({'success': False, 'message': err})


@app.route('/vm/<vm_id>/stop')
@login_required
@vm_owner_or_admin
def stop_vm_route(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False, 'message': 'VM not found'})
    r, pid = vm.vm_status(vm_id)
    if not r:
        return jsonify({'success': False, 'message': 'Not running'})
    if vm.stop_vm(pid, v['ssh_port']):
        db_execute("UPDATE vm_instances SET status='stopped', pid=NULL WHERE vm_id=?", (vm_id,))
        audit(session['user_id'], 'stop_vm', vm_id)
        return jsonify({'success': True, 'message': 'Stopped'})
    return jsonify({'success': False})

@app.route('/vm/<vm_id>/restart')
@login_required
@vm_owner_or_admin
def restart_vm_route(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False, 'message': 'VM not found'})
    r, pid = vm.vm_status(vm_id)
    if r:
        vm.stop_vm(pid, row_get(v, 'ssh_port'))
        time.sleep(2)
    fws = db_execute("SELECT host_port, guest_port, protocol FROM port_forwards WHERE vm_id=?", (vm_id,), fetch=True) or []
    extra = [dict(r) for r in fws]
    nested = bool(row_get(v, 'nested_kvm') or 0)
    sp = int(row_get(v, 'ssh_port') or 0)
    serial = row_get(v, 'serial_port') or row_get(v, 'vnc_port')
    if sp and sp != 22:
        subprocess.run(['fuser', '-k', f'{sp}/tcp'], capture_output=True)
    time.sleep(0.5)
    np = vm.start_vm(
        vm_id, v['os_template'], v['ram_mb'], v['cpu_cores'], v['storage_gb'],
        sp, serial,
        row_get(v, 'network_mode') or 'private',
        row_get(v, 'public_ip'),
        row_get(v, 'private_ip'),
        extra, nested,
    )
    if np:
        db_execute("UPDATE vm_instances SET status='running', pid=? WHERE vm_id=?", (np, vm_id))
        return jsonify({'success': True, 'message': 'Restarted!'})
    return jsonify({'success': False, 'message': 'Failed to restart'})



@app.route('/vm/<vm_id>/reinstall', methods=['POST', 'GET'])
@admin_required
def reinstall_vm_route(vm_id):
    """Wipe disk + cloud-init and redeploy same specs (fresh install)."""
    vm_id = safe_vm_id(vm_id)
    if not vm_id:
        return jsonify({'success': False, 'message': 'Invalid VM id'})
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False, 'message': 'VM not found'})
    running, pid = vm.vm_status(vm_id)
    if running:
        vm.stop_vm(pid, row_get(v, 'ssh_port'))
        time.sleep(1)
    try:
        d = (VM_DIR / vm_id).resolve()
        if str(d).startswith(str(VM_DIR.resolve())) and d.exists():
            shutil.rmtree(d, ignore_errors=True)
        d.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return jsonify({'success': False, 'message': f'Wipe failed: {e}'})
    root_pw = generate_vm_password(12)
    db_execute(
        "UPDATE vm_instances SET status='creating', creation_progress=1, creation_step=?, "
        "ssh_password=?, pid=NULL WHERE vm_id=?",
        ('Reinstall queued…', root_pw, vm_id)
    )
    threading.Thread(
        target=complete_vm_setup,
        args=(
            vm_id, v['os_template'], v['ram_mb'], v['cpu_cores'], v['storage_gb'],
            v['ssh_port'], row_get(v, 'serial_port') or row_get(v, 'vnc_port'),
            row_get(v, 'network_mode') or 'private',
            row_get(v, 'public_ip'), row_get(v, 'private_ip'),
        ),
        daemon=True,
    ).start()
    audit(session['user_id'], 'reinstall_vm', f'Reinstall {v["name"]} ({vm_id[:8]})')
    if request.is_json or 'application/json' in (request.headers.get('Accept') or ''):
        return jsonify({'success': True, 'message': 'Reinstall started', 'redirect': url_for('vm_installing', vm_id=vm_id)})
    flash('Reinstall started.', 'success')
    return redirect(url_for('vm_installing', vm_id=vm_id))


@app.route('/vm/<vm_id>/delete')
@admin_required
def delete_vm_route(vm_id):
    vm_id = safe_vm_id(vm_id)
    if not vm_id:
        return jsonify({'success': False, 'message': 'Invalid VM id'})
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False, 'message': 'Not found'})
    r, pid = vm.vm_status(vm_id)
    if r:
        vm.stop_vm(pid, v['ssh_port'])
    if v['public_ip']:
        db_execute("UPDATE public_ips SET is_available=1, assigned_vm_id=NULL WHERE ip_address=?",
                   (v['public_ip'],))
    db_execute("DELETE FROM port_forwards WHERE vm_id=?", (vm_id,))
    try:
        d = (VM_DIR / vm_id).resolve()
        if str(d).startswith(str(VM_DIR.resolve())) and d.exists():
            shutil.rmtree(d, ignore_errors=True)
    except Exception:
        pass
    db_execute("DELETE FROM vm_instances WHERE vm_id=?", (vm_id,))
    audit(session['user_id'], 'delete_vm', f'Deleted {v["name"]} ({vm_id[:8]})')
    return jsonify({'success': True, 'message': 'Deleted'})

@app.route('/vm/<vm_id>/tmate')
@login_required
@vm_owner_or_admin
def tmate_route(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False})
    pw = v['ssh_password'] or ''
    # public_ip is display-only — always reach the guest via the real hostfwd.
    host = '127.0.0.1'
    res = vm.setup_tmate(vm_id, v['ssh_port'], password=pw, host=host)
    if res:
        return jsonify({'success': True, 'tmate_ssh': res.get('ssh'), 'tmate_web': res.get('web')})
    return jsonify({'success': False, 'message': getattr(vm, 'last_share_error', None) or 'Try again later'})

@app.route('/vm/<vm_id>/sshx')
@login_required
@vm_owner_or_admin
def sshx_route(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False})
    pw = v['ssh_password'] or ''
    # public_ip is display-only — always reach the guest via the real hostfwd.
    host = '127.0.0.1'
    res = vm.setup_sshx(vm_id, v['ssh_port'], password=pw, host=host)
    if res:
        return jsonify({'success': True, 'url': res.get('url')})
    return jsonify({'success': False, 'message': getattr(vm, 'last_share_error', None) or 'Could not start sshx — try again in a moment.'})


@app.route('/vm/<vm_id>/ports', methods=['GET', 'POST'])
@login_required
@vm_owner_or_admin
def vm_ports(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False})
    if request.method == 'POST':
        if session.get('role') != 'admin':
            return jsonify({'success': False, 'message': 'Admin only'})
        action = (request.json or {}).get('action')
        if action == 'add':
            gp = int((request.json or {}).get('guest_port', 0))
            if not gp or gp == 22:
                return jsonify({'success': False, 'message': 'Guest port required (not 22)'})
            max_nat = int(gsv('max_nat_ports_per_vm', 5) or 5)
            cnt = db_execute("SELECT COUNT(*) as c FROM port_forwards WHERE vm_id=?", (vm_id,), fetchone=True)
            if cnt and cnt['c'] >= max_nat:
                return jsonify({'success': False, 'message': f'Max {max_nat} NAT ports per VM'})
            hp = allocate_host_port()
            try:
                db_execute(
                    "INSERT INTO port_forwards (vm_id, host_port, guest_port, protocol, label) VALUES (?,?,?,?,?)",
                    (vm_id, hp, gp, 'tcp', f'{hp}->{gp}')
                )
                return jsonify({'success': True, 'message': f'Added host :{hp} → guest :{gp}. Restart VM to apply.', 'host_port': hp})
            except Exception as e:
                return jsonify({'success': False, 'message': str(e)})
        if action == 'delete':
            fid = (request.json or {}).get('id')
            db_execute("DELETE FROM port_forwards WHERE id=? AND vm_id=?", (fid, vm_id))
            return jsonify({'success': True, 'message': 'Removed. Restart VM to apply.'})
    fws = db_execute("SELECT * FROM port_forwards WHERE vm_id=?", (vm_id,), fetch=True) or []
    return jsonify({'success': True, 'forwards': [dict(r) for r in fws]})

@app.route('/vm/<vm_id>/metrics')
@login_required
@vm_owner_or_admin
def metrics_route(vm_id):
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False})
    r, pid = vm.vm_status(vm_id)
    if r:
        return jsonify({'success': True, 'running': True, 'metrics': vm.vm_metrics(pid)})
    return jsonify({'success': True, 'running': False})

@app.route('/vm/<vm_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_vm(vm_id):
    vm_id = safe_vm_id(vm_id)
    if not vm_id:
        flash('Invalid VM id.', 'danger')
        return redirect(url_for('admin_vms'))
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        flash('VM not found.', 'danger')
        return redirect(url_for('admin_vms'))
    if request.method == 'POST':
        name = sanitize_name(request.form.get('name', ''), 64)
        if not name:
            flash('Name is required.', 'warning')
            return redirect(url_for('edit_vm', vm_id=vm_id))
        try:
            # SSH host port is system-managed; only change if admin provides a free one
            raw_port = request.form.get('ssh_port', '').strip()
            new_port = int(raw_port) if raw_port else int(v['ssh_port'] or 0)
            ram = int(request.form.get('ram_mb') or v['ram_mb'])
            cpu = int(request.form.get('cpu_cores') or v['cpu_cores'])
            stor = int(request.form.get('storage_gb') or v['storage_gb'])
            uid = int(request.form.get('user_id') or v['user_id'])
            notes = request.form.get('notes', '') or ''
            root_pw = request.form.get('ssh_password', '').strip()
            nested_kvm = 1 if request.form.get('nested_kvm') == 'on' else 0
        except (ValueError, TypeError) as e:
            flash(f'Invalid values: {e}', 'danger')
            return redirect(url_for('edit_vm', vm_id=vm_id))

        if new_port != v['ssh_port']:
            if new_port < 22 or new_port > 65535:
                flash('Port must be 22-65535.', 'danger')
                return redirect(url_for('edit_vm', vm_id=vm_id))
            ex = db_execute("SELECT COUNT(*) as c FROM vm_instances WHERE ssh_port=? AND vm_id!=?",
                            (new_port, vm_id), fetchone=True)
            pf = db_execute("SELECT COUNT(*) as c FROM port_forwards WHERE host_port=?", (new_port,), fetchone=True)
            if (ex and ex['c'] > 0) or (pf and pf['c'] > 0):
                flash(f'Port {new_port} is already in use!', 'danger')
                return redirect(url_for('edit_vm', vm_id=vm_id))

        if stor < v['storage_gb']:
            flash('Disk size cannot be decreased.', 'warning')
            return redirect(url_for('edit_vm', vm_id=vm_id))
        if stor > v['storage_gb']:
            r, pid = vm.vm_status(vm_id)
            if r:
                flash('Stop the VM before increasing disk size.', 'warning')
                return redirect(url_for('edit_vm', vm_id=vm_id))
            try:
                vm.resize_disk(vm_id, stor)
            except Exception as e:
                flash(f'Disk resize failed: {e}', 'danger')
                return redirect(url_for('edit_vm', vm_id=vm_id))

        update_pw = root_pw if root_pw else v['ssh_password']
        try:
            db_execute(
                "UPDATE vm_instances SET name=?, ram_mb=?, cpu_cores=?, storage_gb=?, notes=?, "
                "user_id=?, ssh_port=?, ssh_password=?, nested_kvm=? WHERE vm_id=?",
                (name, ram, cpu, stor, notes, uid, new_port, update_pw, nested_kvm, vm_id)
            )
        except Exception as e:
            flash(f'Update failed: {e}', 'danger')
            return redirect(url_for('edit_vm', vm_id=vm_id))
        audit(session['user_id'], 'edit_vm', f'Edited {name} ({vm_id[:8]})')
        flash('VM updated successfully! Restart VM to apply CPU/RAM/nested changes.', 'success')
        return redirect(url_for('manage_vm', vm_id=vm_id))

    users = db_execute("SELECT id, username FROM users WHERE is_active=1 ORDER BY username", fetch=True) or []
    return render_template('edit_vm.html', vm=v, users=users, have_kvm=HAVE_KVM)

# ─────────────────────────── Admin routes ───────────────────────────

@app.route('/admin')
@admin_required
def admin_dashboard():
    tv = (db_execute("SELECT COUNT(*) as c FROM vm_instances", fetchone=True) or {'c': 0})['c']
    # Real running count
    all_vms = db_execute("SELECT vm_id, status FROM vm_instances", fetch=True) or []
    rv = 0
    for v in all_vms:
        running, _ = vm.vm_status(v['vm_id'])
        if running:
            rv += 1
    tu = (db_execute("SELECT COUNT(*) as c FROM users", fetchone=True) or {'c': 0})['c']
    cpu = psutil.cpu_percent(interval=0.3)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    return render_template('admin/dashboard.html',
                           total_vms=tv, running_vms=rv, total_users=tu,
                           cpu_percent=cpu,
                           memory_percent=mem.percent,
                           memory_used=round(mem.used / (1024 ** 3), 1),
                           memory_total=round(mem.total / (1024 ** 3), 1),
                           disk_percent=disk.percent)

@app.route('/admin/vms')
@admin_required
def admin_vms():
    vms = db_execute(
        "SELECT v.*, u.username FROM vm_instances v LEFT JOIN users u ON v.user_id=u.id "
        "ORDER BY v.created_at DESC", fetch=True) or []
    vl = []
    total_ram = 0
    running = 0
    stopped = 0
    for v in vms:
        d = dict(v)
        r, _ = vm.vm_status(v['vm_id'])
        d['real_status'] = 'running' if r else ('creating' if v['status'] == 'creating' else 'stopped')
        if d['real_status'] == 'running':
            running += 1
        elif d['real_status'] == 'stopped':
            stopped += 1
        total_ram += v['ram_mb'] or 0
        vl.append(d)
    return render_template('admin/vms.html', vms=vl, total=len(vl),
                           running=running, stopped=stopped,
                           total_ram=f"{total_ram/1024:.1f}G")

@app.route('/admin/users')
@admin_required
def admin_users():
    users = db_execute("SELECT * FROM users ORDER BY created_at DESC", fetch=True) or []
    total = len(users)
    admins = sum(1 for u in users if u['role'] == 'admin')
    active = sum(1 for u in users if u['is_active'])
    return render_template('admin/users.html', users=users,
                           total_users=total, admins=admins, active=active)

@app.route('/admin/users/create', methods=['GET', 'POST'])
@admin_required
def admin_create_user():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        role = request.form.get('role', 'user')
        if not username or not email or not password:
            flash('All fields required.', 'warning')
            return redirect(url_for('admin_create_user'))
        try:
            db_execute("INSERT INTO users (username, email, password, role) VALUES (?,?,?,?)",
                       (username, email, generate_password_hash(password, method='scrypt'), role))
            audit(session['user_id'], 'create_user', username)
            flash(f'User {username} created.', 'success')
            return redirect(url_for('admin_users'))
        except sqlite3.IntegrityError:
            flash('Username or email already exists.', 'danger')
    return render_template('admin/create_user.html')

@app.route('/admin/users/<int:user_id>/edit', methods=['GET', 'POST'])
@admin_required
def admin_edit_user(user_id):
    u = db_execute("SELECT * FROM users WHERE id=?", (user_id,), fetchone=True)
    if not u:
        flash('User not found.', 'danger')
        return redirect(url_for('admin_users'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        role = request.form.get('role', 'user')
        if role not in ('user', 'admin'):
            role = 'user'
        is_active = 1 if request.form.get('is_active') in ('on', '1', 'true', True) else 0
        pw = request.form.get('new_password', '').strip()
        if not username or not email:
            flash('Username and email are required.', 'warning')
            return render_template('admin/edit_user.html', user=u)
        # prevent locking yourself out
        if user_id == session['user_id']:
            is_active = 1  # cannot deactivate yourself
            if role != 'admin' and session.get('role') == 'admin':
                other = db_execute(
                    "SELECT COUNT(*) as c FROM users WHERE role='admin' AND is_active=1 AND id!=?",
                    (user_id,), fetchone=True)
                if not other or other['c'] < 1:
                    flash('Cannot demote the only active admin.', 'danger')
                    return render_template('admin/edit_user.html', user=u)
        try:
            if pw:
                if len(pw) < 4:
                    flash('Password must be at least 4 characters.', 'warning')
                    return render_template('admin/edit_user.html', user=u)
                db_execute(
                    "UPDATE users SET username=?, email=?, role=?, is_active=?, password=? WHERE id=?",
                    (username, email, role, is_active, generate_password_hash(pw, method='scrypt'), user_id)
                )
            else:
                db_execute(
                    "UPDATE users SET username=?, email=?, role=?, is_active=? WHERE id=?",
                    (username, email, role, is_active, user_id)
                )
            audit(session['user_id'], 'edit_user', f'{username} (id={user_id})')
            flash('User updated successfully.', 'success')
            return redirect(url_for('admin_users'))
        except Exception as e:
            flash(f'Update failed (username/email may already exist): {e}', 'danger')
            return render_template('admin/edit_user.html', user=u)
    return render_template('admin/edit_user.html', user=u)

@app.route('/admin/users/<int:user_id>/delete')
@admin_required
def admin_delete_user(user_id):
    if user_id == session['user_id']:
        flash('Cannot delete yourself.', 'danger')
        return redirect(url_for('admin_users'))
    db_execute("DELETE FROM users WHERE id=?", (user_id,))
    audit(session['user_id'], 'delete_user', str(user_id))
    flash('User deleted.', 'success')
    return redirect(url_for('admin_users'))

@app.route('/admin/settings', methods=['GET', 'POST'])
@admin_required
def admin_settings():
    if request.method == 'POST':
        locked = {'site_version', 'valid_license_key', 'license_activated', 'license_key_entered',
                  'license_activated_at', 'license_digest'}
        saved = 0
        for k, v in request.form.items():
            if not k.startswith('setting_'):
                continue
            key = k.replace('setting_', '', 1).strip()
            if not key or key in locked or key not in SETTINGS_ALLOWLIST:
                continue
            val = str(v).strip()[:2000]
            if key == 'site_name':
                val = val[:80] or 'AKVM Panel'
            if key == 'background_url' and val and not (val.startswith('https://') or val.startswith('/')):
                continue
            if key == 'discord_oauth_client_secret' and not val:
                continue  # blank means "keep existing secret", not "clear it"
            try:
                _set_setting(key, val)
                saved += 1
            except Exception as e:
                flash(f'Failed to save {key}: {e}', 'danger')
        if saved:
            flash(f'Settings saved ({saved} fields).', 'success')
        else:
            flash('No settings were updated.', 'warning')
        # Checkboxes aren't submitted at all when unchecked — handle them explicitly
        # so unchecking actually turns them off instead of leaving the old value.
        if 'settings_form' in request.form:
            _set_setting('security_scan_enabled', 'true' if 'setting_security_scan_enabled' in request.form else 'false')
            _set_setting('security_auto_stop_on_mining', 'true' if 'setting_security_auto_stop_on_mining' in request.form else 'false')
            _set_setting('discord_oauth_enabled', 'true' if 'setting_discord_oauth_enabled' in request.form else 'false')
        return redirect(url_for('admin_settings'))
    settings = {r['key']: r['value'] for r in (db_execute("SELECT * FROM settings", fetch=True) or [])}
    return render_template('admin/settings.html', settings=settings, os_templates=OS_TEMPLATES)

@app.route('/admin/icons')
@admin_required
def admin_icons():
    settings = {r['key']: r['value'] for r in (db_execute("SELECT * FROM settings", fetch=True) or [])}
    return render_template('admin/icons.html', settings=settings)

@app.route('/admin/discord-bot')
@admin_required
def admin_discord_bot():
    settings = {r['key']: r['value'] for r in (db_execute("SELECT * FROM settings", fetch=True) or [])}
    return render_template('admin/discord_bot.html', settings=settings, os_templates=OS_TEMPLATES)

ICON_ALLOWED_EXT = {'png', 'jpg', 'jpeg', 'ico', 'svg', 'webp'}

@app.route('/admin/settings/icon-upload', methods=['POST'])
@admin_required
def admin_settings_icon_upload():
    file = request.files.get('icon')
    if not file or not file.filename:
        flash('No file selected.', 'danger')
        return redirect(url_for('admin_icons'))
    ext = file.filename.rsplit('.', 1)[-1].lower() if '.' in file.filename else ''
    if ext not in ICON_ALLOWED_EXT:
        flash('Unsupported file type. Use PNG, JPG, ICO, SVG, or WEBP.', 'danger')
        return redirect(url_for('admin_icons'))
    upload_dir = BASE_DIR / 'static' / 'uploads'
    upload_dir.mkdir(parents=True, exist_ok=True)
    for old in upload_dir.glob('site-icon.*'):
        try: old.unlink()
        except Exception: pass
    dest = upload_dir / f'site-icon.{ext}'
    file.save(dest)
    _set_setting('site_icon_url', f'/static/uploads/site-icon.{ext}?v={int(time.time())}')
    audit(session['user_id'], 'settings_icon_upload', ext)
    flash('Site icon updated.', 'success')
    return redirect(url_for('admin_icons'))

@app.route('/admin/settings/icon-remove', methods=['POST'])
@admin_required
def admin_settings_icon_remove():
    upload_dir = BASE_DIR / 'static' / 'uploads'
    for old in upload_dir.glob('site-icon.*'):
        try: old.unlink()
        except Exception: pass
    _set_setting('site_icon_url', '')
    audit(session['user_id'], 'settings_icon_remove', '')
    flash('Site icon removed.', 'success')
    return redirect(url_for('admin_icons'))

@app.route('/admin/settings/sidebar-icon-upload', methods=['POST'])
@admin_required
def admin_settings_sidebar_icon_upload():
    file = request.files.get('icon')
    if not file or not file.filename:
        flash('No file selected.', 'danger')
        return redirect(url_for('admin_icons'))
    ext = file.filename.rsplit('.', 1)[-1].lower() if '.' in file.filename else ''
    if ext not in ICON_ALLOWED_EXT:
        flash('Unsupported file type. Use PNG, JPG, ICO, SVG, or WEBP.', 'danger')
        return redirect(url_for('admin_icons'))
    upload_dir = BASE_DIR / 'static' / 'uploads'
    upload_dir.mkdir(parents=True, exist_ok=True)
    for old in upload_dir.glob('sidebar-icon.*'):
        try: old.unlink()
        except Exception: pass
    dest = upload_dir / f'sidebar-icon.{ext}'
    file.save(dest)
    _set_setting('sidebar_icon_url', f'/static/uploads/sidebar-icon.{ext}?v={int(time.time())}')
    audit(session['user_id'], 'settings_sidebar_icon_upload', ext)
    flash('Sidebar icon updated.', 'success')
    return redirect(url_for('admin_icons'))

@app.route('/admin/settings/sidebar-icon-remove', methods=['POST'])
@admin_required
def admin_settings_sidebar_icon_remove():
    upload_dir = BASE_DIR / 'static' / 'uploads'
    for old in upload_dir.glob('sidebar-icon.*'):
        try: old.unlink()
        except Exception: pass
    _set_setting('sidebar_icon_url', '')
    audit(session['user_id'], 'settings_sidebar_icon_remove', '')
    flash('Sidebar icon removed.', 'success')
    return redirect(url_for('admin_icons'))


@app.route('/admin/fonts', methods=['GET', 'POST'])
@admin_required
def admin_fonts():
    if request.method == 'POST':
        key = (request.form.get('ui_font') or 'inter').strip().lower()
        if key not in PANEL_FONTS:
            flash('Unknown font.', 'danger')
        else:
            _set_setting('ui_font', key)
            flash(f'Font set to {PANEL_FONTS[key]["name"]}.', 'success')
        return redirect(url_for('admin_fonts'))
    current, meta = get_ui_font()
    return render_template('admin/fonts.html', fonts=PANEL_FONTS, current=current, current_meta=meta)

@app.route('/admin/public-ips', methods=['GET', 'POST'])
@admin_required
def admin_public_ips():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'add':
            ip = request.form.get('ip_address', '').strip()
            label = request.form.get('label', '').strip()
            notes = request.form.get('notes', '').strip()
            if not ip:
                flash('IP address required.', 'warning')
            else:
                try:
                    db_execute("INSERT INTO public_ips (ip_address, label, notes) VALUES (?,?,?)",
                               (ip, label, notes))
                    flash(f'Public IP {ip} added.', 'success')
                    audit(session['user_id'], 'add_public_ip', ip)
                except sqlite3.IntegrityError:
                    flash('IP already exists.', 'danger')
        elif action == 'delete':
            ip_id = request.form.get('ip_id')
            row = db_execute("SELECT * FROM public_ips WHERE id=?", (ip_id,), fetchone=True)
            if row and not row['is_available']:
                flash('Cannot delete an assigned IP. Unassign first.', 'warning')
            else:
                db_execute("DELETE FROM public_ips WHERE id=?", (ip_id,))
                flash('IP removed.', 'success')
        elif action == 'free':
            ip_id = request.form.get('ip_id')
            db_execute("UPDATE public_ips SET is_available=1, assigned_vm_id=NULL WHERE id=?", (ip_id,))
            flash('IP marked available.', 'success')
        return redirect(url_for('admin_public_ips'))
    ips = db_execute("SELECT * FROM public_ips ORDER BY created_at DESC", fetch=True) or []
    return render_template('admin/public_ips.html', ips=ips)

@app.route('/admin/nodes', methods=['GET', 'POST'])
@admin_required
def admin_nodes():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'ensure_local':
            nid = ensure_local_node()
            if nid:
                flash('Local Node is ready.', 'success')
            else:
                flash('Failed to create Local Node.', 'danger')
            return redirect(url_for('admin_nodes'))
        if action == 'delete_node':
            nid = int(request.form.get('node_id', 0))
            n = db_execute("SELECT * FROM nodes WHERE id=?", (nid,), fetchone=True)
            if n and n['is_local']:
                flash('Cannot delete Local Node. Use Ensure Local Node if missing.', 'warning')
            elif n:
                c = db_execute("SELECT COUNT(*) as c FROM vm_instances WHERE node_id=?", (nid,), fetchone=True)
                if c and c['c']:
                    flash('Node still has VMs assigned.', 'danger')
                else:
                    db_execute("DELETE FROM nodes WHERE id=?", (nid,))
                    flash('Node removed.', 'success')
            return redirect(url_for('admin_nodes'))
    # refresh / recreate local node stats
    ensure_local_node()
    local = db_execute("SELECT * FROM nodes WHERE is_local=1", fetchone=True)
    if local:
        try:
            cpu = psutil.cpu_count() or 1
            ram = int(psutil.virtual_memory().total / (1024 * 1024))
            disk = int(psutil.disk_usage('/').total / (1024 ** 3))
            db_execute(
                "UPDATE nodes SET cpu_cores=?, ram_mb=?, disk_gb=?, has_kvm=?, "
                "last_seen=CURRENT_TIMESTAMP, status='online', hostname=? WHERE is_local=1",
                (cpu, ram, disk, 1 if HAVE_KVM else 0, socket.gethostname())
            )
        except Exception:
            pass
    nodes = db_execute("SELECT * FROM nodes ORDER BY is_local DESC, name", fetch=True) or []
    # count VMs per node
    enriched = []
    for n in nodes:
        d = dict(n)
        c = db_execute("SELECT COUNT(*) as c FROM vm_instances WHERE node_id=?", (n['id'],), fetchone=True)
        d['vm_count'] = c['c'] if c else 0
        enriched.append(d)
    return render_template('admin/nodes.html', nodes=enriched, have_kvm=HAVE_KVM)

@app.route('/admin/os-templates')
@admin_required
def admin_os_templates():
    return render_template('admin/os_templates.html', templates=OS_TEMPLATES)

@app.route('/admin/os-templates/<key>/download')
@admin_required
def admin_os_download(key):
    if key not in OS_TEMPLATES:
        flash('Unknown template.', 'danger')
        return redirect(url_for('admin_os_templates'))
    t = OS_TEMPLATES[key]
    flash(f'Template "{t["name"]}" downloads automatically when you create a VM using it.', 'info')
    return redirect(url_for('admin_os_templates'))

@app.route('/admin/audit')
@admin_required
def admin_audit():
    logs = db_execute(
        "SELECT a.*, u.username FROM audit_log a LEFT JOIN users u ON a.user_id=u.id "
        "ORDER BY a.timestamp DESC LIMIT 150", fetch=True) or []
    return render_template('admin/audit.html', logs=logs)

# ─────────────────────────── Profile & notifications ───────────────────────────

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    u = db_execute("SELECT * FROM users WHERE id=?", (session['user_id'],), fetchone=True)
    c = (db_execute("SELECT COUNT(*) as c FROM vm_instances WHERE user_id=?",
                    (session['user_id'],), fetchone=True) or {'c': 0})['c']
    if request.method == 'POST':
        # Profile form only (API keys use different action URL)
        email = request.form.get('email', '').strip()
        pw = request.form.get('new_password', '').strip()
        if not email or '@' not in email:
            flash('Valid email required.', 'warning')
            return redirect(url_for('profile'))
        try:
            if pw:
                if len(pw) < 4:
                    flash('Password must be at least 4 characters.', 'warning')
                    return redirect(url_for('profile'))
                db_execute("UPDATE users SET email=?, password=? WHERE id=?",
                           (email, generate_password_hash(pw, method='scrypt'), session['user_id']))
            else:
                db_execute("UPDATE users SET email=? WHERE id=?", (email, session['user_id']))
            flash('Profile updated.', 'success')
        except Exception as e:
            flash(f'Update failed: {e}', 'danger')
        return redirect(url_for('profile'))
    return render_template('profile.html', user=u, vm_count=c)

@app.route('/notifications')
@login_required
def notifications():
    notifs = db_execute("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50",
                        (session['user_id'],), fetch=True) or []
    return render_template('notifications.html', notifications=notifs)

@app.route('/notifications/read/<int:nid>')
@login_required
def read_notification(nid):
    db_execute("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?",
               (nid, session['user_id']))
    return jsonify({'success': True})

@app.route('/notifications/read-all')
@login_required
def read_all_notifications():
    db_execute("UPDATE notifications SET is_read=1 WHERE user_id=?", (session['user_id'],))
    return redirect(url_for('notifications'))

# ─────────────────────────── Errors & filters ───────────────────────────

@app.errorhandler(404)
def e404(e):
    return render_template('errors/404.html'), 404

@app.errorhandler(500)
def e500(e):
    return render_template('errors/500.html'), 500

@app.template_filter('datetime')
def dt_fmt(v):
    if not v:
        return 'N/A'
    if isinstance(v, str):
        try:
            return datetime.strptime(v[:19], '%Y-%m-%d %H:%M:%S').strftime('%b %d, %Y')
        except Exception:
            return v
    return v.strftime('%b %d, %Y')

@app.template_filter('status_badge')
def status_badge(s):
    colors = {
        'running': 'success',
        'stopped': 'secondary',
        'creating': 'warning',
        'error': 'danger'
    }
    return colors.get(s, 'secondary')

# ─────────────────────────── Main ───────────────────────────


# ─────────────────────────── Node agent API ───────────────────────────

@app.route('/api/node/register', methods=['POST'])
def api_node_register():
    data = request.json or {}
    token = data.get('token') or request.headers.get('X-Node-Token', '')
    expected = gsv('node_register_token', '')
    if not expected or len(expected) < 16 or not constant_time_eq(token, expected):
        return jsonify({'success': False, 'message': 'Invalid or missing node register token'}), 403
    name = (data.get('name') or '').strip() or f"node-{uuid.uuid4().hex[:6]}"
    hostname = data.get('hostname') or ''
    api_url = data.get('api_url') or ''
    has_kvm = 1 if data.get('has_kvm') else 0
    cpu = int(data.get('cpu_cores') or 0)
    ram = int(data.get('ram_mb') or 0)
    disk = int(data.get('disk_gb') or 0)
    agent_version = data.get('agent_version') or '1.0'
    node_token = secrets.token_hex(24)
    existing = db_execute("SELECT id FROM nodes WHERE name=?", (name,), fetchone=True)
    if existing:
        db_execute(
            "UPDATE nodes SET hostname=?, api_url=?, has_kvm=?, cpu_cores=?, ram_mb=?, disk_gb=?, "
            "status='online', last_seen=CURRENT_TIMESTAMP, token=?, agent_version=? WHERE id=?",
            (hostname, api_url, has_kvm, cpu, ram, disk, node_token, agent_version, existing['id'])
        )
        nid = existing['id']
    else:
        db_execute(
            "INSERT INTO nodes (name, hostname, is_local, status, cpu_cores, ram_mb, disk_gb, has_kvm, api_url, token, agent_version) "
            "VALUES (?,?,0,'online',?,?,?,?,?,?,?)",
            (name, hostname, cpu, ram, disk, has_kvm, api_url, node_token, agent_version)
        )
        row = db_execute("SELECT id FROM nodes WHERE name=?", (name,), fetchone=True)
        nid = row['id'] if row else None
    return jsonify({'success': True, 'node_id': nid, 'node_token': node_token})

@app.route('/api/node/heartbeat', methods=['POST'])
def api_node_heartbeat():
    data = request.json or {}
    token = data.get('token') or request.headers.get('X-Node-Token', '')
    node = db_execute("SELECT * FROM nodes WHERE token=?", (token,), fetchone=True)
    if not node:
        return jsonify({'success': False}), 403
    db_execute(
        "UPDATE nodes SET status='online', last_seen=CURRENT_TIMESTAMP, has_kvm=?, cpu_cores=?, ram_mb=?, disk_gb=? WHERE id=?",
        (1 if data.get('has_kvm') else 0, int(data.get('cpu_cores') or 0),
         int(data.get('ram_mb') or 0), int(data.get('disk_gb') or 0), node['id'])
    )
    return jsonify({'success': True})


# ─────────────────────────── REST API ───────────────────────────

def _hash_api_key(raw):
    return hashlib.sha256(raw.encode()).hexdigest()

def _issue_api_key(user_id, name, scope):
    raw = 'akvm_' + secrets.token_urlsafe(32)
    prefix = raw[:12]
    db_execute(
        "INSERT INTO api_keys (user_id, name, key_hash, key_prefix, scope) VALUES (?,?,?,?,?)",
        (user_id, name or 'default', _hash_api_key(raw), prefix, scope)
    )
    return raw

def api_auth(required_scope='user'):
    """Authenticate via Bearer API key. Token scope is the sole permission source.

    Scopes:
      - user  → /api/v1/user/* only
      - admin → /api/v1/admin/* and /api/v1/user/* (admin includes user level)

    Account role alone never elevates a user-scoped token.
    """
    ip = request.headers.get('X-Forwarded-For', request.remote_addr or 'unknown').split(',')[0].strip()
    if not rate_limit(f'api:{ip}', limit=120, window=60):
        return None, (jsonify({'success': False, 'error': 'Rate limit exceeded'}), 429)
    auth = request.headers.get('Authorization', '')
    if not auth.startswith('Bearer '):
        return None, (jsonify({'success': False, 'error': 'Missing Bearer token'}), 401)
    raw = auth[7:].strip()
    if not raw:
        return None, (jsonify({'success': False, 'error': 'Empty token'}), 401)
    h = _hash_api_key(raw)
    row = db_execute(
        "SELECT k.*, u.username, u.role, u.is_active as user_active "
        "FROM api_keys k JOIN users u ON u.id=k.user_id "
        "WHERE k.key_hash=? AND k.is_active=1",
        (h,), fetchone=True
    )
    if not row or not row['user_active']:
        return None, (jsonify({'success': False, 'error': 'Invalid or revoked API key'}), 401)
    scope = (row['scope'] or 'user').strip().lower()
    if scope not in ('user', 'admin'):
        scope = 'user'
    # Invalid: admin-scoped key on a non-admin account
    if scope == 'admin' and row['role'] != 'admin':
        return None, (jsonify({
            'success': False,
            'error': 'Admin-scoped key is invalid for this account'
        }), 403)
    # Hierarchical permission: admin > user. Never grant from account role.
    level = {'user': 1, 'admin': 2}
    need = level.get(required_scope, 1)
    have = level.get(scope, 0)
    if have < need:
        return None, (jsonify({
            'success': False,
            'error': f'This API key has scope "{scope}"; requires "{required_scope}"',
            'key_scope': scope,
            'required_scope': required_scope,
        }), 403)
    db_execute("UPDATE api_keys SET last_used=CURRENT_TIMESTAMP WHERE id=?", (row['id'],))
    # Expose normalized scope on the row for handlers
    try:
        row = dict(row)
        row['scope'] = scope
    except Exception:
        pass
    return row, None

def _vm_dict(v, include_secret=False):
    d = {
        'id': v['vm_id'],
        'name': v['name'],
        'os': v['os_template'],
        'status': v['status'],
        'cpu': v['cpu_cores'],
        'ram_mb': v['ram_mb'],
        'disk_gb': v['storage_gb'],
        'network_mode': v['network_mode'],
        'public_ip': v['public_ip'],
        'private_ip': v['private_ip'] if 'private_ip' in v.keys() else None,
        'ssh_port': v['ssh_port'],
        'ssh_host': v['ssh_host'],
        'serial_port': v['serial_port'] if 'serial_port' in v.keys() else v['vnc_port'],
        'created_at': v['created_at'],
    }
    running, _ = vm.vm_status(v['vm_id'])
    d['running'] = running
    d['real_status'] = 'running' if running else ('creating' if v['status'] == 'creating' else 'stopped')
    if include_secret:
        d['ssh_user'] = v['ssh_user']
        d['ssh_password'] = v['ssh_password']
    return d

# --- User API ---

@app.route('/api/v1/user/vms', methods=['GET'])
def api_user_vms():
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('user')
    if err:
        return err
    vms = db_execute("SELECT * FROM vm_instances WHERE user_id=? ORDER BY created_at DESC", (row['user_id'],), fetch=True) or []
    return jsonify({'success': True, 'vms': [_vm_dict(v) for v in vms]})

@app.route('/api/v1/user/vms/<vm_id>', methods=['GET'])
def api_user_vm_detail(vm_id):
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('user')
    if err:
        return err
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v or (v['user_id'] != row['user_id'] and row['role'] != 'admin'):
        return jsonify({'success': False, 'error': 'Not found'}), 404
    return jsonify({'success': True, 'vm': _vm_dict(v)})

@app.route('/api/v1/user/vms/<vm_id>/<action>', methods=['POST'])
def api_user_vm_action(vm_id, action):
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('user')
    if err:
        return err
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v or (v['user_id'] != row['user_id'] and row['role'] != 'admin'):
        return jsonify({'success': False, 'error': 'Not found'}), 404
    if action not in ('start', 'stop', 'restart'):
        return jsonify({'success': False, 'error': 'Invalid action'}), 400
    fws = db_execute("SELECT host_port, guest_port, protocol FROM port_forwards WHERE vm_id=?", (vm_id,), fetch=True) or []
    extra = [dict(r) for r in fws]
    nested = bool(v['nested_kvm']) if 'nested_kvm' in v.keys() else False
    pub = v['public_ip'] if 'public_ip' in v.keys() else None
    priv = v['private_ip'] if 'private_ip' in v.keys() else None
    serial = v['serial_port'] if 'serial_port' in v.keys() and v['serial_port'] else v['vnc_port']
    if action == 'start':
        r, _ = vm.vm_status(vm_id)
        if r:
            return jsonify({'success': False, 'message': 'Already running'})
        if v['ssh_port'] and int(v['ssh_port']) != 22:
            subprocess.run(['fuser', '-k', f'{v["ssh_port"]}/tcp'], capture_output=True)
        pid = vm.start_vm(vm_id, v['os_template'], v['ram_mb'], v['cpu_cores'], v['storage_gb'],
                          v['ssh_port'], serial, v['network_mode'] or 'private', pub, priv, extra, nested)
        if pid:
            db_execute("UPDATE vm_instances SET status='running', pid=? WHERE vm_id=?", (pid, vm_id))
            return jsonify({'success': True, 'message': 'Started'})
        return jsonify({'success': False, 'message': 'Failed to start'})
    if action == 'stop':
        r, pid = vm.vm_status(vm_id)
        if not r:
            return jsonify({'success': False, 'message': 'Not running'})
        vm.stop_vm(pid, v['ssh_port'])
        db_execute("UPDATE vm_instances SET status='stopped', pid=NULL WHERE vm_id=?", (vm_id,))
        return jsonify({'success': True, 'message': 'Stopped'})
    # restart
    r, pid = vm.vm_status(vm_id)
    if r:
        vm.stop_vm(pid, v['ssh_port'])
        time.sleep(2)
    if v['ssh_port'] and int(v['ssh_port']) != 22:
        subprocess.run(['fuser', '-k', f'{v["ssh_port"]}/tcp'], capture_output=True)
    np = vm.start_vm(vm_id, v['os_template'], v['ram_mb'], v['cpu_cores'], v['storage_gb'],
                     v['ssh_port'], serial, v['network_mode'] or 'private', pub, priv, extra, nested)
    if np:
        db_execute("UPDATE vm_instances SET status='running', pid=? WHERE vm_id=?", (np, vm_id))
        return jsonify({'success': True, 'message': 'Restarted'})
    return jsonify({'success': False, 'message': 'Restart failed'})

# --- Admin API ---

@app.route('/api/v1/admin/vms', methods=['GET'])
def api_admin_vms():
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    vms = db_execute("SELECT * FROM vm_instances ORDER BY created_at DESC", fetch=True) or []
    return jsonify({'success': True, 'vms': [_vm_dict(v) for v in vms]})

@app.route('/api/v1/admin/vms', methods=['POST'])
def api_admin_create_vm():
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    data = request.json or {}
    name = (data.get('name') or '').strip()
    ost = data.get('os_template', 'ubuntu-22.04')
    if not name or ost not in OS_TEMPLATES:
        return jsonify({'success': False, 'error': 'name and valid os_template required'}), 400
    ram = int(data.get('ram_mb', 2048))
    cpu = int(data.get('cpu_cores', 2))
    stor = int(data.get('storage_gb', 20))
    uid = int(data.get('user_id', row['user_id']))
    network_mode = data.get('network_mode', 'private')
    nested_kvm = 1 if data.get('nested_kvm') else 0
    root_pw = generate_vm_password(12)
    vid = str(uuid.uuid4())
    sp = allocate_host_port()
    serial = allocate_host_port()
    private_ip = allocate_private_ip() if network_mode == 'private' else None
    if network_mode == 'public':
        sp = 22
    nid = ensure_local_node()
    ssh_host = PUBLIC_IP
    db_execute(
        "INSERT INTO vm_instances "
        "(vm_id, user_id, name, os_template, ram_mb, cpu_cores, storage_gb, "
        "ssh_port, ssh_host, ssh_user, ssh_password, network_mode, public_ip, "
        "private_ip, node_id, vnc_port, serial_port, status, creation_step, accel_mode, nested_kvm) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (vid, uid, name, ost, ram, cpu, stor, sp, ssh_host, 'root', root_pw,
         network_mode, None, private_ip, nid, serial, serial, 'creating', 'Starting...',
         'kvm' if HAVE_KVM else 'tcg', nested_kvm)
    )
    threading.Thread(target=complete_vm_setup,
                     args=(vid, ost, ram, cpu, stor, sp, serial, network_mode, None, private_ip),
                     daemon=True).start()
    return jsonify({'success': True, 'vm_id': vid, 'ssh_port': sp, 'message': 'VM creating'})

@app.route('/api/v1/admin/vms/<vm_id>', methods=['DELETE'])
def api_admin_delete_vm(vm_id):
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False, 'message': 'Not found'}), 404
    r, pid = vm.vm_status(vm_id)
    if r:
        vm.stop_vm(pid, v['ssh_port'])
    if v['public_ip']:
        db_execute("UPDATE public_ips SET is_available=1, assigned_vm_id=NULL WHERE ip_address=?", (v['public_ip'],))
    db_execute("DELETE FROM port_forwards WHERE vm_id=?", (vm_id,))
    d = VM_DIR / vm_id
    if d.exists():
        shutil.rmtree(d, ignore_errors=True)
    db_execute("DELETE FROM vm_instances WHERE vm_id=?", (vm_id,))
    return jsonify({'success': True, 'message': 'Deleted'})

@app.route('/api/v1/admin/users', methods=['GET'])
def api_admin_users():
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    users = db_execute("SELECT id, username, email, role, is_active, created_at FROM users ORDER BY id", fetch=True) or []
    return jsonify({'success': True, 'users': [dict(u) for u in users]})


@app.route('/api/v1/admin/users', methods=['POST'])
def api_admin_create_user():
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    data = request.json or {}
    username = (data.get('username') or '').strip()
    email = (data.get('email') or '').strip()
    password = data.get('password') or ''
    role = data.get('role', 'user')
    if not username or not email or not password:
        return jsonify({'success': False, 'error': 'username, email, password required'}), 400
    if role not in ('user', 'admin'):
        role = 'user'
    try:
        db_execute("INSERT INTO users (username, email, password, role) VALUES (?,?,?,?)",
                   (username, email, generate_password_hash(password, method='scrypt'), role))
        u = db_execute("SELECT id, username, email, role FROM users WHERE username=?", (username,), fetchone=True)
        return jsonify({'success': True, 'user': dict(u)})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400

@app.route('/api/v1/admin/users/<int:user_id>', methods=['PATCH', 'PUT'])
def api_admin_edit_user(user_id):
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    u = db_execute("SELECT * FROM users WHERE id=?", (user_id,), fetchone=True)
    if not u:
        return jsonify({'success': False, 'error': 'Not found'}), 404
    data = request.json or {}
    username = (data.get('username') or u['username']).strip()
    email = (data.get('email') or u['email']).strip()
    role = data.get('role', u['role'])
    is_active = data.get('is_active', u['is_active'])
    is_active = 1 if is_active in (True, 1, '1', 'true', 'on') else 0
    try:
        if data.get('password'):
            db_execute("UPDATE users SET username=?, email=?, role=?, is_active=?, password=? WHERE id=?",
                       (username, email, role, is_active, generate_password_hash(data['password'], method='scrypt'), user_id))
        else:
            db_execute("UPDATE users SET username=?, email=?, role=?, is_active=? WHERE id=?",
                       (username, email, role, is_active, user_id))
        return jsonify({'success': True, 'message': 'Updated'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400

@app.route('/api/v1/admin/users/<int:user_id>', methods=['DELETE'])
def api_admin_delete_user(user_id):
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    if user_id == row['user_id']:
        return jsonify({'success': False, 'error': 'Cannot delete yourself'}), 400
    db_execute("DELETE FROM users WHERE id=?", (user_id,))
    return jsonify({'success': True, 'message': 'Deleted'})

@app.route('/api/v1/admin/vms/<vm_id>', methods=['GET'])
def api_admin_vm_detail(vm_id):
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return jsonify({'success': False, 'error': 'Not found'}), 404
    return jsonify({'success': True, 'vm': _vm_dict(v), 'progress': v['creation_progress'], 'step': v['creation_step']})

@app.route('/api/v1/admin/vms/<vm_id>/<action>', methods=['POST'])
def api_admin_vm_action(vm_id, action):
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    # reuse user action logic with elevated access by temp treating as owner
    return api_user_vm_action(vm_id, action)

@app.route('/api/v1/admin/public-ips', methods=['GET', 'POST'])
def api_admin_public_ips():
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    if request.method == 'GET':
        ips = db_execute("SELECT * FROM public_ips ORDER BY ip_address", fetch=True) or []
        return jsonify({'success': True, 'ips': [dict(i) for i in ips]})
    data = request.json or {}
    ip = (data.get('ip_address') or '').strip()
    if not ip:
        return jsonify({'success': False, 'error': 'ip_address required'}), 400
    try:
        db_execute("INSERT INTO public_ips (ip_address, label, notes) VALUES (?,?,?)",
                   (ip, data.get('label') or '', data.get('notes') or ''))
        return jsonify({'success': True, 'message': 'Added'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400

@app.route('/api/v1/admin/nodes', methods=['GET', 'POST'])
def api_admin_nodes():
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    if request.method == 'POST' and (request.json or {}).get('action') == 'ensure_local':
        nid = ensure_local_node()
        return jsonify({'success': True, 'node_id': nid, 'message': 'Local node ready'})
    ensure_local_node()
    nodes = db_execute("SELECT * FROM nodes ORDER BY is_local DESC, name", fetch=True) or []
    return jsonify({'success': True, 'nodes': [dict(n) for n in nodes]})

@app.route('/api/v1/admin/os-templates', methods=['GET'])
def api_admin_os_templates():
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    out = {k: {'name': v['name'], 'default_user': v['default_user']} for k, v in OS_TEMPLATES.items()}
    return jsonify({'success': True, 'templates': out})

@app.route('/api/v1/admin/settings', methods=['GET', 'POST'])
def api_admin_settings():
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    locked = {'site_version', 'valid_license_key', 'license_activated', 'license_key_entered', 'license_activated_at'}
    if request.method == 'GET':
        settings = {r['key']: r['value'] for r in (db_execute("SELECT * FROM settings", fetch=True) or [])}
        for k in list(settings.keys()):
            if k in locked or k not in SETTINGS_ALLOWLIST:
                settings.pop(k, None)
        return jsonify({'success': True, 'settings': settings})
    data = request.json or {}
    for k, v in data.items():
        if k in locked or k not in SETTINGS_ALLOWLIST:
            continue
        val = str(v)[:2000]
        if k == 'background_url' and val and not (val.startswith('https://') or val.startswith('/')):
            continue
        db_execute("INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?,?,CURRENT_TIMESTAMP)", (k, val))
    return jsonify({'success': True, 'message': 'Saved'})

@app.route('/api/v1/admin/audit', methods=['GET'])
def api_admin_audit():
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('admin')
    if err:
        return err
    if row['role'] != 'admin':
        return jsonify({'success': False, 'error': 'Admin only'}), 403
    logs = db_execute("SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT 100", fetch=True) or []
    return jsonify({'success': True, 'logs': [dict(l) for l in logs]})

@app.route('/api/v1/user/vms/<vm_id>/progress', methods=['GET'])
def api_user_vm_progress(vm_id):
    if not is_licensed():
        return jsonify({'success': False, 'error': 'License required'}), 403
    row, err = api_auth('user')
    if err:
        return err
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v or (v['user_id'] != row['user_id'] and row['role'] != 'admin'):
        return jsonify({'success': False, 'error': 'Not found'}), 404
    running, _ = vm.vm_status(vm_id)
    return jsonify({
        'success': True,
        'progress': int(v['creation_progress'] or 0),
        'step': v['creation_step'] or '',
        'status': v['status'],
        'running': running,
    })

@app.route('/api/v1/keys', methods=['GET', 'POST'])
@login_required
def api_keys_manage():
    """Web UI helper: list/create API keys for current user."""
    if request.method == 'POST':
        name = (request.form.get('name') or request.json.get('name') if request.is_json else request.form.get('name') or 'default')
        requested = ''
        if request.is_json and request.json:
            requested = (request.json.get('scope') or 'user')
        else:
            requested = request.form.get('scope') or 'user'
        requested = str(requested).strip().lower()
        # Token only gets permissions explicitly granted; admin scope only if account is admin
        if requested == 'admin' and session.get('role') == 'admin':
            scope = 'admin'
        else:
            scope = 'user'
        raw = _issue_api_key(session['user_id'], name, scope)
        if request.is_json:
            return jsonify({'success': True, 'api_key': raw, 'scope': scope, 'message': 'Store this key — it will not be shown again.'})
        flash(f'API key created (copy now): {raw}', 'success')
        return redirect(url_for('profile'))
    keys = db_execute("SELECT id, name, key_prefix, scope, created_at, last_used, is_active FROM api_keys WHERE user_id=? ORDER BY created_at DESC", (session['user_id'],), fetch=True) or []
    return jsonify({'success': True, 'keys': [dict(k) for k in keys]})

@app.route('/api/v1/keys/<int:kid>/revoke', methods=['POST'])
@login_required
def api_keys_revoke(kid):
    db_execute("UPDATE api_keys SET is_active=0 WHERE id=? AND user_id=?", (kid, session['user_id']))
    if request.is_json:
        return jsonify({'success': True})
    flash('Key revoked.', 'info')
    return redirect(url_for('profile'))


# ==================== Discord Bot Integration ====================
# Runs inside the same process as the panel, in its own thread with its
# own asyncio event loop. Talks directly to the DB / VMManager — no HTTP
# round-trip needed. Enable + configure from Settings.

_discord_bot_thread = None
_discord_bot_loop = None
_discord_bot_client = None
_discord_bot_status = {'running': False, 'error': None, 'connected_as': None}

def _discord_available():
    try:
        import discord  # noqa
        return True
    except ImportError:
        return False

def _bot_is_admin(ctx_or_interaction):
    try:
        author_id = str(ctx_or_interaction.author.id)
    except Exception:
        author_id = None
    if author_id:
        admin_ids = [x.strip() for x in (gsv('discord_admin_ids', '') or '').split(',') if x.strip()]
        if author_id in admin_ids:
            return True
    try:
        return bool(ctx_or_interaction.author.guild_permissions.administrator)
    except Exception:
        return False

def _get_panel_user_by_discord(discord_id):
    return db_execute("SELECT * FROM users WHERE discord_id=?", (str(discord_id),), fetchone=True)

def _resolve_owned_vm(ctx, vm_id):
    """Returns (vm_row, error_message). Allows access if the caller registered
    this VM themselves, or if they have Discord Administrator on this server."""
    v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
    if not v:
        return None, "VM not found. Use `akvm!myvms` to see your VM IDs."
    if _bot_is_admin(ctx):
        return v, None
    u = _get_panel_user_by_discord(ctx.author.id)
    if not u or v['user_id'] != u['id']:
        return None, "That's not your VM."
    return v, None

def _build_discord_client():
    import discord
    from discord.ext import commands
    import io as _io

    intents = discord.Intents.default()
    intents.message_content = True
    bot = commands.Bot(command_prefix="akvm!", intents=intents, help_command=None)

    def _no_perm_embed():
        return discord.Embed(title="Not allowed", description="You need **Administrator** permission on this server to use that command.", color=0xef4444)

    @bot.event
    async def on_ready():
        _discord_bot_status['running'] = True
        _discord_bot_status['error'] = None
        _discord_bot_status['connected_as'] = str(bot.user)
        # Set the bot's Discord avatar to match the panel logo — only once
        # (Discord rate-limits avatar changes, so we don't retry every reconnect).
        if (gsv('discord_bot_avatar_set', 'false') or 'false').lower() not in ('1', 'true', 'yes'):
            try:
                logo_path = BASE_DIR / 'static' / 'uploads' / 'sidebar-icon.png'
                if logo_path.exists():
                    with open(logo_path, 'rb') as f:
                        await bot.user.edit(avatar=f.read())
                    _set_setting('discord_bot_avatar_set', 'true')
            except Exception as e:
                logging.getLogger('akvm.bot').warning(f"Could not set bot avatar: {e}")

    @bot.event
    async def on_command_error(ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return
        if isinstance(error, commands.MissingRequiredArgument):
            return await ctx.reply(f"Missing argument: `{error.param.name}`. Try `akvm!help`.")
        await ctx.reply(f"❌ {error}")

    # ---------------- Self-service (any Discord member) ----------------

    @bot.command(name="register")
    async def cmd_register(ctx, username: str, email: str, password: str):
        if _get_panel_user_by_discord(ctx.author.id):
            return await ctx.reply("You already have a linked account. Use `akvm!myvms` to see your VMs.")
        try:
            db_execute("INSERT INTO users (username, email, password, role, discord_id) VALUES (?,?,?,?,?)",
                       (username, email, generate_password_hash(password, method='scrypt'), 'user', str(ctx.author.id)))
        except Exception as e:
            return await ctx.reply(f"❌ Could not register: {e}")
        try:
            await ctx.message.delete()  # scrub the plaintext password from chat history
        except Exception:
            pass
        await ctx.send(f"{ctx.author.mention} ✅ Account **{username}** created and linked to your Discord. Run `akvm!create` to get your free VM.")

    @bot.command(name="create")
    async def cmd_create(ctx):
        u = _get_panel_user_by_discord(ctx.author.id)
        if not u:
            return await ctx.reply("You need an account first — run `akvm!register <username> <email> <password>`.")
        limit = int(gsv('discord_free_vm_limit', '1') or 1)
        existing = db_execute("SELECT COUNT(*) c FROM vm_instances WHERE user_id=?", (u['id'],), fetchone=True)
        if existing and existing['c'] >= limit:
            return await ctx.reply(f"You already have {existing['c']} VM(s) — the free limit is {limit}. Use `akvm!myvms` to manage them.")
        ost = gsv('discord_free_vm_os', 'ubuntu-22.04') or 'ubuntu-22.04'
        if ost not in OS_TEMPLATES:
            ost = 'ubuntu-22.04'
        ram = int(gsv('discord_free_vm_ram_mb', '8192') or 8192)
        cpu = int(gsv('discord_free_vm_cpu_cores', '2') or 2)
        stor = int(gsv('discord_free_vm_storage_gb', '40') or 40)
        vid = str(uuid.uuid4())
        sp = allocate_host_port()
        serial = allocate_host_port()
        private_ip = allocate_private_ip()
        nid = ensure_local_node()
        root_pw = generate_vm_password(12)
        name = f"{ctx.author.name}-free"
        db_execute(
            "INSERT INTO vm_instances "
            "(vm_id, user_id, name, os_template, ram_mb, cpu_cores, storage_gb, "
            "ssh_port, ssh_host, ssh_user, ssh_password, network_mode, public_ip, "
            "private_ip, node_id, vnc_port, serial_port, status, creation_step, accel_mode, nested_kvm) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (vid, u['id'], name, ost, ram, cpu, stor, sp, PUBLIC_IP, 'root', root_pw,
             'private', None, private_ip, nid, serial, serial, 'creating', 'Starting...',
             'kvm' if HAVE_KVM else 'tcg', 0)
        )
        threading.Thread(target=complete_vm_setup,
                          args=(vid, ost, ram, cpu, stor, sp, serial, 'private', None, private_ip),
                          daemon=True).start()
        await ctx.reply(f"🚀 Creating your free VM (`{vid}`) — {cpu} vCPU · {ram}MB RAM · {stor}GB disk · {ost}.\nCheck progress with `akvm!vmstatus {vid}`. Login details will be in `akvm!myvms` once it's ready.")

    @bot.command(name="myvms")
    async def cmd_myvms(ctx):
        u = _get_panel_user_by_discord(ctx.author.id)
        if not u:
            return await ctx.reply("You don't have an account yet — run `akvm!register <username> <email> <password>`.")
        rows = db_execute("SELECT * FROM vm_instances WHERE user_id=? ORDER BY created_at DESC", (u['id'],), fetch=True) or []
        if not rows:
            return await ctx.reply("You have no VMs yet. Run `akvm!create` to get a free one.")
        embed = discord.Embed(title="Your VMs", color=0xd98f3f)
        for v in rows:
            running, _ = vm.vm_status(v['vm_id'])
            state = "🟢 running" if running else "⚪ stopped"
            embed.add_field(
                name=f"{v['name']} — {state}",
                value=f"`{v['vm_id']}`\n{v['cpu_cores']} vCPU · {v['ram_mb']}MB · {v['storage_gb']}GB\n`ssh {v['ssh_user']}@{v['ssh_host'] or PUBLIC_IP} -p {v['ssh_port']}`",
                inline=False
            )
        await ctx.reply(embed=embed)

    async def _do_power(ctx, vm_id, action):
        v, err = _resolve_owned_vm(ctx, vm_id)
        if err:
            return await ctx.reply(f"❌ {err}")
        fws = db_execute("SELECT host_port, guest_port, protocol FROM port_forwards WHERE vm_id=?", (vm_id,), fetch=True) or []
        extra = [dict(r) for r in fws]
        nested = bool(v['nested_kvm']) if 'nested_kvm' in v.keys() else False
        pub = v['public_ip'] if 'public_ip' in v.keys() else None
        priv = v['private_ip'] if 'private_ip' in v.keys() else None
        serial = v['serial_port'] if 'serial_port' in v.keys() and v['serial_port'] else v['vnc_port']
        try:
            if action == 'start':
                running, _ = vm.vm_status(vm_id)
                if running:
                    return await ctx.reply("Already running.")
                if v['ssh_port'] and int(v['ssh_port']) != 22:
                    subprocess.run(['fuser', '-k', f'{v["ssh_port"]}/tcp'], capture_output=True)
                pid = vm.start_vm(vm_id, v['os_template'], v['ram_mb'], v['cpu_cores'], v['storage_gb'],
                                   v['ssh_port'], serial, v['network_mode'] or 'private', pub, priv, extra, nested)
                if pid:
                    db_execute("UPDATE vm_instances SET status='running', pid=? WHERE vm_id=?", (pid, vm_id))
                    return await ctx.reply(f"✅ Started **{v['name']}**.")
                return await ctx.reply("❌ Failed to start.")
            if action == 'stop':
                running, pid = vm.vm_status(vm_id)
                if not running:
                    return await ctx.reply("Not running.")
                vm.stop_vm(pid, v['ssh_port'])
                db_execute("UPDATE vm_instances SET status='stopped', pid=NULL WHERE vm_id=?", (vm_id,))
                return await ctx.reply(f"🛑 Stopped **{v['name']}**.")
            if action == 'restart':
                running, pid = vm.vm_status(vm_id)
                if running:
                    vm.stop_vm(pid, v['ssh_port'])
                    time.sleep(2)
                if v['ssh_port'] and int(v['ssh_port']) != 22:
                    subprocess.run(['fuser', '-k', f'{v["ssh_port"]}/tcp'], capture_output=True)
                np = vm.start_vm(vm_id, v['os_template'], v['ram_mb'], v['cpu_cores'], v['storage_gb'],
                                  v['ssh_port'], serial, v['network_mode'] or 'private', pub, priv, extra, nested)
                if np:
                    db_execute("UPDATE vm_instances SET status='running', pid=? WHERE vm_id=?", (np, vm_id))
                    return await ctx.reply(f"🔄 Restarted **{v['name']}**.")
                return await ctx.reply("❌ Restart failed.")
            if action == 'delete':
                running, pid = vm.vm_status(vm_id)
                if running:
                    vm.stop_vm(pid, v['ssh_port'])
                if v['public_ip']:
                    db_execute("UPDATE public_ips SET is_available=1, assigned_vm_id=NULL WHERE ip_address=?", (v['public_ip'],))
                db_execute("DELETE FROM port_forwards WHERE vm_id=?", (vm_id,))
                d = VM_DIR / vm_id
                if d.exists():
                    shutil.rmtree(d, ignore_errors=True)
                db_execute("DELETE FROM vm_instances WHERE vm_id=?", (vm_id,))
                return await ctx.reply(f"🗑️ Deleted **{v['name']}**.")
        except Exception as e:
            return await ctx.reply(f"❌ Error: {e}")

    @bot.command(name="vmstart")
    async def cmd_vmstart(ctx, vm_id: str):
        await _do_power(ctx, vm_id, 'start')

    @bot.command(name="vmstop")
    async def cmd_vmstop(ctx, vm_id: str):
        await _do_power(ctx, vm_id, 'stop')

    @bot.command(name="vmrestart")
    async def cmd_vmrestart(ctx, vm_id: str):
        await _do_power(ctx, vm_id, 'restart')

    @bot.command(name="vmdelete")
    async def cmd_vmdelete(ctx, vm_id: str, confirm: str = ""):
        if confirm.lower() != "confirm":
            return await ctx.reply(f"This deletes the VM permanently. Run `akvm!vmdelete {vm_id} confirm` to proceed.")
        await _do_power(ctx, vm_id, 'delete')

    # ---------------- Bot file manager (own VM, or admin) ----------------

    @bot.command(name="files")
    async def cmd_files(ctx, vm_id: str, path: str = "/"):
        v, err = _resolve_owned_vm(ctx, vm_id)
        if err:
            return await ctx.reply(f"❌ {err}")
        running, _ = vm.vm_status(vm_id)
        if not running:
            return await ctx.reply("VM is not running. Start it first with `akvm!vmstart`.")
        p = safe_remote_path(path)
        try:
            with sftp_connect(v) as sftp:
                entries = sftp.listdir_attr(p)
        except Exception as e:
            return await ctx.reply(f"❌ {e}")
        if not entries:
            return await ctx.reply(f"`{p}` is empty.")
        lines = []
        for e in sorted(entries, key=lambda x: (not stat.S_ISDIR(x.st_mode), x.filename.lower()))[:40]:
            is_dir = stat.S_ISDIR(e.st_mode)
            lines.append(f"{'📁' if is_dir else '📄'} {e.filename}" + ('' if is_dir else f" ({e.st_size}B)"))
        embed = discord.Embed(title=f"{v['name']} — {p}", description="\n".join(lines), color=0xd98f3f)
        await ctx.reply(embed=embed)

    @bot.command(name="download")
    async def cmd_download(ctx, vm_id: str, path: str):
        v, err = _resolve_owned_vm(ctx, vm_id)
        if err:
            return await ctx.reply(f"❌ {err}")
        running, _ = vm.vm_status(vm_id)
        if not running:
            return await ctx.reply("VM is not running.")
        p = safe_remote_path(path)
        try:
            with sftp_connect(v) as sftp:
                st = sftp.stat(p)
                if stat.S_ISDIR(st.st_mode):
                    return await ctx.reply("That's a directory — use `akvm!files` to browse it.")
                if (st.st_size or 0) > 8 * 1024 * 1024:
                    return await ctx.reply("File too large to send via Discord (>8MB). Use the panel's Files page instead.")
                buf = _io.BytesIO()
                sftp.getfo(p, buf)
                buf.seek(0)
        except Exception as e:
            return await ctx.reply(f"❌ {e}")
        await ctx.reply(file=discord.File(buf, filename=posixpath.basename(p) or 'file'))

    @bot.command(name="upload")
    async def cmd_upload(ctx, vm_id: str, path: str):
        v, err = _resolve_owned_vm(ctx, vm_id)
        if err:
            return await ctx.reply(f"❌ {err}")
        running, _ = vm.vm_status(vm_id)
        if not running:
            return await ctx.reply("VM is not running.")
        if not ctx.message.attachments:
            return await ctx.reply("Attach the file you want to upload to this message.")
        att = ctx.message.attachments[0]
        data = await att.read()
        p = safe_remote_path(path)
        try:
            with sftp_connect(v) as sftp:
                sftp.putfo(_io.BytesIO(data), p)
        except Exception as e:
            return await ctx.reply(f"❌ {e}")
        await ctx.reply(f"✅ Uploaded `{att.filename}` → `{p}`")

    @bot.command(name="exec")
    async def cmd_exec(ctx, vm_id: str, *, command: str):
        v, err = _resolve_owned_vm(ctx, vm_id)
        if err:
            return await ctx.reply(f"❌ {err}")
        running, _ = vm.vm_status(vm_id)
        if not running:
            return await ctx.reply("VM is not running.")
        async with ctx.typing():
            try:
                out = await asyncio.get_event_loop().run_in_executor(
                    None, lambda: vm.ssh_exec(v['ssh_port'], command, v['ssh_password'], v['ssh_user'] or 'root', 30)
                )
            except Exception as e:
                return await ctx.reply(f"❌ {e}")
        text = (out or '').strip() or '(no output)'
        if len(text) > 1900:
            text = text[:1900] + "\n… (truncated)"
        await ctx.reply(f"```\n{text}\n```")

    # ---------------- Admin-only ----------------

    @bot.command(name="vms")
    async def cmd_vms(ctx):
        if not _bot_is_admin(ctx):
            return await ctx.reply(embed=_no_perm_embed())
        rows = db_execute("SELECT vm_id, name, status, ram_mb, cpu_cores, storage_gb FROM vm_instances ORDER BY created_at DESC LIMIT 25", fetch=True) or []
        if not rows:
            return await ctx.reply("No VMs found.")
        embed = discord.Embed(title="AKVM — All VMs", color=0xd98f3f)
        for r in rows:
            running, _ = vm.vm_status(r['vm_id'])
            state = "🟢 running" if running else "⚪ stopped"
            embed.add_field(name=f"{r['name']} — {state}", value=f"`{r['vm_id']}`\n{r['cpu_cores']} vCPU · {r['ram_mb']}MB · {r['storage_gb']}GB", inline=False)
        await ctx.reply(embed=embed)

    @bot.command(name="vmstatus")
    async def cmd_vmstatus(ctx, vm_id: str):
        v = db_execute("SELECT * FROM vm_instances WHERE vm_id=?", (vm_id,), fetchone=True)
        if not v:
            return await ctx.reply("VM not found.")
        if not _bot_is_admin(ctx):
            u = _get_panel_user_by_discord(ctx.author.id)
            if not u or v['user_id'] != u['id']:
                return await ctx.reply(embed=_no_perm_embed())
        running, pid = vm.vm_status(vm_id)
        embed = discord.Embed(title=v['name'], color=0x22c55e if running else 0x6b6b74)
        embed.add_field(name="Status", value="🟢 running" if running else "⚪ stopped", inline=True)
        embed.add_field(name="OS", value=v['os_template'], inline=True)
        embed.add_field(name="Spec", value=f"{v['cpu_cores']} vCPU · {v['ram_mb']}MB · {v['storage_gb']}GB", inline=True)
        embed.add_field(name="SSH", value=f"`ssh {v['ssh_user']}@{v['ssh_host'] or PUBLIC_IP} -p {v['ssh_port']}`", inline=False)
        embed.add_field(name="VM ID", value=f"`{vm_id}`", inline=False)
        await ctx.reply(embed=embed)

    @bot.command(name="vmcreate")
    async def cmd_vmcreate(ctx, name: str, os_template: str, ram_mb: int = 2048, cpu_cores: int = 2, storage_gb: int = 20, owner_username: str = ""):
        if not _bot_is_admin(ctx):
            return await ctx.reply(embed=_no_perm_embed())
        if os_template not in OS_TEMPLATES:
            valid = ", ".join(sorted(OS_TEMPLATES.keys()))
            return await ctx.reply(f"Invalid os_template. Valid: {valid}")
        uid = None
        if owner_username:
            u = db_execute("SELECT id FROM users WHERE username=?", (owner_username,), fetchone=True)
            if not u:
                return await ctx.reply(f"No panel user named `{owner_username}`.")
            uid = u['id']
        else:
            admin_row = db_execute("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1", fetchone=True)
            uid = admin_row['id'] if admin_row else 1
        vid = str(uuid.uuid4())
        sp = allocate_host_port()
        serial = allocate_host_port()
        private_ip = allocate_private_ip()
        nid = ensure_local_node()
        root_pw = generate_vm_password(12)
        db_execute(
            "INSERT INTO vm_instances "
            "(vm_id, user_id, name, os_template, ram_mb, cpu_cores, storage_gb, "
            "ssh_port, ssh_host, ssh_user, ssh_password, network_mode, public_ip, "
            "private_ip, node_id, vnc_port, serial_port, status, creation_step, accel_mode, nested_kvm) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (vid, uid, name, os_template, ram_mb, cpu_cores, storage_gb, sp, PUBLIC_IP, 'root', root_pw,
             'private', None, private_ip, nid, serial, serial, 'creating', 'Starting...',
             'kvm' if HAVE_KVM else 'tcg', 0)
        )
        threading.Thread(target=complete_vm_setup,
                          args=(vid, os_template, ram_mb, cpu_cores, storage_gb, sp, serial, 'private', None, private_ip),
                          daemon=True).start()
        await ctx.reply(f"🚀 Creating **{name}** (`{vid}`). Check `akvm!vmstatus {vid}` for progress.")

    @bot.command(name="oslist")
    async def cmd_oslist(ctx):
        keys = ", ".join(f"`{k}`" for k in sorted(OS_TEMPLATES.keys()))
        await ctx.reply(f"Available OS templates:\n{keys}")

    @bot.command(name="users")
    async def cmd_users(ctx):
        if not _bot_is_admin(ctx):
            return await ctx.reply(embed=_no_perm_embed())
        rows = db_execute("SELECT username, email, role, is_active FROM users ORDER BY id LIMIT 25", fetch=True) or []
        if not rows:
            return await ctx.reply("No users found.")
        lines = [f"{'🟢' if r['is_active'] else '⚪'} **{r['username']}** ({r['role']}) — {r['email']}" for r in rows]
        embed = discord.Embed(title="AKVM — Users", description="\n".join(lines), color=0xd98f3f)
        await ctx.reply(embed=embed)

    @bot.command(name="adduser")
    async def cmd_adduser(ctx, username: str, email: str, password: str, role: str = "user"):
        if not _bot_is_admin(ctx):
            return await ctx.reply(embed=_no_perm_embed())
        if role not in ('user', 'admin'):
            role = 'user'
        try:
            db_execute("INSERT INTO users (username, email, password, role) VALUES (?,?,?,?)",
                       (username, email, generate_password_hash(password, method='scrypt'), role))
            await ctx.reply(f"✅ Created user **{username}** ({role}).")
        except Exception as e:
            await ctx.reply(f"❌ Failed: {e}")

    @bot.command(name="admin")
    async def cmd_admin(ctx, member: discord.Member):
        if not _bot_is_admin(ctx):
            return await ctx.reply(embed=_no_perm_embed())
        u = _get_panel_user_by_discord(member.id)
        if not u:
            return await ctx.reply(f"{member.mention} hasn't linked a panel account yet — they need to run `akvm!register` first.")
        if u['role'] == 'admin':
            return await ctx.reply(f"**{u['username']}** is already an admin.")
        db_execute("UPDATE users SET role='admin' WHERE id=?", (u['id'],))
        audit(u['id'], 'discord_promote_admin', f"by discord:{ctx.author.id}")
        await ctx.reply(f"✅ **{u['username']}** ({member.mention}) is now a panel admin.")

    @bot.command(name="ping")
    async def cmd_ping(ctx):
        latency_ms = round(bot.latency * 1000)
        await ctx.reply(f"🏓 Pong — {latency_ms}ms")

    @bot.command(name="whoami")
    async def cmd_whoami(ctx):
        u = _get_panel_user_by_discord(ctx.author.id)
        if not u:
            return await ctx.reply("You don't have a linked account yet — run `akvm!register <username> <email> <password>`.")
        count = db_execute("SELECT COUNT(*) c FROM vm_instances WHERE user_id=?", (u['id'],), fetchone=True)
        embed = discord.Embed(title=u['username'], color=0xd98f3f)
        embed.add_field(name="Role", value=u['role'], inline=True)
        embed.add_field(name="Email", value=u['email'], inline=True)
        embed.add_field(name="VMs", value=str(count['c'] if count else 0), inline=True)
        embed.add_field(name="Active", value="Yes" if row_get(u, 'is_active', 1) else "No — deactivated", inline=True)
        await ctx.reply(embed=embed)

    @bot.command(name="unregister")
    async def cmd_unregister(ctx, confirm: str = ""):
        u = _get_panel_user_by_discord(ctx.author.id)
        if not u:
            return await ctx.reply("You don't have a linked account.")
        if confirm.lower() != "confirm":
            return await ctx.reply(f"This unlinks **{u['username']}** from your Discord account (the panel account itself is kept — you can still log in with your password). Run `akvm!unregister confirm` to proceed.")
        db_execute("UPDATE users SET discord_id=NULL WHERE id=?", (u['id'],))
        await ctx.reply("✅ Unlinked. Your panel account still exists — log in with your username/password on the website.")

    @bot.command(name="reinstall")
    async def cmd_reinstall(ctx, vm_id: str, confirm: str = ""):
        v, err = _resolve_owned_vm(ctx, vm_id)
        if err:
            return await ctx.reply(f"❌ {err}")
        if confirm.lower() != "confirm":
            return await ctx.reply(f"This will **wipe all data** on **{v['name']}** and reinstall {v['os_template']} fresh. Run `akvm!reinstall {vm_id} confirm` to proceed.")
        running, pid = vm.vm_status(vm_id)
        if running:
            vm.stop_vm(pid, row_get(v, 'ssh_port'))
            time.sleep(1)
        try:
            d = (VM_DIR / vm_id).resolve()
            if str(d).startswith(str(VM_DIR.resolve())) and d.exists():
                shutil.rmtree(d, ignore_errors=True)
            d.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            return await ctx.reply(f"❌ Wipe failed: {e}")
        root_pw = generate_vm_password(12)
        db_execute(
            "UPDATE vm_instances SET status='creating', creation_progress=1, creation_step=?, "
            "ssh_password=?, pid=NULL WHERE vm_id=?",
            ('Reinstall queued (via Discord)…', root_pw, vm_id)
        )
        threading.Thread(
            target=complete_vm_setup,
            args=(
                vm_id, v['os_template'], v['ram_mb'], v['cpu_cores'], v['storage_gb'],
                v['ssh_port'], row_get(v, 'serial_port') or row_get(v, 'vnc_port'),
                row_get(v, 'network_mode') or 'private',
                row_get(v, 'public_ip'), row_get(v, 'private_ip'),
            ),
            daemon=True,
        ).start()
        audit(None, 'discord_reinstall_vm', f'{v["name"]} ({vm_id[:8]}) by discord:{ctx.author.id}')
        await ctx.reply(f"🔄 Reinstalling **{v['name']}** — check `akvm!vmstatus {vm_id}` for progress.")

    @bot.command(name="resetpw")
    async def cmd_resetpw(ctx, username: str, new_password: str):
        if not _bot_is_admin(ctx):
            return await ctx.reply(embed=_no_perm_embed())
        u = db_execute("SELECT * FROM users WHERE username=?", (username,), fetchone=True)
        if not u:
            return await ctx.reply(f"No panel user named `{username}`.")
        db_execute("UPDATE users SET password=? WHERE id=?", (generate_password_hash(new_password, method='scrypt'), u['id']))
        audit(u['id'], 'discord_resetpw', f"by discord:{ctx.author.id}")
        try:
            await ctx.message.delete()
        except Exception:
            pass
        await ctx.send(f"✅ Password reset for **{username}**.")

    @bot.command(name="removeuser")
    async def cmd_removeuser(ctx, username: str, confirm: str = ""):
        if not _bot_is_admin(ctx):
            return await ctx.reply(embed=_no_perm_embed())
        u = db_execute("SELECT * FROM users WHERE username=?", (username,), fetchone=True)
        if not u:
            return await ctx.reply(f"No panel user named `{username}`.")
        if confirm.lower() != "confirm":
            vm_count = db_execute("SELECT COUNT(*) c FROM vm_instances WHERE user_id=?", (u['id'],), fetchone=True)
            return await ctx.reply(f"**{username}** has {vm_count['c'] if vm_count else 0} VM(s). This deactivates their account (VMs are kept, untouched). Run `akvm!removeuser {username} confirm` to proceed.")
        db_execute("UPDATE users SET is_active=0 WHERE id=?", (u['id'],))
        audit(u['id'], 'discord_deactivate_user', f"by discord:{ctx.author.id}")
        await ctx.reply(f"✅ **{username}** has been deactivated (can no longer log in). Their VMs were left untouched.")

    @bot.command(name="notify")
    async def cmd_notify(ctx, member: discord.Member, *, message: str):
        if not _bot_is_admin(ctx):
            return await ctx.reply(embed=_no_perm_embed())
        u = _get_panel_user_by_discord(member.id)
        if not u:
            return await ctx.reply(f"{member.mention} hasn't linked a panel account yet.")
        db_execute("INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)",
                   (u['id'], 'Message from admin', message, 'info'))
        await ctx.reply(f"✅ Sent a panel notification to **{u['username']}**.")

    @bot.command(name="ipstatus")
    async def cmd_ipstatus(ctx):
        if not _bot_is_admin(ctx):
            return await ctx.reply(embed=_no_perm_embed())
        total = db_execute("SELECT COUNT(*) c FROM public_ips", fetchone=True)
        used = db_execute("SELECT COUNT(*) c FROM public_ips WHERE is_available=0", fetchone=True)
        t = total['c'] if total else 0
        us = used['c'] if used else 0
        await ctx.reply(f"📡 Public IP pool: **{us}/{t}** in use, **{t - us}** free.")

    @bot.command(name="scan")
    async def cmd_scan(ctx, vm_id: str):
        v, err = _resolve_owned_vm(ctx, vm_id)
        if err:
            return await ctx.reply(f"❌ {err}")
        running, _ = vm.vm_status(vm_id)
        if not running:
            return await ctx.reply("VM is not running — start it first.")
        msg = await ctx.reply("🔍 Scanning for crypto-miners and intrusion signs…")
        scan = scan_vm_for_threats(v)
        audit(None, 'discord_security_scan', f"{v['name']} by discord:{ctx.author.id}")
        embed = discord.Embed(
            title=f"Security Scan — {v['name']}",
            color=0xef4444 if (scan['ok'] and (scan['miner_detected'] or scan['suspicious_cron'])) else 0x22c55e,
            description=scan_summary_text(scan)
        )
        if scan.get('matched_processes'):
            embed.add_field(name="Matched processes", value=", ".join(scan['matched_processes']), inline=False)
        try:
            await msg.edit(content=None, embed=embed)
        except Exception:
            await ctx.reply(embed=embed)

    @bot.command(name="scanall")
    async def cmd_scanall(ctx):
        if not _bot_is_admin(ctx):
            return await ctx.reply(embed=_no_perm_embed())
        rows = db_execute("SELECT * FROM vm_instances", fetch=True) or []
        running_vms = [r for r in rows if vm.vm_status(r['vm_id'])[0]]
        if not running_vms:
            return await ctx.reply("No running VMs to scan.")
        msg = await ctx.reply(f"🔍 Scanning {len(running_vms)} running VM(s)…")
        flagged = []
        for r in running_vms:
            scan = scan_vm_for_threats(r)
            if scan['ok'] and (scan['miner_detected'] or scan['suspicious_cron'] or scan['failed_logins'] > 20):
                flagged.append((r['name'], r['vm_id'], scan))
        if not flagged:
            return await msg.edit(content=f"✅ Scanned {len(running_vms)} VM(s) — nothing suspicious found.")
        embed = discord.Embed(title=f"Security Scan — {len(flagged)} VM(s) flagged", color=0xef4444)
        for name, vid, scan in flagged[:20]:
            embed.add_field(name=f"{name} ({vid[:8]})", value=scan_summary_text(scan), inline=False)
        await msg.edit(content=None, embed=embed)

    @bot.command(name="help", aliases=["akvmhelp"])
    async def cmd_help(ctx):
        embed = discord.Embed(title="AKVM Bot — Commands", color=0xd98f3f, description=(
            "**Get started**\n"
            "`akvm!register username email password` — create your account\n"
            "`akvm!create` — get your free VM\n"
            "`akvm!myvms` — list your VMs\n"
            "`akvm!whoami` — your account info\n"
            "`akvm!unregister confirm` — unlink Discord from your account\n"
            "`akvm!ping` — check the bot is alive\n\n"
            "**Your VMs**\n"
            "`akvm!vmstart id` · `akvm!vmstop id` · `akvm!vmrestart id`\n"
            "`akvm!vmdelete id confirm` · `akvm!reinstall id confirm`\n"
            "`akvm!files id [path]` — browse files\n"
            "`akvm!download id path` — download a file\n"
            "`akvm!upload id path` — attach a file to upload it\n"
            "`akvm!exec id command` — run a shell command\n\n"
            "**Admin only**\n"
            "`akvm!vms` · `akvm!vmstatus id` · `akvm!vmcreate name os [ram] [cpu] [disk] [owner]`\n"
            "`akvm!oslist` · `akvm!users` · `akvm!adduser username email password [role]`\n"
            "`akvm!admin @user` — promote to admin\n"
            "`akvm!resetpw username newpassword` — reset a user's password\n"
            "`akvm!removeuser username confirm` — deactivate a user\n"
            "`akvm!notify @user message` — send them a panel notification\n"
            "`akvm!ipstatus` — public IP pool usage\n"
            "`akvm!scan id` — check one VM for miners/intrusion signs\n"
            "`akvm!scanall` — scan every running VM"
        ))
        await ctx.reply(embed=embed)

    return bot

def _run_discord_bot_thread(token):
    global _discord_bot_loop, _discord_bot_client
    import asyncio
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    _discord_bot_loop = loop
    try:
        client = _build_discord_client()
        _discord_bot_client = client
        loop.run_until_complete(client.start(token))
    except Exception as e:
        _discord_bot_status['running'] = False
        _discord_bot_status['error'] = str(e)
        logging.getLogger('akvm.bot').error(f"Discord bot crashed: {e}")
    finally:
        _discord_bot_status['running'] = False

def start_discord_bot():
    global _discord_bot_thread
    if not _discord_available():
        _discord_bot_status['error'] = "discord.py not installed — run: pip install discord.py"
        return False
    if _discord_bot_thread and _discord_bot_thread.is_alive():
        return True
    token = (gsv('discord_bot_token', '') or '').strip()
    if not token:
        _discord_bot_status['error'] = "No bot token configured"
        return False
    _discord_bot_status['error'] = None
    _discord_bot_thread = threading.Thread(target=_run_discord_bot_thread, args=(token,), daemon=True)
    _discord_bot_thread.start()
    return True

def stop_discord_bot():
    global _discord_bot_thread, _discord_bot_loop, _discord_bot_client
    if _discord_bot_client and _discord_bot_loop:
        try:
            import asyncio
            asyncio.run_coroutine_threadsafe(_discord_bot_client.close(), _discord_bot_loop)
        except Exception:
            pass
    _discord_bot_status['running'] = False
    _discord_bot_status['connected_as'] = None

@app.route('/admin/settings/discord-bot', methods=['POST'])
@admin_required
def admin_settings_discord_bot():
    token = (request.form.get('discord_bot_token') or '').strip()
    guild_id = (request.form.get('discord_bot_guild_id') or '').strip()
    enabled = 'discord_bot_enabled' in request.form
    if token:
        _set_setting('discord_bot_token', token)
    _set_setting('discord_bot_guild_id', guild_id)
    _set_setting('discord_bot_enabled', 'true' if enabled else 'false')

    admin_ids_raw = request.form.get('discord_admin_ids')
    if admin_ids_raw is not None:
        cleaned = [x.strip() for x in admin_ids_raw.split(',') if x.strip().isdigit()]
        _set_setting('discord_admin_ids', ','.join(cleaned))

    ost = (request.form.get('discord_free_vm_os') or '').strip()
    if ost and ost in OS_TEMPLATES:
        _set_setting('discord_free_vm_os', ost)
    for field, default in (
        ('discord_free_vm_ram_mb', 8192),
        ('discord_free_vm_cpu_cores', 2),
        ('discord_free_vm_storage_gb', 40),
        ('discord_free_vm_limit', 1),
    ):
        raw = (request.form.get(field) or '').strip()
        if raw.isdigit():
            _set_setting(field, str(max(0, int(raw))))

    stop_discord_bot()
    time.sleep(0.3)
    if enabled:
        ok = start_discord_bot()
        if ok:
            flash('Discord settings saved — bot (re)connecting, check akvm!help in Discord.', 'success')
        else:
            flash(f"Could not start bot: {_discord_bot_status.get('error')}", 'danger')
    else:
        flash('Discord settings saved.', 'success')
    audit(session['user_id'], 'discord_bot_config', f'enabled={enabled}')
    return redirect(url_for('admin_discord_bot'))

@app.route('/admin/settings/discord-bot/status')
@admin_required
def admin_settings_discord_bot_status():
    return jsonify({
        'running': _discord_bot_status.get('running', False),
        'error': _discord_bot_status.get('error'),
        'connected_as': _discord_bot_status.get('connected_as'),
        'installed': _discord_available(),
    })


if __name__ == '__main__':
    init_db()
    start_license_check_thread()
    start_security_scan_thread()
    if (gsv('discord_bot_enabled', 'false') or 'false').lower() in ('1', 'true', 'yes'):
        if _discord_available():
            start_discord_bot()
        else:
            print("  [AKVM] Discord bot enabled in settings but discord.py is not installed.")
            print("         Run: pip install discord.py")
    print(f"\n{'='*50}")
    print(f"  AKVM Panel v1.0")
    print(f"  URL:  http://{PUBLIC_IP}:5000")
    print(f"  Login: admin / admin123")
    print(f"  Accel: {'KVM' if HAVE_KVM else 'TCG (no /dev/kvm)'}")
    print(f"{'='*50}\n")
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
