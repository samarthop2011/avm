#!/usr/bin/env bash
#
# AKVM Panel — One-Command Installer
# Usage:
#   sudo bash install.sh
#   or:  curl -fsSL https://YOUR_HOST/install.sh | sudo bash
#
set -euo pipefail

# ---------- colors ----------
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${CYAN}[AKVM]${NC} $1"; }
ok()    { echo -e "${GREEN}[OK]${NC} $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()   { echo -e "${RED}[ERROR]${NC} $1"; }

# ---------- must be root ----------
if [[ "${EUID}" -ne 0 ]]; then
  err "Please run as root (sudo bash install.sh)"
  exit 1
fi

# ---------- config ----------
INSTALL_DIR="${AKVM_INSTALL_DIR:-/opt/akvm}"
REPO_URL="${AKVM_REPO_URL:-https://github.com/Akvmpanel/v1.git}"
SERVICE_NAME="akvm"
PANEL_PORT="${AKVM_PORT:-5000}"
PY_BIN="python3"
DOMAIN="${AKVM_DOMAIN:-}"

# Detect if we're running from a local checkout (e.g. `bash install.sh` inside
# the extracted folder) vs piped via `curl | bash` (no local files exist).
LOCAL_SRC=""
if [[ -n "${BASH_SOURCE:-}" ]]; then
  _src_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd || true)"
  if [[ -n "$_src_dir" && -f "$_src_dir/akvm.py" ]]; then
    LOCAL_SRC="$_src_dir"
  fi
fi

echo ""
echo -e "${CYAN}=========================================${NC}"
echo -e "${CYAN}   AKVM Panel — Installer${NC}"
echo -e "${CYAN}=========================================${NC}"
echo ""

# ---------- detect OS ----------
if [[ -f /etc/os-release ]]; then
  . /etc/os-release
  OS_ID="${ID:-unknown}"
else
  OS_ID="unknown"
fi

if [[ "$OS_ID" != "ubuntu" && "$OS_ID" != "debian" ]]; then
  warn "This installer is built for Ubuntu/Debian. Detected: $OS_ID"
  read -rp "Continue anyway? [y/N]: " cont
  [[ "$cont" =~ ^[Yy]$ ]] || exit 1
fi

# ---------- platform detection (Railway, and similar managed PaaS) ----------
# On Railway (and most managed container platforms), you don't run your own
# nginx/certbot — the platform's own edge network terminates TLS and proxies
# to your container. Trying to bind port 80/443 yourself there is pointless
# (traffic never reaches it that way) and privileged operations are blocked
# anyway. Detect it and skip straight past the nginx/SSL section.
ON_RAILWAY=0
if [[ -n "${RAILWAY_ENVIRONMENT:-}" || -n "${RAILWAY_PROJECT_ID:-}" || -n "${RAILWAY_SERVICE_ID:-}" ]]; then
  ON_RAILWAY=1
fi

# ---------- domain (optional) ----------
# If not passed via AKVM_DOMAIN and we're running interactively (a real
# terminal, not piped with no stdin), ask for it. Leave blank to skip and
# just use http://IP:PORT.
if [[ "$ON_RAILWAY" -eq 1 ]]; then
  if [[ -n "$DOMAIN" ]]; then
    warn "Domain '${DOMAIN}' given, but this looks like Railway — skipping nginx/certbot."
    warn "On Railway, set the domain from the dashboard instead: Service -> Settings ->"
    warn "Networking -> Custom Domain (Railway issues the SSL cert automatically)."
  fi
  DOMAIN=""
elif [[ -z "$DOMAIN" && -t 0 ]]; then
  read -rp "Domain for this panel (leave blank to skip, use IP:${PANEL_PORT} instead): " DOMAIN
fi

# ---------- install host dependencies ----------
info "Updating package lists..."
apt update -y

# Unhold git from any previous run of this script (older versions held it,
# which can conflict with bundled security-update transactions).
apt-mark unhold git >/dev/null 2>&1 || true
dpkg --configure -a >/dev/null 2>&1 || true

# --no-upgrade: only install what's missing, never upgrade packages that
# are already present. This avoids two container-filesystem issues at once:
#  - "Invalid cross-device link" when dpkg tries to upgrade an in-use binary
#    like git on some overlay filesystems
#  - "Held packages were changed" when apt bundles git/curl/wget together
#    into one upgrade transaction just because sshpass needs installing
info "Installing host dependencies (qemu, cloud-image-utils, python, etc)..."
if ! apt install -y --no-upgrade \
  qemu-system-x86 qemu-utils cloud-image-utils \
  wget curl sshpass openssh-client git \
  python3 python3-pip python3-venv \
  cpu-checker psmisc net-tools unzip; then
    warn "apt install hit an error — attempting to fix broken packages and retry..."
    apt-get install -f -y || true
    dpkg --configure -a || true
    apt install -y --no-upgrade \
      qemu-system-x86 qemu-utils cloud-image-utils \
      wget curl sshpass openssh-client git \
      python3 python3-pip python3-venv \
      cpu-checker psmisc net-tools unzip
fi

ok "Host dependencies installed."

if [[ -n "$DOMAIN" ]]; then
  info "Domain provided (${DOMAIN}) — installing Nginx + Certbot..."
  apt install -y --no-upgrade nginx certbot python3-certbot-nginx
  ok "Nginx + Certbot installed."
fi

# ---------- KVM check ----------
info "Checking for hardware virtualization (KVM)..."
if kvm-ok >/dev/null 2>&1; then
  ok "KVM is available — VMs will run at near-native speed."
else
  warn "KVM not available on this host — VMs will fall back to TCG (slower software emulation)."
  warn "If this is a VPS, ask your provider to enable nested virtualization."
fi

# ---------- get app files (local copy or fresh clone) ----------
if [[ -n "$LOCAL_SRC" && "$LOCAL_SRC" != "$INSTALL_DIR" ]]; then
  info "Installing AKVM from local files (${LOCAL_SRC})..."
  mkdir -p "$INSTALL_DIR"
  cp -r "$LOCAL_SRC"/. "$INSTALL_DIR"/
elif [[ -n "$LOCAL_SRC" ]]; then
  info "Already running from ${INSTALL_DIR}"
else
  info "Downloading AKVM from ${REPO_URL}..."
  rm -rf "$INSTALL_DIR"
  git clone --depth 1 "$REPO_URL" "$INSTALL_DIR"
fi
cd "$INSTALL_DIR"

# ---------- python venv + deps ----------
info "Creating Python virtual environment..."
$PY_BIN -m venv venv
source venv/bin/activate

info "Installing Python dependencies..."
pip install --upgrade pip >/dev/null
pip install -r requirements.txt

ok "Python environment ready."
deactivate

# ---------- service: systemd if available, otherwise nohup + watchdog ----------
# Docker/LXC containers usually don't run systemd as PID 1, so `systemctl`
# doesn't exist there. Detect that and fall back to a simple background
# process + a watchdog loop that restarts it if it dies (poor man's Restart=on-failure).
HAS_SYSTEMD=0
if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  HAS_SYSTEMD=1
fi

if [[ "$HAS_SYSTEMD" -eq 1 ]]; then
  info "Creating systemd service (auto-start on boot)..."
  cat > /etc/systemd/system/${SERVICE_NAME}.service <<EOF
[Unit]
Description=AKVM Panel
After=network.target

[Service]
Type=simple
WorkingDirectory=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/venv/bin/python ${INSTALL_DIR}/akvm.py
Restart=on-failure
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable ${SERVICE_NAME} >/dev/null 2>&1
  systemctl restart ${SERVICE_NAME}

  sleep 2

  if systemctl is-active --quiet ${SERVICE_NAME}; then
    ok "AKVM Panel service is running."
  else
    err "Service failed to start. Check logs with: journalctl -u ${SERVICE_NAME} -e"
    exit 1
  fi
else
  warn "No systemd here (PID 1 is not systemd — you're likely inside Docker/LXC)."
  info "Starting AKVM Panel with a nohup + auto-restart watchdog instead..."

  mkdir -p "${INSTALL_DIR}/run"
  PIDFILE="${INSTALL_DIR}/run/akvm.pid"
  LOGFILE="${INSTALL_DIR}/run/akvm.log"
  WATCHDOG_PIDFILE="${INSTALL_DIR}/run/watchdog.pid"

  # Kill any previous instance from an earlier install run.
  [[ -f "$PIDFILE" ]] && kill "$(cat "$PIDFILE")" >/dev/null 2>&1 || true
  [[ -f "$WATCHDOG_PIDFILE" ]] && kill "$(cat "$WATCHDOG_PIDFILE")" >/dev/null 2>&1 || true
  pkill -f "${INSTALL_DIR}/venv/bin/python ${INSTALL_DIR}/akvm.py" >/dev/null 2>&1 || true

  cat > "${INSTALL_DIR}/run/watchdog.sh" <<EOF
#!/usr/bin/env bash
# Restarts akvm.py whenever it exits. Runs in the background.
cd "${INSTALL_DIR}"
while true; do
  PYTHONUNBUFFERED=1 "${INSTALL_DIR}/venv/bin/python" "${INSTALL_DIR}/akvm.py" >> "${LOGFILE}" 2>&1 &
  echo \$! > "${PIDFILE}"
  wait \$!
  echo "[\$(date)] AKVM exited, restarting in 5s..." >> "${LOGFILE}"
  sleep 5
done
EOF
  chmod +x "${INSTALL_DIR}/run/watchdog.sh"

  nohup "${INSTALL_DIR}/run/watchdog.sh" >/dev/null 2>&1 &
  disown
  echo $! > "$WATCHDOG_PIDFILE"

  sleep 3

  if [[ -f "$PIDFILE" ]] && kill -0 "$(cat "$PIDFILE")" >/dev/null 2>&1; then
    ok "AKVM Panel is running (PID $(cat "$PIDFILE"), watchdog PID $(cat "$WATCHDOG_PIDFILE"))."
    info "Logs: tail -f ${LOGFILE}"
    warn "This container has no init system, so AKVM won't survive a container restart on its own."
    warn "Re-run this installer (or just: bash ${INSTALL_DIR}/run/watchdog.sh &) after the container restarts,"
    warn "or better: run this container with a proper entrypoint / --restart policy from the Docker host side."
  else
    err "Panel failed to start. Check: tail -n 100 ${LOGFILE}"
    exit 1
  fi
fi

# ---------- nginx reverse proxy + SSL (only if a domain was given) ----------
SSL_OK=0
if [[ -n "$DOMAIN" ]]; then
  info "Configuring Nginx reverse proxy for ${DOMAIN}..."
  # Everything in this block is best-effort: a failure here should warn and
  # move on, never kill the whole install (the panel itself is already up
  # by this point). Temporarily disable `set -e` for that reason.
  set +e

  cat > /etc/nginx/sites-available/${SERVICE_NAME} <<EOF
server {
    listen 80;
    server_name ${DOMAIN};

    location / {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 3600s;
    }
}
EOF
  ln -sf /etc/nginx/sites-available/${SERVICE_NAME} /etc/nginx/sites-enabled/${SERVICE_NAME}
  rm -f /etc/nginx/sites-enabled/default

  NGINX_UP=0
  if nginx -t >/tmp/akvm-nginx-test.log 2>&1; then
    if [[ "$HAS_SYSTEMD" -eq 1 ]]; then
      if systemctl reload nginx 2>/tmp/akvm-nginx-start.log || systemctl restart nginx 2>>/tmp/akvm-nginx-start.log; then
        NGINX_UP=1
      fi
    else
      # No systemd: try a live reload first (works if nginx is already
      # running); if that fails, kill any stale master and start fresh.
      if nginx -s reload >/tmp/akvm-nginx-start.log 2>&1; then
        NGINX_UP=1
      else
        pkill nginx >/dev/null 2>&1
        sleep 1
        if nginx 2>>/tmp/akvm-nginx-start.log; then
          NGINX_UP=1
        fi
      fi
    fi
    if [[ "$NGINX_UP" -eq 1 ]]; then
      ok "Nginx is proxying ${DOMAIN} -> 127.0.0.1:${PANEL_PORT}"
    else
      err "Nginx config was valid but the server failed to (re)start. Log:"
      tail -n 20 /tmp/akvm-nginx-start.log 2>/dev/null || true
      warn "Panel is still reachable directly at http://<server-ip>:${PANEL_PORT}"
    fi
  else
    err "Nginx config test failed — check /etc/nginx/sites-available/${SERVICE_NAME}. Log:"
    tail -n 20 /tmp/akvm-nginx-test.log 2>/dev/null || true
  fi

  if [[ "$NGINX_UP" -eq 1 ]]; then
    info "Requesting SSL certificate for ${DOMAIN} (Let's Encrypt)..."
    warn "Make sure ${DOMAIN}'s DNS A record already points at this server's IP, or this will fail."
    if certbot --nginx -d "${DOMAIN}" --non-interactive --agree-tos -m "admin@${DOMAIN}" --redirect; then
      ok "SSL certificate installed — panel is now on https://${DOMAIN}"
      SSL_OK=1
    else
      warn "Certbot failed (DNS not pointed here yet, or port 80/443 blocked?). Panel is still reachable over plain http://${DOMAIN}"
      warn "Fix DNS/firewall, then rerun: certbot --nginx -d ${DOMAIN}"
    fi
  else
    warn "Skipping SSL request since Nginx isn't running yet — fix Nginx first, then rerun:"
    warn "  certbot --nginx -d ${DOMAIN}"
  fi

  set -e
fi

# ---------- done ----------
SERVER_IP=$(curl -s -4 ifconfig.me || hostname -I | awk '{print $1}')

# ---------- license ----------
info "Reading AKVM license key..."
LICENSE_OUT="$("${INSTALL_DIR}/venv/bin/python" - "$INSTALL_DIR" <<'PYEOF' 2>/dev/null || true
import os, sys, sqlite3, hmac, hashlib
inst = sys.argv[1]
db = os.path.join(inst, 'akvm.db')
secret = "akvm-9f3c7a1e-59b2-4d8a-b6ce-2f0a7e4c1d6b-do-not-share"
try:
    con = sqlite3.connect(db)
    iid = None
    for r in con.execute("SELECT value FROM settings WHERE key='license_install_id'"):
        iid = r[0]
    if not iid:
        iid = os.urandom(6).hex()
        con.execute("INSERT OR REPLACE INTO settings (key,value,updated_at) VALUES ('license_install_id',?,CURRENT_TIMESTAMP)", (iid,))
        con.commit()
    d = hmac.new(secret.encode(), iid.encode(), hashlib.sha256).hexdigest().upper()
    groups = [d[i:i+5] for i in range(0,20,5)]
    print("IID=%s" % iid)
    print("KEY=AKVM-%s-%s-%s-%s" % tuple(groups))
except Exception as e:
    print("ERR=%s" % e)
PYEOF
)"
LKEY="$(printf '%s\n' "$LICENSE_OUT" | grep '^KEY=' | cut -d= -f2-)"
LIID="$(printf '%s\n' "$LICENSE_OUT" | grep '^IID=' | cut -d= -f2-)"

echo ""
echo -e "${GREEN}=========================================${NC}"
echo -e "${GREEN}   AKVM Panel installed successfully!${NC}"
echo -e "${GREEN}=========================================${NC}"
echo ""
if [[ -n "$DOMAIN" && "$SSL_OK" -eq 1 ]]; then
  echo -e "  Panel URL:     ${CYAN}https://${DOMAIN}${NC}"
elif [[ -n "$DOMAIN" ]]; then
  echo -e "  Panel URL:     ${CYAN}http://${DOMAIN}${NC}  (SSL not active yet — see warning above)"
  echo -e "  Fallback URL:  ${CYAN}http://${SERVER_IP}:${PANEL_PORT}${NC}"
elif [[ "$ON_RAILWAY" -eq 1 ]]; then
  echo -e "  Panel is listening on port ${CYAN}${PANEL_PORT}${NC} inside the container."
  echo -e "  In the Railway dashboard: Service -> Settings -> Networking ->"
  echo -e "  set the Target Port to ${CYAN}${PANEL_PORT}${NC}, then Generate Domain (or add a"
  echo -e "  Custom Domain) — Railway will expose it over https:// with its own SSL cert."
else
  echo -e "  Panel URL:     ${CYAN}http://${SERVER_IP}:${PANEL_PORT}${NC}"
fi
echo -e "  Install path:  ${CYAN}${INSTALL_DIR}${NC}"
echo -e "  Default login: ${CYAN}admin / admin123${NC}  (change this immediately!)"
if [[ -n "$LKEY" && -n "$LIID" ]]; then
  echo ""
  echo -e "  ${GREEN}── AKVM License ──${NC}"
  echo -e "  Install ID:  ${CYAN}${LIID}${NC}"
  echo -e "  License Key: ${CYAN}${LKEY}${NC}"
  echo -e "  (Enter this key on the License page to activate.)"
else
  warn "Could not read license key (panel DB not ready yet)."
  warn "After the panel starts, open Admin → License to see your Install ID and request a key."
fi
echo ""
if [[ "$HAS_SYSTEMD" -eq 1 ]]; then
  echo -e "  Manage service:"
  echo -e "    systemctl status ${SERVICE_NAME}"
  echo -e "    systemctl restart ${SERVICE_NAME}"
  echo -e "    journalctl -u ${SERVICE_NAME} -f"
else
  echo -e "  No systemd in this environment — managed by a background watchdog instead:"
  echo -e "    tail -f ${INSTALL_DIR}/run/akvm.log        # view logs"
  echo -e "    kill \$(cat ${INSTALL_DIR}/run/akvm.pid)     # stop akvm (watchdog restarts it — kill watchdog too if you want it to stay stopped)"
  echo -e "    kill \$(cat ${INSTALL_DIR}/run/watchdog.pid) # stop the watchdog (and akvm won't auto-restart anymore)"
  echo -e "    bash ${INSTALL_DIR}/run/watchdog.sh &        # start it again later"
fi
echo ""
