#!/usr/bin/env bash
# Restarts AKVM Panel without systemd — for containers/sandboxes where
# `systemctl` isn't available (e.g. "systemd is not running in this container").
#
# Usage:
#   bash restart.sh
#
set -e
cd "$(dirname "${BASH_SOURCE[0]}")"

echo "Stopping any running akvm.py process..."
pkill -f "python.*akvm\.py" 2>/dev/null || true
sleep 1

if [ -d venv ]; then
    source venv/bin/activate
fi

echo "Installing/updating dependencies..."
pip install -r requirements.txt --quiet --break-system-packages 2>/dev/null || pip install -r requirements.txt --quiet

echo "Starting AKVM Panel in the background..."
nohup python3 akvm.py > akvm.log 2>&1 &
disown

sleep 2
echo ""
echo "Started. Tail logs with:  tail -f akvm.log"
echo "Stop it again with:       pkill -f 'python.*akvm.py'"
