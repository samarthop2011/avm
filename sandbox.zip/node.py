#!/usr/bin/env python3
"""
AKVM Node Agent v1.0
Run on additional hosts to register as compute nodes with the panel.

Usage:
  export AKVM_PANEL_URL=http://panel-ip:5000
  export AKVM_NODE_TOKEN=your_register_token   # set in Panel → Settings
  export AKVM_NODE_NAME=node-2
  export AKVM_AGENT_PORT=5050
  python3 node.py

The agent:
  - Registers with the panel
  - Sends heartbeats (CPU/RAM/disk/KVM)
  - Exposes a small API the panel can call later for remote VM ops
"""

import os, sys, time, socket, threading, json, subprocess
from pathlib import Path

try:
    import psutil
except ImportError:
    print("Install: pip install psutil flask requests")
    sys.exit(1)

try:
    import requests
except ImportError:
    print("Install: pip install requests")
    sys.exit(1)

from flask import Flask, request, jsonify

PANEL_URL = os.environ.get('AKVM_PANEL_URL', 'http://127.0.0.1:5000').rstrip('/')
REGISTER_TOKEN = os.environ.get('AKVM_NODE_TOKEN', '')
NODE_NAME = os.environ.get('AKVM_NODE_NAME', socket.gethostname())
AGENT_PORT = int(os.environ.get('AKVM_AGENT_PORT', '5050'))
AGENT_HOST = os.environ.get('AKVM_AGENT_HOST', '0.0.0.0')
HEARTBEAT_SECS = int(os.environ.get('AKVM_HEARTBEAT', '30'))
AGENT_VERSION = '1.0'

VM_DIR = Path(os.environ.get('AKVM_VM_DIR', './vm_instances_node')).absolute()
VM_DIR.mkdir(exist_ok=True)

node_token = None  # issued by panel after register
node_id = None

app = Flask(__name__)


def has_kvm():
    try:
        return os.path.exists('/dev/kvm') and os.access('/dev/kvm', os.R_OK | os.W_OK)
    except Exception:
        return False


def host_stats():
    return {
        'cpu_cores': psutil.cpu_count() or 1,
        'ram_mb': int(psutil.virtual_memory().total / (1024 * 1024)),
        'disk_gb': int(psutil.disk_usage('/').total / (1024 ** 3)),
        'has_kvm': has_kvm(),
        'hostname': socket.gethostname(),
    }


def register():
    global node_token, node_id
    stats = host_stats()
    # public URL of this agent (panel will call back)
    api_url = os.environ.get('AKVM_AGENT_URL', f'http://{socket.gethostbyname(socket.gethostname())}:{AGENT_PORT}')
    payload = {
        'token': REGISTER_TOKEN,
        'name': NODE_NAME,
        'hostname': stats['hostname'],
        'api_url': api_url,
        'has_kvm': stats['has_kvm'],
        'cpu_cores': stats['cpu_cores'],
        'ram_mb': stats['ram_mb'],
        'disk_gb': stats['disk_gb'],
        'agent_version': AGENT_VERSION,
    }
    r = requests.post(f'{PANEL_URL}/api/node/register', json=payload, timeout=15)
    r.raise_for_status()
    data = r.json()
    if not data.get('success'):
        raise RuntimeError(data.get('message', 'register failed'))
    node_token = data['node_token']
    node_id = data.get('node_id')
    print(f"[OK] Registered as node_id={node_id} name={NODE_NAME}")
    return data


def heartbeat_loop():
    while True:
        try:
            if not node_token:
                time.sleep(5)
                continue
            stats = host_stats()
            payload = {'token': node_token, **stats}
            requests.post(f'{PANEL_URL}/api/node/heartbeat', json=payload, timeout=10)
        except Exception as e:
            print(f"[heartbeat] {e}")
        time.sleep(HEARTBEAT_SECS)


@app.route('/health')
def health():
    return jsonify({
        'ok': True,
        'node': NODE_NAME,
        'node_id': node_id,
        'has_kvm': has_kvm(),
        'agent_version': AGENT_VERSION,
    })


@app.route('/api/status')
def status():
    auth = request.headers.get('X-Node-Token', '')
    if node_token and auth != node_token:
        return jsonify({'success': False}), 403
    return jsonify({'success': True, **host_stats(), 'node_id': node_id})


def main():
    if not REGISTER_TOKEN:
        print("Set AKVM_NODE_TOKEN to the panel's node_register_token (Settings).")
        sys.exit(1)
    print(f"AKVM Node Agent {AGENT_VERSION}")
    print(f"  Panel: {PANEL_URL}")
    print(f"  Name:  {NODE_NAME}")
    print(f"  KVM:   {has_kvm()}")
    try:
        register()
    except Exception as e:
        print(f"Register failed: {e}")
        sys.exit(1)
    threading.Thread(target=heartbeat_loop, daemon=True).start()
    print(f"Agent API on {AGENT_HOST}:{AGENT_PORT}")
    app.run(host=AGENT_HOST, port=AGENT_PORT, debug=False, threaded=True)


if __name__ == '__main__':
    main()
