# AKVM Panel v1.0

Modern KVM management panel with dark UI (HKVM-inspired), public IP pool, web console, and working cloud-init.

## Features

- **Dark modern UI** matching HKVM Panel style (sidebar, cards, stats)
- **Admin-only VM creation** — regular users cannot create VMs
- **Public IPv4 pool** — store public IPs and assign them when deploying
- **Private (NAT) or Public** network mode per VM
- **Cloud-init** with:
  - `root` user + password
  - OS default sudo user (`ubuntu` / `debian`) with same password
  - SSH password auth + PermitRootLogin
  - Root FS resize
- **Web Terminal (SSH console)** via Paramiko
- **QEMU serial** console + web SSH shell
- **SSH** works out of the box (hostfwd + cloud-init)
- Fixed **edit VM** (port conflict checks, disk grow, password update)
- User management, settings, audit log, notifications

## Requirements (host)

```bash
sudo apt update
sudo apt install -y qemu-system-x86 qemu-utils cloud-image-utils wget curl sshpass python3-pip python3-venv
# KVM support
sudo apt install -y cpu-checker
kvm-ok
```

## Install & Run

### Quick install (recommended)

One command sets up everything — host dependencies, Python venv, and a systemd service so the panel auto-starts on boot:

```bash
cd akvm
sudo bash install.sh
```

That's it. It will print the panel URL when done (default `http://YOUR_IP:5000`).

Manage it afterward with:
```bash
systemctl status akvm
systemctl restart akvm
journalctl -u akvm -f
```

During install, the script automatically prints your **AKVM License Key** and **Install ID** (see the `── AKVM License ──` block in the output). Enter that key on the **License** page to activate the panel.

### Manual install

```bash
cd akvm
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python akvm.py
```

Open `http://YOUR_IP:5000`

**Default login:** `admin` / `admin123`

## Notes

- VMs use user-mode networking + SSH port forward. Public IP is stored/displayed and used as the advertised SSH host; traffic still hits the host on the assigned port.
- For true L2 public IP binding you would need bridge/macvtap setup on the host (not included for safety/simplicity).
- Change the default root password under **Settings**.
- Only **admins** can create / edit / delete VMs and manage users & public IPs.


## License

Each install has its own **Install ID**. The matching **License Key** is derived
from it (HMAC-SHA256) and is printed automatically during `install.sh` in the
`── AKVM License ──` block.

To show your license key again at any time, run:

```bash
pythan3 show_license.py
```

(If your install lives elsewhere, point the script at your `akvm` directory —
usage: `python show_license.py /path/to/akvm`.)

Then enter the key on **Admin → License** to activate the panel. A revoked
install is automatically locked by the periodic revocation check.


## Additional nodes (node.py)

1. In Panel → Settings set **Node register token**.
2. On another host:

```bash
pip install flask requests psutil
export AKVM_PANEL_URL=http://PANEL_IP:5000
export AKVM_NODE_TOKEN=your_token
export AKVM_NODE_NAME=node-2
export AKVM_AGENT_PORT=5050
python3 node.py
```

3. The node appears under **Management → Nodes**.

## Nested KVM / CPU

- Nested KVM on → `-cpu host,+vmx,+svm` (guest can use KVM)
- Nested off + host KVM → `-cpu kvm64`
- No host KVM → TCG `-cpu qemu64`

## SMBIOS

Configured under Settings — shows as manufacturer/product in neofetch/fastfetch (default manufacturer: Michael).


## REST API

Create a key under **Profile → API Keys**.

```bash
# User API — list my VMs
curl -H "Authorization: Bearer YOUR_KEY" http://HOST:5000/api/v1/user/vms

# User API — start / stop / restart
curl -X POST -H "Authorization: Bearer YOUR_KEY" http://HOST:5000/api/v1/user/vms/VM_ID/start

# Admin API — list all VMs
curl -H "Authorization: Bearer ADMIN_KEY" http://HOST:5000/api/v1/admin/vms

# Admin API — create VM
curl -X POST -H "Authorization: Bearer ADMIN_KEY" -H "Content-Type: application/json" \
  -d '{"name":"web1","os_template":"ubuntu-24.04","ram_mb":2048,"cpu_cores":2,"storage_gb":20}' \
  http://HOST:5000/api/v1/admin/vms

# Admin API — delete VM
curl -X DELETE -H "Authorization: Bearer ADMIN_KEY" http://HOST:5000/api/v1/admin/vms/VM_ID
```

Passwords are never returned by the API list/detail endpoints.


## License verification

The product key is **not** stored in plaintext. Activation compares a salted SHA-256
digest against XOR-masked material embedded in the binary. Tampering with
`license_activated` in the database is insufficient without a matching digest.
