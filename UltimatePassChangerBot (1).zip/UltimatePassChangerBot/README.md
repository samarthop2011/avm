# Ultimate Pass Changer Bot — PUBLIC

Merged Microsoft / Minecraft account pass changer Discord bot.
**No owner lock. No /authorize. Anyone in the server can use every command.**

## Commands

| Command | What it does |
|---------|----------------|
| /scrape email password | Login + scrape profile, screenshots every step |
| /reset link email [new_password] | Password reset via Microsoft link |
| /genpass [length] | Strong password generator |
| /proxystatus | Proxy pool status |
| /proxyrefresh | Pull free proxies (ProxyScrape) |
| /proxytoggle | Enable / disable proxies |
| /stats | Usage stats |
| /history [limit] | Recent jobs |
| /setheadless true\|false | Headless Chrome on/off |
| /ping | Latency |
| /help · /commands | Help |

CAPTCHA challenges are posted as images — reply with the text or `skip`.

## Setup

```bash
cd UltimatePassChangerBot
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# DISCORD_TOKEN=... in .env
python bot.py
```

Enable Message Content Intent in Discord Developer Portal.
Chrome/Chromium required.
