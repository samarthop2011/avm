"""
Ultimate Microsoft / Minecraft Account Pass Changer — PUBLIC Discord Bot
No owner lock. No authorize list. Anyone can use the commands.
Screenshots every step · Proxy rotation · CAPTCHA → Discord
"""
from __future__ import annotations

import asyncio
import json
import os
import random
import threading
import traceback
from datetime import datetime, timezone
from io import BytesIO
from typing import Optional, Dict

import discord
from discord import app_commands
from discord.ext import commands, tasks
from dotenv import load_dotenv

from automation.driver import get_proxy_pool
from automation.core import scrape_account_info
from automation.reset_password import perform_password_reset
from utils.password_generator import generate_password

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

CONFIG_FILE = os.path.join(DATA_DIR, "config.json")
STATS_FILE = os.path.join(DATA_DIR, "bot_stats.json")
HISTORY_FILE = os.path.join(DATA_DIR, "history.jsonl")

COLOR_PRIMARY = 0x7B2CBF
COLOR_SUCCESS = 0x10B981
COLOR_ERROR = 0xEF4444
COLOR_WARNING = 0xF59E0B
COLOR_INFO = 0x3B82F6

DEFAULT_CONFIG = {
    "bot_enabled": True,
    "headless": True,
    "use_proxy": True,
    "max_concurrent": 8,
    "captcha_timeout_sec": 180,
}


def load_json(path: str, default):
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return default.copy() if isinstance(default, dict) else default


def save_json(path: str, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


class DataStore:
    def __init__(self):
        self.config = load_json(CONFIG_FILE, DEFAULT_CONFIG)
        self.stats = load_json(
            STATS_FILE,
            {"total_processed": 0, "total_success": 0, "total_failed": 0, "users_served": {}},
        )
        self.active_jobs: Dict[int, dict] = {}

    def save_all(self):
        save_json(CONFIG_FILE, self.config)
        save_json(STATS_FILE, self.stats)

    def bump_stat(self, success: bool, uid: int):
        self.stats["total_processed"] += 1
        if success:
            self.stats["total_success"] += 1
        else:
            self.stats["total_failed"] += 1
        key = str(uid)
        self.stats["users_served"][key] = self.stats["users_served"].get(key, 0) + 1
        save_json(STATS_FILE, self.stats)

    def log_history(self, row: dict):
        with open(HISTORY_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(row, default=str) + "\n")


store = DataStore()

intents = discord.Intents.default()
intents.message_content = True
intents.dm_messages = True
bot = commands.Bot(command_prefix="!", intents=intents)


def embed(title: str, description: str = "", color: int = COLOR_PRIMARY) -> discord.Embed:
    e = discord.Embed(title=title, description=description, color=color, timestamp=datetime.now(timezone.utc))
    e.set_footer(text="Ultimate Pass Changer · public")
    return e


async def send_step(
    channel: discord.abc.Messageable,
    step: str,
    detail: str = "",
    png: Optional[bytes] = None,
    color: int = COLOR_INFO,
):
    e = embed(f"Step · {step}", detail, color)
    files = []
    if png:
        fname = f"{step.replace(' ', '_')[:40]}.png"
        files.append(discord.File(BytesIO(png), filename=fname))
        e.set_image(url=f"attachment://{fname}")
    await channel.send(embed=e, files=files or None)


class CaptchaBridge:
    """Selenium thread blocks until user replies in Discord with captcha text."""

    def __init__(self, user: discord.User, channel: discord.abc.Messageable, loop: asyncio.AbstractEventLoop):
        self.user = user
        self.channel = channel
        self.loop = loop

    def solve(self, png_bytes: bytes) -> str:
        fut = asyncio.run_coroutine_threadsafe(self._ask(png_bytes), self.loop)
        try:
            return fut.result(timeout=store.config.get("captcha_timeout_sec", 180))
        except Exception as e:
            print(f"[CaptchaBridge] {e}")
            return ""

    async def _ask(self, png_bytes: bytes) -> str:
        file = discord.File(BytesIO(png_bytes), filename="captcha.png")
        e = embed(
            "CAPTCHA / Robot Check",
            f"{self.user.mention} solve the image below.\n"
            f"Reply here with the **exact text** within "
            f"{store.config.get('captcha_timeout_sec', 180)}s.\n"
            f"Type `skip` to abort.",
            COLOR_WARNING,
        )
        e.set_image(url="attachment://captcha.png")
        msg = await self.channel.send(content=self.user.mention, embed=e, file=file)

        def check(m: discord.Message):
            return m.author.id == self.user.id and m.channel.id == msg.channel.id

        try:
            reply = await bot.wait_for(
                "message",
                check=check,
                timeout=store.config.get("captcha_timeout_sec", 180),
            )
            text = reply.content.strip()
            if text.lower() == "skip":
                return ""
            await self.channel.send(embed=embed("Answer received", f"`{text}`", COLOR_SUCCESS))
            return text
        except asyncio.TimeoutError:
            await self.channel.send(embed=embed("CAPTCHA timeout", "No answer received.", COLOR_ERROR))
            return ""


def run_scrape_job(email: str, password: str, user: discord.User, channel_id: int, loop: asyncio.AbstractEventLoop):
    channel = bot.get_channel(channel_id)
    if channel is None:
        try:
            channel = user.dm_channel or loop.run_until_complete(user.create_dm())
        except Exception:
            channel = None

    def log(msg: str):
        if channel:
            asyncio.run_coroutine_threadsafe(send_step(channel, "LOG", msg, color=COLOR_INFO), loop)

    def shot(png: bytes, label: str):
        if channel:
            asyncio.run_coroutine_threadsafe(
                send_step(channel, label, "Screenshot", png=png, color=COLOR_PRIMARY), loop
            )

    bridge = CaptchaBridge(user, channel, loop) if channel else None

    try:
        result = scrape_account_info(
            email=email,
            password=password,
            log=log,
            screenshot=shot,
            captcha_solver=bridge.solve if bridge else None,
            headless=store.config.get("headless", True),
            use_proxy=store.config.get("use_proxy", True),
        )
        success = result.get("error") is None
        store.bump_stat(success, user.id)
        store.log_history({"type": "scrape", "email": email, "result": result, "user": user.id, "ts": str(datetime.now())})

        async def finish():
            if not channel:
                return
            if success:
                e = embed("Account Info", color=COLOR_SUCCESS)
                e.add_field(name="Email", value=f"`{email}`", inline=False)
                e.add_field(name="Name", value=str(result.get("name") or "—"))
                e.add_field(name="DOB", value=str(result.get("dob") or "—"))
                e.add_field(name="Region", value=str(result.get("region") or "—"))
                e.add_field(name="Skype", value=str(result.get("skype_id") or "—"))
            else:
                e = embed("Scrape Failed", str(result.get("error") or "unknown"), COLOR_ERROR)
            await channel.send(embed=e)

        asyncio.run_coroutine_threadsafe(finish(), loop)
    except Exception as e:
        traceback.print_exc()
        store.bump_stat(False, user.id)
        if channel:
            asyncio.run_coroutine_threadsafe(channel.send(embed=embed("Crash", str(e), COLOR_ERROR)), loop)
    finally:
        store.active_jobs.pop(user.id, None)


def run_reset_job(
    reset_link: str,
    email: str,
    new_password: Optional[str],
    user: discord.User,
    channel_id: int,
    loop: asyncio.AbstractEventLoop,
):
    channel = bot.get_channel(channel_id)
    if channel is None:
        try:
            channel = user.dm_channel or loop.run_until_complete(user.create_dm())
        except Exception:
            channel = None

    if not new_password:
        new_password = generate_password(14)

    def log(msg: str):
        if channel:
            asyncio.run_coroutine_threadsafe(send_step(channel, "LOG", msg, color=COLOR_INFO), loop)

    def shot(png: bytes, label: str):
        if channel:
            asyncio.run_coroutine_threadsafe(
                send_step(channel, label, "Screenshot", png=png, color=COLOR_PRIMARY), loop
            )

    bridge = CaptchaBridge(user, channel, loop) if channel else None

    try:
        result = perform_password_reset(
            reset_link=reset_link,
            email=email,
            new_password=new_password,
            log=log,
            screenshot=shot,
            captcha_solver=bridge.solve if bridge else None,
            headless=store.config.get("headless", True),
            use_proxy=store.config.get("use_proxy", True),
        )
        success = bool(result.get("success"))
        store.bump_stat(success, user.id)
        store.log_history(
            {
                "type": "reset",
                "email": email,
                "new_password": new_password if success else None,
                "result": result,
                "user": user.id,
                "ts": str(datetime.now()),
            }
        )

        async def finish():
            if not channel:
                return
            if success:
                e = embed("Password Changed", color=COLOR_SUCCESS)
                e.add_field(name="Email", value=f"`{email}`", inline=False)
                e.add_field(name="New Password", value=f"`{new_password}`", inline=False)
                e.add_field(name="Note", value="Save this. Not recoverable later.", inline=False)
            else:
                e = embed("Reset Failed", str(result.get("error") or "unknown"), COLOR_ERROR)
            await channel.send(embed=e)

        asyncio.run_coroutine_threadsafe(finish(), loop)
    except Exception as e:
        traceback.print_exc()
        store.bump_stat(False, user.id)
        if channel:
            asyncio.run_coroutine_threadsafe(channel.send(embed=embed("Crash", str(e), COLOR_ERROR)), loop)
    finally:
        store.active_jobs.pop(user.id, None)


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} ({bot.user.id})")
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} commands: {[c.name for c in synced]}")
    except Exception as e:
        print(f"Sync error: {e}")
    if not proxy_refresh.is_running():
        proxy_refresh.start()
    activity = discord.Activity(type=discord.ActivityType.watching, name="/help | public pass changer")
    await bot.change_presence(activity=activity)


@tasks.loop(hours=2)
async def proxy_refresh():
    pool = get_proxy_pool()
    added = await asyncio.to_thread(pool.fetch_live)
    print(f"[proxy] +{added} total={len(pool)}")


# ===================== PUBLIC COMMANDS (no owner / no auth) =====================

@bot.tree.command(name="help", description="Show all bot commands")
async def cmd_help(interaction: discord.Interaction):
    e = embed("Ultimate Pass Changer — Commands")
    e.add_field(
        name="Account",
        value=(
            "`/scrape email password` — login + pull profile (screenshots every step)\n"
            "`/reset link email [new_password]` — change password via reset link\n"
            "`/genpass [length]` — generate a strong password"
        ),
        inline=False,
    )
    e.add_field(
        name="Proxy",
        value=(
            "`/proxystatus` — pool size + sample\n"
            "`/proxyrefresh` — pull free proxies from ProxyScrape\n"
            "`/proxytoggle` — enable / disable proxies"
        ),
        inline=False,
    )
    e.add_field(
        name="Info",
        value="`/stats` · `/history [limit]` · `/ping` · `/setheadless true|false`",
        inline=False,
    )
    e.add_field(
        name="CAPTCHA",
        value="When a robot check appears the bot posts the image. Reply with the text (or `skip`).",
        inline=False,
    )
    e.add_field(name="Access", value="**Public** — no owner lock, anyone can use.", inline=False)
    await interaction.response.send_message(embed=e)


@bot.tree.command(name="scrape", description="Login to Microsoft account and scrape profile info")
@app_commands.describe(email="Account email", password="Current password")
async def cmd_scrape(interaction: discord.Interaction, email: str, password: str):
    if interaction.user.id in store.active_jobs:
        await interaction.response.send_message("You already have a job running. Wait for it to finish.", ephemeral=True)
        return
    if len(store.active_jobs) >= store.config.get("max_concurrent", 8):
        await interaction.response.send_message("Bot is busy. Try again in a moment.", ephemeral=True)
        return

    await interaction.response.send_message(
        embed=embed("Scrape started", f"Email: `{email}`\nScreenshots will stream below.")
    )
    store.active_jobs[interaction.user.id] = {"type": "scrape", "started": datetime.now()}
    t = threading.Thread(
        target=run_scrape_job,
        args=(email, password, interaction.user, interaction.channel_id, bot.loop),
        daemon=True,
    )
    t.start()


@bot.tree.command(name="reset", description="Change password using a Microsoft reset link")
@app_commands.describe(
    link="Full password-reset URL from Microsoft email",
    email="Account email",
    new_password="Optional custom new password (auto-generated if empty)",
)
async def cmd_reset(
    interaction: discord.Interaction,
    link: str,
    email: str,
    new_password: Optional[str] = None,
):
    if interaction.user.id in store.active_jobs:
        await interaction.response.send_message("You already have a job running.", ephemeral=True)
        return
    if not link.startswith("http"):
        await interaction.response.send_message("Link must be a full http(s) URL.", ephemeral=True)
        return
    if len(store.active_jobs) >= store.config.get("max_concurrent", 8):
        await interaction.response.send_message("Bot is busy. Try again shortly.", ephemeral=True)
        return

    await interaction.response.send_message(
        embed=embed(
            "Reset started",
            f"Email: `{email}`\nNew pass: `{'auto' if not new_password else 'custom'}`",
        )
    )
    store.active_jobs[interaction.user.id] = {"type": "reset", "started": datetime.now()}
    t = threading.Thread(
        target=run_reset_job,
        args=(link, email, new_password, interaction.user, interaction.channel_id, bot.loop),
        daemon=True,
    )
    t.start()


@bot.tree.command(name="genpass", description="Generate a strong password")
@app_commands.describe(length="Length 10-32 (default 14)")
async def cmd_genpass(interaction: discord.Interaction, length: app_commands.Range[int, 10, 32] = 14):
    pw = generate_password(length)
    await interaction.response.send_message(
        embed=embed("Generated Password", f"`{pw}`", COLOR_SUCCESS), ephemeral=True
    )


@bot.tree.command(name="proxystatus", description="Show proxy pool status")
async def cmd_proxystatus(interaction: discord.Interaction):
    pool = get_proxy_pool()
    sample = pool.random()
    sample_s = f"{sample[0]}://{sample[1]}:{sample[2]}" if sample else "none"
    e = embed("Proxy Pool")
    e.add_field(name="Count", value=str(len(pool)))
    e.add_field(name="Enabled", value=str(store.config.get("use_proxy", True)))
    e.add_field(name="Sample", value=f"`{sample_s}`", inline=False)
    e.add_field(
        name="Sources",
        value="Good_HTTP.txt · Good_Socks5.txt · static list · ProxyScrape live",
        inline=False,
    )
    await interaction.response.send_message(embed=e)


@bot.tree.command(name="proxyrefresh", description="Fetch fresh free proxies from ProxyScrape")
async def cmd_proxyrefresh(interaction: discord.Interaction):
    await interaction.response.defer(thinking=True)
    pool = get_proxy_pool()
    added = await asyncio.to_thread(pool.fetch_live)
    await interaction.followup.send(
        embed=embed("Proxy refresh", f"Added **{added}** · total **{len(pool)}**", COLOR_SUCCESS)
    )


@bot.tree.command(name="proxytoggle", description="Toggle proxy usage on/off")
async def cmd_proxytoggle(interaction: discord.Interaction):
    store.config["use_proxy"] = not store.config.get("use_proxy", True)
    store.save_all()
    await interaction.response.send_message(
        embed=embed("Proxy", f"use_proxy = **{store.config['use_proxy']}**", COLOR_INFO)
    )


@bot.tree.command(name="stats", description="Bot usage statistics")
async def cmd_stats(interaction: discord.Interaction):
    s = store.stats
    e = embed("Statistics")
    e.add_field(name="Processed", value=str(s.get("total_processed", 0)))
    e.add_field(name="Success", value=str(s.get("total_success", 0)))
    e.add_field(name="Failed", value=str(s.get("total_failed", 0)))
    e.add_field(name="Active jobs", value=str(len(store.active_jobs)))
    e.add_field(name="Proxies", value=str(len(get_proxy_pool())))
    await interaction.response.send_message(embed=e)


@bot.tree.command(name="setheadless", description="Run Chrome headless or visible")
@app_commands.describe(value="true = headless, false = visible browser")
async def cmd_setheadless(interaction: discord.Interaction, value: bool):
    store.config["headless"] = value
    store.save_all()
    await interaction.response.send_message(embed=embed("Headless", f"headless = **{value}**"))


@bot.tree.command(name="history", description="Recent job history")
@app_commands.describe(limit="How many lines (max 20)")
async def cmd_history(interaction: discord.Interaction, limit: app_commands.Range[int, 1, 20] = 10):
    if not os.path.exists(HISTORY_FILE):
        await interaction.response.send_message("No history yet.", ephemeral=True)
        return
    lines = open(HISTORY_FILE, encoding="utf-8").read().strip().splitlines()[-limit:]
    text = "\n".join(f"`{l[:160]}`" for l in lines) or "empty"
    await interaction.response.send_message(embed=embed("History", text[:3900]), ephemeral=True)


@bot.tree.command(name="ping", description="Latency check")
async def cmd_ping(interaction: discord.Interaction):
    await interaction.response.send_message(
        embed=embed("Pong", f"{round(bot.latency * 1000)} ms", COLOR_SUCCESS)
    )


@bot.tree.command(name="commands", description="List every slash command registered")
async def cmd_commands(interaction: discord.Interaction):
    names = sorted(c.name for c in bot.tree.get_commands())
    await interaction.response.send_message(
        embed=embed("Registered commands", ", ".join(f"`/{n}`" for n in names) or "none")
    )


def main():
    if not TOKEN:
        raise SystemExit("Set DISCORD_TOKEN in .env")
    pool = get_proxy_pool()
    print(f"Proxy pool: {len(pool)} entries")
    print("PUBLIC mode — no owner / authorize gates")
    bot.run(TOKEN)


if __name__ == "__main__":
    main()
