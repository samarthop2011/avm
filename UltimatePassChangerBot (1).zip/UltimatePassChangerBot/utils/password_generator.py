import random
import string


def generate_password(length: int = 14) -> str:
    """Strong password acceptable by Microsoft rules."""
    length = max(10, min(length, 32))
    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    digits = string.digits
    special = "!@#$%&*"
    # guarantee classes
    chars = [
        random.choice(lower),
        random.choice(upper),
        random.choice(digits),
        random.choice(special),
    ]
    pool = lower + upper + digits + special
    chars += [random.choice(pool) for _ in range(length - 4)]
    random.shuffle(chars)
    return "".join(chars)
