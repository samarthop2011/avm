"""
Password reset flow for Microsoft / Xbox Live accounts.
"""
from __future__ import annotations

import time
from typing import Callable, Optional

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

from automation.driver import create_driver, cleanup_driver
from automation.captcha import take_full_screenshot, download_hip_captcha, inject_captcha_answer


def clean_text(text: str) -> str:
    if not text:
        return ""
    return "".join(c for c in str(text) if ord(c) <= 0xFFFF)


LogFn = Callable[[str], None]
ShotFn = Callable[[bytes, str], None]  # png bytes, label


def perform_password_reset(
    reset_link: str,
    email: str,
    new_password: str,
    log: Optional[LogFn] = None,
    screenshot: Optional[ShotFn] = None,
    captcha_solver: Optional[Callable[[bytes], str]] = None,
    headless: bool = True,
    use_proxy: bool = True,
) -> dict:
    """
    Open reset link, enter email + new password, handle captcha if needed.
    captcha_solver(png_bytes) -> answer string (blocks until user solves).
    """
    def _log(msg: str):
        print(msg)
        if log:
            log(msg)

    def _shot(driver, label: str):
        if screenshot:
            try:
                png = driver.get_screenshot_as_png()
                screenshot(png, label)
            except Exception:
                pass

    driver = create_driver(headless=headless, use_proxy=use_proxy)
    wait = WebDriverWait(driver, 25)
    result = {"email": email, "success": False, "error": None, "new_password": new_password}

    try:
        _log("Opening reset link...")
        driver.get(reset_link)
        time.sleep(2)
        _shot(driver, "01_reset_link_opened")

        # Email
        try:
            email_input = wait.until(
                EC.presence_of_element_located(
                    (By.ID, "AccountNameInput")
                )
            )
        except TimeoutException:
            try:
                email_input = wait.until(
                    EC.presence_of_element_located((By.NAME, "i0116"))
                )
            except TimeoutException:
                email_input = wait.until(
                    EC.presence_of_element_located(
                        (By.CSS_SELECTOR, "input[type='email'], input[name*='mail' i]")
                    )
                )
        email_input.clear()
        email_input.send_keys(clean_text(email))
        email_input.send_keys(Keys.RETURN)
        _log("Email submitted.")
        time.sleep(2)
        _shot(driver, "02_email_submitted")

        # Possible captcha after email
        hip = download_hip_captcha(driver)
        if hip is None:
            # still try page screenshot for any challenge
            page = driver.page_source.lower()
            if "captcha" in page or "hip" in page or "prove" in page:
                hip = take_full_screenshot(driver)
        if hip is not None and captcha_solver:
            _log("CAPTCHA detected — sending to Discord for solve...")
            _shot(driver, "03_captcha_challenge")
            answer = captcha_solver(hip.getvalue())
            if answer:
                if inject_captcha_answer(driver, answer):
                    _log(f"CAPTCHA answer injected: {answer}")
                    try:
                        submit = driver.find_element(By.CSS_SELECTOR, "input[type='submit'], button[type='submit']")
                        submit.click()
                    except Exception:
                        pass
                    time.sleep(2)
                    _shot(driver, "04_captcha_submitted")
                else:
                    _log("Could not find captcha input field.")

        # New password fields
        try:
            new_pass = wait.until(EC.presence_of_element_located((By.ID, "iPassword")))
        except TimeoutException:
            new_pass = wait.until(
                EC.presence_of_element_located(
                    (By.CSS_SELECTOR, "input[type='password']")
                )
            )
        new_pass.clear()
        new_pass.send_keys(clean_text(new_password))

        try:
            retype = driver.find_element(By.ID, "iRetypePassword")
            retype.clear()
            retype.send_keys(clean_text(new_password))
        except Exception:
            # some flows only have one field
            pass

        _log("New password filled.")
        time.sleep(1)
        _shot(driver, "05_password_filled")
        try:
            new_pass.send_keys(Keys.RETURN)
        except Exception:
            try:
                btn = driver.find_element(By.CSS_SELECTOR, "input[type='submit'], button[type='submit']")
                btn.click()
            except Exception:
                pass

        time.sleep(4)
        _shot(driver, "06_after_submit")

        page = driver.page_source.lower()
        if "success" in page or "changed" in page or "updated" in page or "sign in" in page:
            result["success"] = True
            _log("Password reset appears successful.")
        else:
            # check for previous password field = sometimes required
            try:
                prev = driver.find_element(By.CSS_SELECTOR, 'input[data-nuid="PreviousPasswordInput"]')
                result["error"] = "Previous password required (account may need different flow)"
                _log(result["error"])
            except Exception:
                result["success"] = True  # optimistic if no clear error
                _log("No clear error; treating as success.")

    except Exception as e:
        result["error"] = str(e)
        _log(f"Reset failed: {e}")
        try:
            _shot(driver, "99_error")
        except Exception:
            pass
    finally:
        cleanup_driver(driver)

    return result
