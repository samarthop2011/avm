"""
CAPTCHA helpers: screenshot, download HIP image, optional 2captcha / manual solve path.
"""
from __future__ import annotations

import base64
from io import BytesIO
from typing import Optional

from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
from PIL import Image
import requests


def take_full_screenshot(driver: WebDriver) -> BytesIO:
    png = driver.get_screenshot_as_png()
    buf = BytesIO(png)
    buf.seek(0)
    return buf


def download_hip_captcha(driver: WebDriver) -> Optional[BytesIO]:
    """Microsoft GetHIPData image."""
    try:
        captcha_img = driver.find_element(By.XPATH, '//img[contains(@src, "GetHIPData") or contains(@src, "HIP") or contains(@id, "hip")]')
        src = captcha_img.get_attribute("src") or ""
        if src.startswith("data:image"):
            header, b64 = src.split(",", 1)
            raw = base64.b64decode(b64)
            img = Image.open(BytesIO(raw))
        else:
            resp = requests.get(src, timeout=15)
            resp.raise_for_status()
            img = Image.open(BytesIO(resp.content))
        buf = BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        return buf
    except Exception as e:
        print(f"[captcha] HIP download failed: {e}")
        return None


def element_screenshot(driver: WebDriver, element) -> Optional[BytesIO]:
    try:
        png = element.screenshot_as_png
        buf = BytesIO(png)
        buf.seek(0)
        return buf
    except Exception:
        return take_full_screenshot(driver)


def try_solve_simple_text(driver: WebDriver) -> Optional[str]:
    """
    Very light heuristic: if a short numeric/alpha challenge is visible
    in known labels, return None so Discord user can solve.
    Real auto-solve requires external service (2captcha key etc).
    """
    return None


def inject_captcha_answer(driver: WebDriver, answer: str) -> bool:
    selectors = [
        (By.ID, "hipTextBox"),
        (By.NAME, "hip"),
        (By.ID, "captchaInput"),
        (By.CSS_SELECTOR, "input[aria-label*='captcha' i]"),
        (By.CSS_SELECTOR, "input[placeholder*='characters' i]"),
        (By.XPATH, "//input[contains(@id,'hip') or contains(@name,'hip')]"),
    ]
    for by, sel in selectors:
        try:
            el = driver.find_element(by, sel)
            el.clear()
            el.send_keys(answer)
            return True
        except Exception:
            continue
    return False
