"""
Microsoft account login + profile scrape.
"""
from __future__ import annotations

import time
from typing import Callable, Optional

import pycountry
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

from automation.driver import create_driver, cleanup_driver
from automation.captcha import take_full_screenshot, download_hip_captcha, inject_captcha_answer

ALL_COUNTRIES = {c.name for c in pycountry.countries}

LogFn = Callable[[str], None]
ShotFn = Callable[[bytes, str], None]


def scrape_account_info(
    email: str,
    password: str,
    log: Optional[LogFn] = None,
    screenshot: Optional[ShotFn] = None,
    captcha_solver: Optional[Callable[[bytes], str]] = None,
    headless: bool = True,
    use_proxy: bool = True,
) -> dict:
    def _log(msg: str):
        print(msg)
        if log:
            log(msg)

    def _shot(driver, label: str):
        if screenshot:
            try:
                screenshot(driver.get_screenshot_as_png(), label)
            except Exception:
                pass

    driver = create_driver(headless=headless, use_proxy=use_proxy)
    wait = WebDriverWait(driver, 20)
    out = {
        "email": email,
        "error": None,
        "name": None,
        "dob": None,
        "region": None,
        "skype_id": None,
    }

    try:
        _log("Navigating to login.live.com ...")
        driver.get("https://login.live.com")
        time.sleep(1.5)
        _shot(driver, "01_login_page")

        # Email
        try:
            email_input = wait.until(EC.presence_of_element_located((By.ID, "usernameEntry")))
        except TimeoutException:
            email_input = wait.until(EC.presence_of_element_located((By.NAME, "loginfmt")))
        email_input.clear()
        email_input.send_keys(email)
        email_input.send_keys(Keys.RETURN)
        time.sleep(2)
        _shot(driver, "02_email_entered")

        # Password path (multiple UI variants)
        password_input = None
        for attempt in range(4):
            try:
                password_input = WebDriverWait(driver, 4).until(
                    EC.presence_of_element_located((By.NAME, "passwd"))
                )
                break
            except TimeoutException:
                pass
            # alternate buttons
            for xpath in (
                "//span[contains(text(), 'Use your password')]",
                "//span[contains(text(), 'Other ways to sign in')]",
                "//*[@id='idA_PWD_SwitchToCredPicker']",
            ):
                try:
                    btn = WebDriverWait(driver, 2).until(EC.element_to_be_clickable((By.XPATH, xpath)))
                    btn.click()
                    time.sleep(1)
                    _shot(driver, f"03_alt_login_{attempt}")
                    break
                except TimeoutException:
                    continue

        if password_input is None:
            try:
                password_input = wait.until(EC.presence_of_element_located((By.NAME, "passwd")))
            except TimeoutException:
                # captcha before password?
                hip = download_hip_captcha(driver) or take_full_screenshot(driver)
                if captcha_solver and hip:
                    _log("Pre-password challenge detected.")
                    ans = captcha_solver(hip.getvalue())
                    if ans:
                        inject_captcha_answer(driver, ans)
                        time.sleep(2)
                try:
                    password_input = wait.until(EC.presence_of_element_located((By.NAME, "passwd")))
                except TimeoutException:
                    out["error"] = "Could not reach password input"
                    _shot(driver, "99_no_password")
                    return out

        password_input.send_keys(password)
        password_input.send_keys(Keys.RETURN)
        time.sleep(2)
        _shot(driver, "04_password_submitted")

        # post-login challenges / stay signed in
        page = driver.page_source
        if "Too Many Requests" in page:
            for _ in range(8):
                time.sleep(1.5)
                driver.refresh()
                if "Too Many Requests" not in driver.page_source:
                    break
            else:
                out["error"] = "Too Many Requests"
                return out

        # captcha after password
        hip = download_hip_captcha(driver)
        if hip and captcha_solver:
            _log("Post-login CAPTCHA.")
            _shot(driver, "05_captcha")
            ans = captcha_solver(hip.getvalue())
            if ans:
                inject_captcha_answer(driver, ans)
                try:
                    driver.find_element(By.CSS_SELECTOR, "input[type='submit'], button[type='submit']").click()
                except Exception:
                    pass
                time.sleep(2)

        for sel in (
            (By.ID, "iLandingViewAction"),
            (By.CSS_SELECTOR, 'button[data-testid="primaryButton"]'),
            (By.XPATH, '//button[@aria-label="Close"]'),
            (By.ID, "idSIButton9"),
        ):
            try:
                el = WebDriverWait(driver, 3).until(EC.element_to_be_clickable(sel))
                el.click()
                time.sleep(1)
            except TimeoutException:
                pass

        _shot(driver, "06_post_login")

        # Profile
        _log("Loading profile...")
        driver.get("https://account.microsoft.com/profile")
        time.sleep(2)
        try:
            wait.until(EC.presence_of_element_located((By.ID, "profile.profile-page.personal-section.full-name")))
            out["name"] = driver.find_element(By.ID, "profile.profile-page.personal-section.full-name").text.strip()
            spans = driver.find_elements(By.CSS_SELECTOR, "span.fui-Text")
            for span in spans:
                text = span.text.strip()
                if "/" in text and len(text.split("/")) == 3:
                    out["dob"] = text.split(";")[0].strip()
                elif text in ALL_COUNTRIES:
                    out["region"] = text
        except Exception as e:
            _log(f"Profile scrape partial: {e}")

        # Skype
        try:
            driver.get("https://secure.skype.com/portal/profile")
            time.sleep(2)
            out["skype_id"] = driver.find_element(By.CLASS_NAME, "username").text.strip()
        except Exception:
            out["skype_id"] = "live:"

        _shot(driver, "07_profile_done")
        _log(f"Scraped name={out['name']} dob={out['dob']} region={out['region']}")

    except Exception as e:
        out["error"] = str(e)
        _log(f"scrape error: {e}")
        try:
            _shot(driver, "99_error")
        except Exception:
            pass
    finally:
        cleanup_driver(driver)

    return out
