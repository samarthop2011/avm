"""
Ultimate driver factory with proxy rotation, stealth, and WebAuthn blocking.
"""
from __future__ import annotations

import os
import platform
import random
import tempfile
from typing import Optional, List, Tuple

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

try:
    from selenium_stealth import stealth
except ImportError:
    stealth = None


USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
]


def parse_proxy_line(line: str) -> Optional[Tuple[str, str, int]]:
    """Return (protocol, host, port) or None."""
    line = line.strip()
    if not line or line.startswith("#") or "INCREDIBLE" in line or "====" in line or "http" in line.lower() and "://" in line and "proxy" not in line.lower():
        if line.startswith("http://") or line.startswith("https://") or line.startswith("socks"):
            pass
        else:
            return None
    # protocol://ip:port
    if "://" in line:
        proto, rest = line.split("://", 1)
        if ":" in rest:
            host, port_s = rest.rsplit(":", 1)
            try:
                return proto.lower(), host.strip(), int(port_s.strip())
            except ValueError:
                return None
    # ip:port  -> assume http
    if ":" in line:
        host, port_s = line.rsplit(":", 1)
        try:
            return "http", host.strip(), int(port_s.strip())
        except ValueError:
            return None
    return None


class ProxyPool:
    def __init__(self, extra: Optional[List[str]] = None):
        self.proxies: List[Tuple[str, str, int]] = []
        self._idx = 0
        self._load_builtin()
        if extra:
            for line in extra:
                p = parse_proxy_line(line)
                if p:
                    self.proxies.append(p)

    def _load_builtin(self):
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        for fname in ("proxies/Good_HTTP.txt", "proxies/Good_Socks5.txt", "proxies/live.txt"):
            path = os.path.join(base, fname)
            if not os.path.exists(path):
                continue
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    p = parse_proxy_line(line)
                    if p:
                        self.proxies.append(p)
        # static elite list from Axion
        static = [
            "socks5://65.21.252.66:10808",
            "socks4://185.244.158.4:3129",
            "socks4://152.53.183.107:8081",
            "socks4://113.166.93.239:5678",
            "socks4://72.49.49.11:31034",
            "socks5://45.74.31.30:5186",
            "socks5://45.74.31.50:16251",
            "socks4://72.195.114.184:4145",
            "socks5://192.111.138.29:4145",
            "socks4://81.29.249.82:5071",
            "socks4://91.247.250.215:4145",
            "socks5://31.129.147.102:1080",
            "socks4://47.85.37.60:1080",
            "socks5://45.32.160.61:1088",
            "socks5://43.128.63.68:7890",
        ]
        for s in static:
            p = parse_proxy_line(s)
            if p:
                self.proxies.append(p)

    def fetch_live(self) -> int:
        """Pull free proxies from ProxyScrape v4."""
        import requests
        url = "https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=protocolipport&format=text"
        added = 0
        try:
            r = requests.get(url, timeout=15)
            r.raise_for_status()
            for line in r.text.splitlines():
                p = parse_proxy_line(line)
                if p:
                    self.proxies.append(p)
                    added += 1
            # persist
            base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            live_path = os.path.join(base, "proxies", "live.txt")
            os.makedirs(os.path.dirname(live_path), exist_ok=True)
            with open(live_path, "w", encoding="utf-8") as f:
                for proto, host, port in self.proxies[-added:]:
                    f.write(f"{proto}://{host}:{port}\n")
        except Exception as e:
            print(f"[ProxyPool] live fetch failed: {e}")
        return added

    def next(self) -> Optional[Tuple[str, str, int]]:
        if not self.proxies:
            return None
        self._idx = (self._idx + 1) % len(self.proxies)
        return self.proxies[self._idx]

    def random(self) -> Optional[Tuple[str, str, int]]:
        if not self.proxies:
            return None
        return random.choice(self.proxies)

    def __len__(self):
        return len(self.proxies)


_proxy_pool: Optional[ProxyPool] = None


def get_proxy_pool() -> ProxyPool:
    global _proxy_pool
    if _proxy_pool is None:
        _proxy_pool = ProxyPool()
    return _proxy_pool


def create_driver(
    headless: bool = True,
    proxy: Optional[Tuple[str, str, int]] = None,
    use_proxy: bool = True,
) -> webdriver.Chrome:
    options = Options()

    if headless:
        options.add_argument("--headless=new")
    else:
        options.add_argument("--start-maximized")

    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1366,768")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--incognito")
    options.add_argument("--disable-webauthn")
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-popup-blocking")
    options.add_argument("--disable-infobars")
    options.add_argument("--lang=en-US")

    webauthn_features = [
        "WebAuthentication", "WebAuthn", "WebAuthenticationAPI",
        "WebAuthenticationSecurityKey", "WebAuthenticationUI",
    ]
    if platform.system().lower() == "windows":
        webauthn_features.extend([
            "WindowsHello", "WindowsHelloForSecurityKeys", "WebAuthenticationWindowsHello",
        ])
        options.add_argument("--disable-webauthn-uvpa")
    options.add_argument(f"--disable-features={','.join(webauthn_features)}")

    prefs = {
        "credentials_enable_autosignin": False,
        "credentials_enable_service": False,
        "webauthn.enable_win_native_api": False,
        "webauthn.enable_usb": False,
        "webauthn.enable_platform_authenticators": False,
        "profile.default_content_setting_values.notifications": 2,
    }
    options.add_experimental_option("prefs", prefs)
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)

    ua = random.choice(USER_AGENTS)
    options.add_argument(f"user-agent={ua}")

    # Proxy
    chosen = proxy
    if use_proxy and chosen is None:
        chosen = get_proxy_pool().random()
    if chosen:
        proto, host, port = chosen
        # Chrome only natively supports http proxies well; socks5 works on many builds
        proxy_arg = f"{proto}://{host}:{port}"
        options.add_argument(f"--proxy-server={proxy_arg}")
        print(f"[driver] using proxy {proxy_arg}")

    # Locate chrome binary
    chrome_paths = [
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable",
        "/usr/bin/chromium-browser",
        "/usr/bin/chromium",
        "/opt/google/chrome/chrome",
        "/snap/bin/chromium",
    ]
    for path in chrome_paths:
        if os.path.exists(path):
            options.binary_location = path
            break

    temp_profile = tempfile.mkdtemp(prefix="upc_")
    options.add_argument(f"--user-data-dir={temp_profile}")

    try:
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=options)
    except Exception:
        driver = webdriver.Chrome(options=options)

    driver.execute_cdp_cmd(
        "Page.addScriptToEvaluateOnNewDocument",
        {
            "source": """
            Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
            window.chrome = { runtime: {} };
            Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
            Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
            """
        },
    )
    if stealth:
        try:
            stealth(
                driver,
                languages=["en-US", "en"],
                vendor="Google Inc.",
                platform="Win32",
                webgl_vendor="Intel Inc.",
                renderer="Intel Iris OpenGL Engine",
                fix_hairline=True,
            )
        except Exception:
            pass

    driver._upc_temp_profile = temp_profile  # type: ignore
    return driver


def cleanup_driver(driver: webdriver.Chrome) -> None:
    try:
        driver.quit()
    except Exception:
        pass
    profile = getattr(driver, "_upc_temp_profile", None)
    if profile and os.path.isdir(profile):
        import shutil
        shutil.rmtree(profile, ignore_errors=True)
